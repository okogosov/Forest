#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

void generateFiles(const std::string& projectName, const std::vector<std::string>& methods) 
{
  std::string upperProjectName = projectName;
  std::transform(upperProjectName.begin(), upperProjectName.end(), upperProjectName.begin(), ::toupper);

  // Generate header file content
  std::ostringstream headerContent;
  headerContent << "#ifndef " << upperProjectName << "_H\n";
  headerContent << "#define " << upperProjectName << "_H\n\n";
  headerContent << "#ifdef " << upperProjectName << "_EXPORTS\n";
  headerContent << "#define " << upperProjectName << "_API __declspec(dllexport)\n";
  headerContent << "#else\n";
  headerContent << "#define " << upperProjectName << "_API __declspec(dllimport)\n";
  headerContent << "#endif\n\n";
  headerContent << "namespace PPLNS\n{\n";
  headerContent << "  class " << upperProjectName << "_API " << projectName << " : public BaseClass\n  {\n  public:\n";
  headerContent << "    " << projectName << "(PPL* ppl);\n";
  headerContent << "    void AddToKeywordDictionary();\n";

  for (const auto& method : methods) 
  {
    headerContent << "    bool Func" << method << "(vector<string> parameters, string& result, Composite* node);\n";
  }

  headerContent << "  };\n";
  headerContent << "  extern \"C\" void " << upperProjectName << "_API " << projectName << "_CreateInstance(PPL* ppl);\n";
  headerContent << "}\n#endif\n";

  // Generate cpp file content
  std::ostringstream cppContent;
  cppContent << "#include \"pch.h\"\n";
  cppContent << "#include \"..\\PPL\\PPL.h\"\n";
  cppContent << "#include \"..\\PPL\\Component\\Component.h\"\n";
  cppContent << "#include \"..\\PPL\\Processing\\processing.h\"\n";
  cppContent << "#include \"" << projectName << ".h\"\n\n";
  cppContent << "using namespace std;\n";
  cppContent << "namespace PPLNS\n{\n";
  cppContent << "  static " << projectName << "* " << upperProjectName << "Instance = nullptr;\n\n";
  cppContent << "  void " << upperProjectName << "_CreateInstance(PPL* ppl)\n  {\n";
  cppContent << "    " << upperProjectName << "Instance = new " << projectName << "(ppl);\n";
  cppContent << "    " << upperProjectName << "Instance->AddToKeywordDictionary();\n";
  cppContent << "  }\n\n";
  cppContent << "  " << projectName << "::" << projectName << "(PPL* ppl)\n  {\n";
  cppContent << "    this->ppl = ppl;\n";
  cppContent << "    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;\n";
  cppContent << "  }\n";
  cppContent << "  //=======================================================\n";
  cppContent << "  void " << projectName << "::AddToKeywordDictionary()\n  {\n";
  cppContent << "    //help_dict is created in BaseClass\n";
  cppContent << "    AddKeyword(\"help\", BaseClass::FuncHelp);\n";

  for (const auto& method : methods) 
  {
    cppContent << "    AddKeyword(\"" << method << "\", Func" << method << ");\n";
  }

  cppContent << "    help_dict->insert({ \"help\", \"\\t" << projectName << ".help([name])\" });\n";

  for (const auto& method : methods) 
  {
    cppContent << "    help_dict->insert(\"" << method << "\", \"\\t...\");\n";
  }

  cppContent << "    for (const auto pair : *keyword_dict)\n    {\n";
  cppContent << "      string key = \"" << projectName << ".\" + pair.first;\n";
  cppContent << "      ppl->processing->keyword_dict->insert({ key, pair.second });\n";
  cppContent << "    }\n";
  cppContent << "    ppl->ImportList->insert({ \"" << projectName << "\", this });\n";
  cppContent << "  }\n";
  cppContent << "  //=========================================================\n";

  for (const auto& method : methods) 
  {
    cppContent << "  bool " << projectName << "::Func" << method << "(vector<string> parameters, string& result, Composite* node) { return true; }\n";
  }

  cppContent << "}\n";

  // Save files
  std::ofstream headerFile(projectName + ".h");
  headerFile << headerContent.str();
  headerFile.close();

  std::ofstream cppFile(projectName + ".cpp");
  cppFile << cppContent.str();
  cppFile.close();
}

int main(int argc, char* argv[]) 
{
  if (argc != 2) 
  {
    std::cerr << "Usage: " << argv[0] << " <ProjectName.cfg>" << std::endl;
    return 1;
  }

  std::ifstream configFile(argv[1]);
  if (!configFile.is_open()) 
  {
    std::cerr << "Could not open the config file." << std::endl;
    return 1;
  }

  std::string projectName;
  std::vector<std::string> methods;
  std::string line;

  while (std::getline(configFile, line)) 
  {
    if (line.find("ProjectName") != std::string::npos) 
    {
      projectName = line.substr(line.find('=') + 1);
      projectName.erase(remove_if(projectName.begin(), projectName.end(), isspace), projectName.end());
    }
    else //if (line.find("Methods") != std::string::npos) 
    {
      std::string methodsLine = line.substr(line.find('=') + 1);
      std::istringstream methodStream(methodsLine);
      std::string method;
      while (std::getline(methodStream, method, ',')) 
      {
        method.erase(remove_if(method.begin(), method.end(), isspace), method.end());
        if (!method.empty()) 
        {
          methods.push_back(method);
        }
      }
    }
  }

  configFile.close();

  generateFiles(projectName, methods);
  std::cout << "Files generated for project: " << projectName << std::endl;

  return 0;
}
