
#include "pch.h"
#include "..\\PPL\\PPL.h"
#include "..\\PPL\\Component\\Component.h"
#include "..\\PPL\\Processing\\processing.h"
#include "#ProjectName#.h"

using namespace std;
namespace PPLNS
{
  static #ProjectName#* #ProjectName#Instance = nullptr;

  void #ProjectName#_CreateInstance(PPL* ppl)
  {
    #ProjectName#Instance = new #ProjectName#(ppl);
    #ProjectName#Instance->AddToKeywordDictionary();
  }

  #ProjectName#::#ProjectName#(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void #ProjectName#::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("#Method#", FuncCompare);
    

    help_dict->insert({ "help","\t#ProjectName#.help([name])" });
    help_dict.Add("#Method#", "\t...");
    
    for (const auto pair : *keyword_dict)
    {
      string key = "#ProjectName#." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList->insert({ "#ProjectName#",this });
  }
  //=========================================================
  bool #ProjectName#::Func#Method#(vector<string> parameters, string& result, Composite* node) 
  { 
   return true;  
  }  
}

