#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame name"></param>
    /// <param name="filename.csv|data"></param>
    /// <param name="list of selected columns"></param>
    /// <returns></returns>
  bool DataFrame::FuncSave(const vector<string>& parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncSave";
    string err;
    try
    {
      if (parameters.size() < 2)
      {
        err =  "[" + func_name + "] wrong parameter, format: DataFrame.Save (DataFrame_name)(filename.csv|data)[(column name1)(column name2)...]";
        printDlgt({ "Error: {0}", err });
        return false;
      }

      string df_name = parameters[0];
      string filename = parameters[1];
      string extension = "";
      if (filename.find(".csv") != string::npos)
        extension = "csv";  
      if (filename.find(".data") != string::npos)
        extension = "data";  
      if (extension.empty())
      {
        printDlgt({ "Error: [{0}] dataframe [{1}]  wrong file extension [{2}] (must be .scr | .data)", func_name, df_name , filename});
        return false;
      }
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      int columns_quantity = comp_df->_children->size();
      string output = "     ";
      vector<string> columns_selected;

      if (parameters.size() > 2)
      {
        columns_selected.assign(parameters.begin() + 2, parameters.end());
      }

      // Test column names
      if (!columns_selected.empty())
      {
        for (const string& cw : columns_selected)
        {
          bool found = false;

          for (int i = 0; i < columns_quantity; i++)
          {
            if ( (*(comp_df->_children))[i]->name == cw)
            {
              found = true;
              break;
            }
          }

          if (!found)
          {
            err = "[" + func_name + "] wrong column name [" + cw + "]";
            printDlgt({ "Error: {0}", err });
            return false;
          }
        }
      }

      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int length;
      TryParse(strLength,length);
      output.clear();

      int RowSelectedFrom = 0;
      int RowSelectedTo = length - 1;
      string strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
      string strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");

      if (!strRowSelectedFrom.empty())
      {
        //RowSelectedFrom = stoi(strRowSelectedFrom);
        if (!TryParse(strRowSelectedFrom, RowSelectedFrom))
        {
          printDlgt({ "Error: [{0}] dataframe [{1}] RowSelectedFrom not digit [{2}]", func_name, df_name, strRowSelectedFrom });
          return false;
        }
      }

      if (!strRowSelectedTo.empty())
      {
        //RowSelectedTo = stoi(strRowSelectedTo);
        if (!TryParse(strRowSelectedTo, RowSelectedTo))
        {
          printDlgt({ "Error: [{0}] dataframe [{1}] RowSelectedTo not digit [{2}]", func_name, df_name, strRowSelectedTo });
          return false;
        }
      }

      if (extension == "csv")
      {
        int real_lines = length; 
        for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
        {
          for (int i = 1; i < columns_quantity; i++)
          {
            Composite* comp2 = (Composite*)(*(comp_df->_children))[i];
            if(!columns_selected.empty())
            {
              if (!VectorContains<string>(columns_selected, comp2->name))
                continue;
            }            
            output += (*(comp2->_children))[j]->value + ",";
          }

          if (!output.empty())
          {
            output.pop_back();
          }
          output += "\n";   // NEW_LINE
        }

        ofstream file(filename);
        file << output;
        file.close();
      }
      if (extension == "data")
      {
        string tmp_return;
        ppl->processing->FuncSaveData({ filename, df_name }, tmp_return, node);
      }
    }
    catch (const exception& ex)
    {
      err = "[" + func_name + "]";
      printDlgt({"Error: {0}  {1}",err,ex.what()});
      return false;
    }
    return true;
  }
}