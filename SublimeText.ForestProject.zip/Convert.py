import json
import re
import os

# RGB Color Hex Codes
COLOR_BLUE    = "#0A78FA"  # Vibrant Blue (commands)
COLOR_PURPLE  = "#9B24A6"  # Deep Purple (control flow)
COLOR_YELLOW  = "#FFFE91"  # Soft Yellow (comments and methods)
COLOR_BG      = "#212121"  # Dark Gray Background
COLOR_WHITE   = "#FFFFFF"

# Commands that MUST be Blue (Ensuring 'get' and 'dbg' are colored)
blue_base = [
    "help", "version", "cls", "shell", "init", "code", "sumdata", "withset", 
    "showcode", "readcode", "rc", "createpplcode", "cpc", "display", "dbg", 
    "definestruct", "dstree", "datanames", "suspend", "resume", "debugppl", 
    "traceppl", "recreate", "log", "exit", "start", "stop", "using", 
    "importlist", "il", "eval", "calc", "length", "type", "isexist", "isdigits", 
    "isinteger", "isalldigits", "isallinteger", "iseven", "isodd", "del", 
    "sleep", "getbykey", "getk", "getbyvalue", "getv", "set", "setkvp", 
    "getvalue", "get", "getname", "gettoken", "createnode", "copynode", 
    "getnodes", "getleaves", "insertstruct", "createstruct", "functionstruct", 
    "instancename", "dstruct", "var", "const", "setconst", "realloc", 
    "storage", "sinit", "sget", "sset", "swrite", "sinfo", "ssetrow", 
    "savedata", "sd", "readdata", "rd", "write#", "writeline", "writearray", 
    "readline", "funclist", "funcname", "argc", "getargname", "call", "getresult", 
    "delegate", "dlgtinstance", "dlgtset", "dlgtcall", "callback"
]

# Control flow commands (Purple)
purple_list = ["import", "if", "else", "switch", "case", "default", "for", "setloopend", "break", "continue", "return", "finally", "failure", "function"]

def process_data():
    if not os.path.exists('Main.json'):
        print("Error: Main.json not found.")
        return
        
    with open('Main.json', 'r', encoding='utf-8') as f:
        raw_json = f.read()
    
    # Clean trailing commas which break standard JSON parsing
    cleaned_json = re.sub(r',\s*([\]}])', r'\1', raw_json)
    try:
        # Load with strict=False to handle potential control characters
        data = json.loads(cleaned_json, strict=False)
    except Exception as e:
        print(f"JSON Error: {e}")
        return

    completions = []
    blue_from_json = []

    # Process group-based Main.json and build trigger\tdescription format
    groups = data.get('groups', {})
    for group_name, cmd_list in groups.items():
        for cmd_obj in cmd_list:
            cmd_raw = cmd_obj.get('cmd', '')
            # Extract trigger names from "cmd (alias)" format
            triggers = re.findall(r'[a-zA-Z0-9#._]+', cmd_raw)
            if not triggers: continue
            
            # Select SCR lines if available, otherwise PPL
            fmt_lines = cmd_obj.get('scr') if cmd_obj.get('scr') else cmd_obj.get('ppl', [])
            
            if not fmt_lines:
                signature = triggers[0]
            else:
                # Use the first line as the menu hint
                signature = fmt_lines[0] if isinstance(fmt_lines, list) else fmt_lines

            for t in triggers:
                if t in purple_list: continue
                if t != "array": blue_from_json.append(t)
                
                # trigger\tDescription format for autocomplete list
                # contents: snippet with editable placeholder
                clean_hint = signature.replace(t, "").strip()
                contents = f"{t} ${{1:{clean_hint}}};$0" if clean_hint else f"{t};$0"

                completions.append({
                    "trigger": f"{t}\t{signature}",
                    "contents": contents
                })

    # Combine all blue keywords for regex matching
    all_blue = sorted(list(set(blue_base + blue_from_json)), key=len, reverse=True)

    # 1. Forest.sublime-completions
    with open('Forest.sublime-completions', 'w', encoding='utf-8') as f:
        json.dump({"scope": "source.forest", "completions": completions}, f, indent=4, ensure_ascii=False)

    # 2. Forest.sublime-syntax (CLEAN YAML - No trailing braces)
    syntax_yaml = f"""%YAML 1.2
---
name: Forest (SCR)
file_extensions: [scr]
scope: source.forest
contexts:
  main:
    # Comments: Soft Yellow
    - match: //.*$
      scope: forest.yellow
    - match: /\\*
      scope: forest.yellow
      push:
        - match: \\*/
          scope: forest.yellow
          pop: true
        - match: .
          scope: forest.yellow
    # Array Logic: array (Blue), .method (Yellow)
    - match: \\b(array)(\\.[a-zA-Z_0-9]+)\\b
      captures:
        1: forest.blue
        2: forest.yellow
    - match: \\barray\\b
      scope: forest.blue
    # Purple flow control
    - match: \\b({"|".join(purple_list)})\\b
      scope: forest.purple
    # Blue standard commands
    - match: \\b({"|".join([re.escape(k) for k in all_blue])})\\b
      scope: forest.blue
    - match: "'|\\""
      push:
        - match: "'|\\""
          pop: true
        - match: .
          scope: string.quoted.forest
    - match: '\\b[0-9]+\\b'
      scope: constant.numeric.forest
    - match: ";"
      scope: punctuation.terminator.forest
"""
    with open('Forest.sublime-syntax', 'w', encoding='utf-8') as f:
        f.write(syntax_yaml.strip())

    # 3. Forest.sublime-color-scheme
    scheme = {
        "name": "Forest Colors",
        "globals": {
            "background": COLOR_BG, "foreground": COLOR_WHITE, "caret": COLOR_WHITE,
            "line_highlight": "#2A2A2A", "selection": "#404040"
        },
        "rules": [
            {"scope": "forest.blue", "foreground": COLOR_BLUE},
            {"scope": "forest.purple", "foreground": COLOR_PURPLE},
            {"scope": "forest.yellow", "foreground": COLOR_YELLOW},
            {"scope": "constant.numeric.forest", "foreground": COLOR_WHITE},
            {"scope": "punctuation.terminator.forest", "foreground": COLOR_WHITE},
            {"scope": "string.quoted.forest", "foreground": "#A6E22E"}
        ]
    }
    with open('Forest.sublime-color-scheme', 'w', encoding='utf-8') as f:
        json.dump(scheme, f, indent=4)

    # 4. Preferences.sublime-settings
    settings = {
        "color_scheme": "Packages/User/Forest.sublime-color-scheme",
        "font_size": 11,
        "theme": "Default Dark.sublime-theme",
        "auto_complete_selector": "source.forest" # Critical for snippets to show
    }
    with open('Preferences.sublime-settings', 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4)

if __name__ == "__main__":
    process_data()
    print("Files created. Move them to Packages/User/")