#ifndef #PROJECTNAME#_H
#define #PROJECTNAME#_H

#ifdef #PROJECTNAME#_EXPORTS
#define #PROJECTNAME#_API __declspec(dllexport)
#else
#define #PROJECTNAME#_API __declspec(dllimport)
#endif

namespace PPLNS
{
  class #PROJECTNAME#_API #ProjectName# : public BaseClass
  {
  public:
    #ProjectName#(PPL* ppl);
    void AddToKeywordDictionary();
    bool Func#Method#(vector<string> parameters, string& result, Composite* node);
  
  };
  extern "C" void  #PROJECTNAME#_API  #ProjectName#_CreateInstance(PPL* ppl);
}
#endif
