#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  bool DataFrame::FuncClearColumns(vector<string> parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncClearColumns";

    try
    {
      if (parameters.size() < 1)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.ClearColumns (df_name)[(column)(column)...]",   func_name });
        return false;
      }

      if (parameters.empty())
        parameters.push_back("DF");


      string df_name = parameters[0];

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = comp_df->_children->size();
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      vector<string> columns_selected;

      if (parameters.size() > 1)
        columns_selected.assign(parameters.begin() + 1, parameters.end());

      //=============Test column names================
      if (!columns_selected.empty())
      {
        for (const string& cw : columns_selected)
        {
          bool b2 = false;
          for (int i = 0; i < columns_quantity; i++)
          {
            if ( (*(comp_df->_children))[i]->name == cw)
            {
              b2 = true;
              break;
            }
          }
          if (!b2)
          {
            printDlgt({"Error: [{0}] wrong column name [{1}]",  func_name, cw });
            return false;
          }
        }
      }
      //============================================
      for (int i = 1; i < columns_quantity; i++)
      {
        Component* c = (*(comp_df->_children))[i];
        if (dynamic_cast<Leaf*>(c))
        {
          printDlgt({"Warning: [{0}] DataFrame [{1}] var [{2}]) not usable",  func_name, df_name, c->name });
          continue;
        }

        Composite* comp_column = dynamic_cast<Composite*>(c);
        if (columns_selected.empty())
        {
          for (size_t j = 0; j < comp_column->_children->size(); j++)
            (*(comp_column->_children))[j]->value = "";
        }
        else
        {
          if(VectorContains(columns_selected, comp_column->name))
          {
            for (size_t j = 0; j < comp_column->_children->size(); j++)
            {
              (*(comp_column->_children))[j]->value = "";
            }
          }
        }
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true;
  }
}