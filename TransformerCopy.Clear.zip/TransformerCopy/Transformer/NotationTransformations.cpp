#include "NotationTransformations.h"
#include <stack>
#include <map>
#include <algorithm> // For std::reverse, std::remove_if
#include <cctype>    // For std::isspace, std::isalnum

// Define operator precedence for mathematical expressions (higher number means higher precedence)
static const std::map<char, int> mathPrecedence =
{
    {'+', 1}, {'-', 1},
    {'*', 2}, {'/', 2},
    {'^', 3} // Exponentiation (right-associative)
};

// Define operator precedence for logical and relational expressions
// NOT/! (highest) > Comparison (==, !=, <, >, <=, >=) > AND (&&) > OR (||), XOR (xor)
static const std::map<std::string, int> logicalPrecedence =
{
    {"||", 1}, {"xor", 1}, // OR and XOR
    {"&&", 2},              // AND
    {"==", 3}, {"!=", 3},   // Equality
    {"<", 4}, {">", 4},     // Relational
    {"<=", 4}, {">=", 4},   // Relational
    {"NOT", 5}, {"!", 5}    // Unary NOT
};


// Helper function to check if a character is a mathematical operator
bool NotationTransformations::isMathOperator(char c)
{
  return mathPrecedence.count(c);
}

// Helper function to get precedence of mathematical operators
int NotationTransformations::getMathPrecedence(char op)
{
  auto it = mathPrecedence.find(op);
  if (it != mathPrecedence.end())
  {
    return it->second;
  }
  return -1; // Not an operator or has no precedence
}

// Helper function to check if a string is a logical or relational operator
bool NotationTransformations::isLogicalOrRelationalOperator(const std::string& s)
{
  return logicalPrecedence.count(s);
}

// Helper function to get precedence of logical or relational operators
int NotationTransformations::getLogicalPrecedence(const std::string& op)
{
  auto it = logicalPrecedence.find(op);
  if (it != logicalPrecedence.end())
  {
    return it->second;
  }
  return -1; // Not an operator or has no precedence
}

// Helper for infix to prefix conversion with parentheses for every element
std::string NotationTransformations::infixToPrefixParenthesized(const std::string& infixExpression, bool isMath)
{
  std::string output_str = "";
  std::stack<std::string> opStack; // For operators
  std::stack<std::string> operandStack; // For operands and intermediate results

  // Trim whitespace and prepare for parsing
  std::string temp_expr = infixExpression;
  temp_expr.erase(std::remove_if(temp_expr.begin(), temp_expr.end(), ::isspace), temp_expr.end());

  // Loop through the expression.
  // This is a simplified tokenization. A full parser would use a lexical analyzer.
  for (int i = 0; i < temp_expr.length(); )
  {
    char c = temp_expr[i];
    std::string current_token_str = ""; // Declare current_token_str here

    if (c == '(')
    {
      opStack.push(std::string(1, c));
      i++;
    }
    else if (c == ')')
    {
      while (!opStack.empty() && opStack.top() != "(")
      {
        std::string op = opStack.top();
        opStack.pop();

        if (op == "NOT" || op == "!") // Unary NOT/!
        {
          if (operandStack.empty())
          {
            return "ERROR: Unary operator missing operand for " + op;
          }
          std::string operand = operandStack.top();
          operandStack.pop();
          operandStack.push("(" + op + " " + operand + ")");
        }
        else // Binary operator
        {
          if (operandStack.size() < 2)
          {
            return "ERROR: Binary operator missing operands for " + op;
          }
          std::string op2 = operandStack.top();
          operandStack.pop();
          std::string op1 = operandStack.top();
          operandStack.pop();
          operandStack.push("(" + op + " " + op1 + " " + op2 + ")");
        }
      }
      if (!opStack.empty() && opStack.top() == "(")
      {
        opStack.pop(); // Pop the '('
      }
      else
      {
        return "ERROR: Mismatched parentheses (closing without opening)";
      }
      i++;
    }
    else if (isMath && isMathOperator(c))
    {
      std::string current_op_str(1, c);
      while (!opStack.empty() && opStack.top() != "(" &&
        ((getMathPrecedence(opStack.top()[0]) > getMathPrecedence(c)) ||
          (getMathPrecedence(opStack.top()[0]) == getMathPrecedence(c) && c != '^'))) // Handle right-associativity for ^
      {
        std::string op = opStack.top();
        opStack.pop();
        if (operandStack.size() < 2)
        {
          return "ERROR: Binary operator missing operands for " + op;
        }
        std::string op2 = operandStack.top();
        operandStack.pop();
        std::string op1 = operandStack.top();
        operandStack.pop();
        operandStack.push("(" + op + " " + op1 + " " + op2 + ")");
      }
      opStack.push(current_op_str);
      i++;
    }
    else if (!isMath) // Logical and Relational expressions
    {
      // Attempt to match multi-character operators first (longest match)
      if (i + 1 < temp_expr.length()) // Check for two-character operators
      {
        std::string two_char_op = temp_expr.substr(i, 2);
        if (two_char_op == "&&") { current_token_str = "&&"; }
        else if (two_char_op == "||") { current_token_str = "||"; }
        else if (two_char_op == "==") { current_token_str = "=="; }
        else if (two_char_op == "!=") { current_token_str = "!="; }
        else if (two_char_op == "<=") { current_token_str = "<="; }
        else if (two_char_op == ">=") { current_token_str = ">="; }
      }

      if (!current_token_str.empty()) // Found a 2-char operator
      {
        i += current_token_str.length();
      }
      else // Check for one-character or keyword operators
      {
        if (c == '!')
        {
          current_token_str = "!";
          i++;
        }
        else if (c == '<')
        {
          current_token_str = "<";
          i++;
        }
        else if (c == '>')
        {
          current_token_str = ">";
          i++;
        }
        else if (i + 2 < temp_expr.length() && temp_expr.substr(i, 3) == "xor") // Keyword xor
        {
          current_token_str = "xor";
          i += 3;
        }
        else // Must be an operand
        {
          while (i < temp_expr.length() && (std::isalnum(temp_expr[i]) || temp_expr[i] == '_'))
          {
            current_token_str += temp_expr[i];
            i++;
          }
          operandStack.push("(" + current_token_str + ")"); // Wrap operand in parentheses
          continue; // Continue to next char after processing operand
        }
      }


      if (isLogicalOrRelationalOperator(current_token_str)) // It's an operator
      {
        while (!opStack.empty() && opStack.top() != "(" &&
          ((getLogicalPrecedence(opStack.top()) > getLogicalPrecedence(current_token_str)) ||
            (getLogicalPrecedence(opStack.top()) == getLogicalPrecedence(current_token_str) &&
              (current_token_str != "!" && current_token_str != "NOT")))) // !/NOT are unary/right-associative
        {
          std::string op = opStack.top();
          opStack.pop();

          if (op == "!" || op == "NOT") // Unary NOT
          {
            if (operandStack.empty())
            {
              return "ERROR: Unary operator missing operand for " + op;
            }
            std::string operand = operandStack.top();
            operandStack.pop();
            operandStack.push("(" + op + " " + operand + ")");
          }
          else // Binary
          {
            if (operandStack.size() < 2)
            {
              return "ERROR: Binary operator missing operands for " + op;
            }
            std::string op2 = operandStack.top();
            operandStack.pop();
            std::string op1 = operandStack.top();
            operandStack.pop();
            operandStack.push("(" + op + " " + op1 + " " + op2 + ")");
          }
        }
        opStack.push(current_token_str);
      }
      else // Should not happen if tokenization is correct, or it's an unrecognized token
      {
        return "ERROR: Unrecognized token: " + current_token_str;
      }
    }
    else // Operand for math (digits or numbers)
    {
      while (i < temp_expr.length() && (std::isalnum(temp_expr[i]) || temp_expr[i] == '.'))
      {
        current_token_str += temp_expr[i];
        i++;
      }
      operandStack.push("(" + current_token_str + ")"); // Wrap operand in parentheses
    }
  }

  // Pop remaining operators
  while (!opStack.empty())
  {
    std::string op = opStack.top();
    opStack.pop();

    if (op == "(")
    {
      return "ERROR: Mismatched parentheses (opening without closing)";
    }
    else if (op == "!" || op == "NOT") // Unary NOT
    {
      if (operandStack.empty())
      {
        return "ERROR: Unary operator missing operand for " + op;
      }
      std::string operand = operandStack.top();
      operandStack.pop();
      operandStack.push("(" + op + " " + operand + ")");
    }
    else // Binary operators
    {
      if (operandStack.size() < 2)
      {
        return "ERROR: Binary operator missing operands for " + op;
      }
      std::string op2 = operandStack.top();
      operandStack.pop();
      std::string op1 = operandStack.top();
      operandStack.pop();
      operandStack.push("(" + op + " " + op1 + " " + op2 + ")");
    }
  }

  if (operandStack.size() != 1)
  {
    return "ERROR: Malformed expression, remaining operands: " + std::to_string(operandStack.size());
  }

  return operandStack.top();
}


bool NotationTransformations::checkParenthesesBalance(const std::string& expression)
{
  int balance = 0;
  for (char c : expression)
  {
    if (c == '(')
    {
      balance++;
    }
    else if (c == ')')
    {
      balance--;
    }
    if (balance < 0) // Closing parenthesis without a matching opening one
    {
      return false;
    }
  }
  return balance == 0; // All parentheses matched
}

std::string NotationTransformations::Logical_InfixToParentheses(const std::string& infixExpression)
{
  return infixToPrefixParenthesized(infixExpression, false);
}

std::string NotationTransformations::Math_InfixToParentheses(const std::string& infixExpression)
{
  return infixToPrefixParenthesized(infixExpression, true);
}