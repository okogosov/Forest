#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Vector.h"

using namespace std;
namespace PPLNS
{
  static Vector* VECTORInstance = nullptr;
  void Vector_CreateInstance(PPL* ppl)
  {
    VECTORInstance = new Vector(ppl);
    VECTORInstance->AddToKeywordDictionary();
  }

  Vector::Vector(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Vector::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create",     FuncCreate);
    AddKeyword("Get",        FuncGet);
    AddKeyword("Set",        FuncSet);
    AddKeyword("Add",        FuncAdd);
    AddKeyword("Write",      FuncWrite);
    AddKeyword("WriteNames", FuncWriteNames);
    AddKeyword("Delete",     FuncDelete);
    AddKeyword("DeleteAll",  FuncDeleteAll);
    AddKeyword("Sort",       FuncSort);

    help_dict->insert({ "help", "\tVector.help([name])" });
    help_dict->insert({ "Create", "\tVector.Create(name)(length)(type)\r\n\ttype=double|float|decimal|bool|int|uint|long|ulong|string" });
    help_dict->insert({ "Get", "\tVector.Get(name)(index)" });
    help_dict->insert({ "Set", "\tVector.Set(name)(index)(value)" });
    help_dict->insert({ "Add", "\tVector.Add(vector_name)(ppl_array)" });
    help_dict->insert({ "Write", "\tVector.Write(vector_name)[(row)(col)(col0)]" });
    help_dict->insert({ "WriteNames", "\tVector.WriteNames()" });
    help_dict->insert({ "Delete", "\tVector.Delete(vector_name)" });
    help_dict->insert({ "DeleteAll", "\tVector.DeleteAll()" });
    help_dict->insert({ "Sort", "\tVector.Sort(vector_name)(ascend | descend)" });

    for (const auto pair : *keyword_dict)
    {
      string key = "Vector." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Vector", this });
  }
  //=========================================================
  bool Vector::GetVectorProperty(const string& name, string& type, int& length, int& index) 
  {
    auto it = vector_properties.find(name);
    if (it == vector_properties.end()) 
    {
      return false; // Key not found
    }
    VectorProperty& vp = it->second; // Get the VectorProperty
    type = vp.type;
    length = vp.length;
    index = vp.index;
    return true;
  }
  //=========================================================================================
  /*string Vector::to_lower(const string& input)
  {
    string output = input; // Create a copy of the input string
    transform(output.begin(), output.end(), output.begin(),
    [](unsigned char c) { return tolower(c); });
    return output; // Return the lowercase string
  }*/
  //=========================================================================================
  // <summary>
  /// 
  /// </summary>
  /// <param name="name"></param>
  /// <param name="length"></param>
  /// <param name="type = double|float|decimal|bool|int|uint|long|ulong|string"></param>
  /// <returns></returns>
 
  bool Vector::FuncCreate(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Vector.FuncCreate";

    if (parameters.size() != 3) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name});
      return false;
    }
    string err;
    try 
    {
      string name = parameters[0];
      if (vector_properties.find(name) != vector_properties.end()) 
      {
        if (ppl->Recreate == "yes")
        {
          err = "[" + function_name + "] vector[" + name + "] recreates";
          printDlgt({ "Warning: {0}",err });
          vector<string> param;
          param.push_back(name);
          this->FuncDelete(param,result,node);
        }
        else
        {
          err = "[" + function_name + "] vector[" + name + "] exists";
          printDlgt({"Error: {0}",err});
          return false;
        }
      }

      int length = 0;
      istringstream(parameters[1]) >> length;
      if (length <= 0) 
      {
        err = "[" + function_name + "] [" + parameters[0] + "] not a valid length [" + parameters[1] + "]";
        printDlgt({"Error: {0}",err});
        return false;
      }

      if (find(array_types.begin(), array_types.end(), parameters[2]) == array_types.end()) 
      {
        err = "[" + function_name + "] wrong type [" + parameters[2] + "]";
        printDlgt({"Error: {0}",err});
        return false;
      }

      VectorProperty vp;
      vp.type = parameters[2];
      vp.length = length;
      vp.index = 0;

      if (parameters[2] == "double") 
      {
        double_vectors.push_back(new double[length]);        
        vp.index = double_vectors.size() - 1;
        for (int i = 0; i < length; i++)    double_vectors[vp.index][i] = (double)0;
      }
      else if (parameters[2] == "float") 
      {
        float_vectors.push_back(new float[length]);
        vp.index = float_vectors.size() - 1;
        for (int i = 0; i < length; i++)    float_vectors[vp.index][i] = (float)0;
      }
      else if (parameters[2] == "decimal") 
      {
        decimal_vectors.push_back(new double[length]);
        vp.index = decimal_vectors.size() - 1;
        for (int i = 0; i < length; i++)    decimal_vectors[vp.index][i] = (double)0;
      }
      else if (parameters[2] == "bool") 
      {
        bool_vectors.push_back(new bool[length]);        
        vp.index = bool_vectors.size() - 1;
        for (int i = 0; i < length; i++)    bool_vectors[vp.index][i] = false;
      }
      else if (parameters[2] == "int") 
      {
        int_vectors.push_back(new int[length]);
        vp.index = int_vectors.size() - 1;
        for (int i = 0; i < length; i++)    int_vectors[vp.index][i] = (int)0;
      }
      else if (parameters[2] == "uint") 
      {
        uint_vectors.push_back(new unsigned int[length]);
        vp.index = uint_vectors.size() - 1;
        for (int i = 0; i < length; i++)    uint_vectors[vp.index][i] = (unsigned int)0;
      }
      else if (parameters[2] == "long") 
      {
        long_vectors.push_back(new long[length]);
        vp.index = long_vectors.size() - 1;
        for (int i = 0; i < length; i++)    long_vectors[vp.index][i] = (long)0;
      }
      else if (parameters[2] == "ulong") 
      {
        ulong_vectors.push_back(new uint64_t[length]);
        vp.index = ulong_vectors.size() - 1;
        for (int i = 0; i < length; i++)    ulong_vectors[vp.index][i] = (uint64_t)0;
      }
      else if (parameters[2] == "string")
      {
        string_vectors.push_back(new string[length]);
        vp.index = string_vectors.size() - 1;
        for (int i = 0; i < length; i++)    string_vectors[vp.index][i] = "";
      }

      vector_properties[name] = vp;

      if (ppl->debugppl == "yes") 
      {
        string tmp = "[" + function_name + "] vector [" + name + "] is created";
        printDlgt({ "Info: {0}", tmp });
      }
    }
    catch (const exception& e) 
    {
      printDlgt({ "Error: {0}", string(e.what()) });
      return false;
    }

    return true;
  }
  //========================================================================================
 /// <summary>
 /// 
 /// </summary>
 /// <param name="name"></param>
 /// <param name="index"></param>
 /// <returns>result</returns>
  bool Vector::FuncGet(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Vector.FuncGet";

    if (parameters.size() != 2) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    string vector_name = parameters[0];
    int ind_array = 0;
    string err;
    try 
    {
      string type;
      int length = 0;
      int index = 0;

      bool b = GetVectorProperty(vector_name, type, length, index);
      if (!b) 
      {
        printDlgt({ "Error: [{0}] vector [{1} does not exist]", function_name, vector_name });
        return false;
      }

      try 
      {
        ind_array = stoi(parameters[1]);
      }
      catch (const invalid_argument&) 
      {
        err = "Error: [" + function_name + "]  [" + vector_name + "] index is not a digital value [" + parameters[1] + "]";
        printDlgt({ "{0}",err });
        return false;
      }

      if (ind_array < 0 || ind_array >= length) 
      {
        err = "Error: [" + function_name + "] [" + vector_name + "] index [" + to_string(ind_array) + "] is out of bounds";
        printDlgt({"{0}", err});
        return false;
      }

      result.clear();
      if (type == "double") 
      {
        result = to_string(double_vectors[index][ind_array]);
      }
      else if (type == "float") 
      {
        result = to_string(float_vectors[index][ind_array]);
      }
      else if (type == "decimal") 
      {
        result = to_string(decimal_vectors[index][ind_array]);
      }
      else if (type == "bool") 
      {
        result = bool_vectors[index][ind_array] ? "True" : "False";
      }
      else if (type == "int") 
      {
        result = to_string(int_vectors[index][ind_array]);
      }
      else if (type == "uint") 
      {
        result = to_string(uint_vectors[index][ind_array]);
      }
      else if (type == "long") 
      {
        result = to_string(long_vectors[index][ind_array]);
      }
      else if (type == "ulong") 
      {
        result = to_string(ulong_vectors[index][ind_array]);
      }
      else if (type == "string") 
      {
        result = string_vectors[index][ind_array];
      }
    }
    catch (const exception&) 
    {
      printDlgt({"Error: [{0}] [{1}]", function_name, vector_name });
      return false;
    }

    return true;
  }
 //=========================================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <param name="name"></param>
  /// <param name="index"></param>
  /// <param name="value"></param>
  bool Vector::FuncSet(vector<string> parameters, string& result, Composite* node) 
  { 
    const string function_name = "Vector.FuncSet";
    string tmp = "";
    if (parameters.size() != 3) 
    {
      tmp = "Error: [" + function_name + "] wrong format";
      printDlgt({ "{0}",tmp });
      return false;
    }

    string vector_name = parameters[0];
    int ind_array = 0;

    try 
    {
      string type;
      int length = 0;
      int index = 0;

      bool b = GetVectorProperty(vector_name, type, length, index);
      if (!b) 
      {
        tmp = "Error: [" + function_name + "vector [" + vector_name + "] does not exist";
        printDlgt({ "{0}",tmp });
        return false;
      }

      try 
      {
        ind_array = stoi(parameters[1]);
      }
      catch (const invalid_argument&) 
      {
        tmp = "Error: [" + function_name, "]  [" + vector_name + "] not a digital value [" + parameters[1] + "]";
        printDlgt({ "{0}",tmp });
        return false;
      }

      if (ind_array < 0 || ind_array >= length) 
      {
        tmp = "Error: [" + function_name + "]  [" + vector_name + "] index [" + to_string(ind_array) + "] is out of bounds";
        printDlgt({ "{0}",tmp });
        return false;
      }

      if (type == "double") 
      {
        double_vectors[index][ind_array] = stod(parameters[2]);
      }
      else if (type == "float") 
      {
        float_vectors[index][ind_array] = stof(parameters[2]);
      }
      else if (type == "decimal") 
      {
        decimal_vectors[index][ind_array] = stold(parameters[2]); // long double for decimal
      }
      else if (type == "bool") 
      {
        string tmp = ToLower(parameters[2]);    // to_lower(parameters[2]);
        bool_vectors[index][ind_array] = (tmp == "true");
      }
      else if (type == "int") 
      {
        int_vectors[index][ind_array] = stoi(parameters[2]);
      }
      else if (type == "uint") 
      {
        uint_vectors[index][ind_array] = static_cast<unsigned int>(stoul(parameters[2]));
      }
      else if (type == "long") 
      {
        long_vectors[index][ind_array] = stoll(parameters[2]);
      }
      else if (type == "ulong") 
      {
        ulong_vectors[index][ind_array] = stoull(parameters[2]);
      }
      else if (type == "string") 
      {
        string_vectors[index][ind_array] = parameters[2];
      }
    }
    catch (const exception&) 
    {
      string tmp = function_name + "[" + vector_name + "] wrong value [" + parameters[2] + "]";
      printDlgt({ "{0}",tmp});
      return false;
    }
    return true; 
  }
  //=========================================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <param name="vector_name"></param>
  /// <param name="ppl_array_name"></param>
  /// <returns></returns>
  bool Vector::FuncAdd(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Vector.FuncAdd";
    string tmp;
    int index_arr = 0;   // for catch()

    if (parameters.size() != 2) 
    {
      printDlgt({ "Error: [0] wrong format", function_name});
      return false;
    }

    string vector_name = parameters[0];
    string ppl_array = parameters[1];

    try 
    {
      bool b = true;
      string type;
      int length = 0;
      int index = 0;

      b = GetVectorProperty(vector_name, type, length, index);
      if (!b) 
      {
        printDlgt({ "Error: [{0}] vector [{1}] does not exist", function_name, vector_name });
        return false;
      }

      string name, nodes;
      Composite* path = nullptr; 
      b = ppl->processing->GetPathAndNameFromGlobalLocal(function_name, ppl_array, path, nodes, name);
      if (!b) return false;

      Composite* node_array = nullptr;
      for (auto& c : *(path->_children))
      {
        if (c->name == name && dynamic_cast<Composite*>(c)) 
        {
          node_array = static_cast<Composite*>(c);
          break;
        }
      }

      if (!node_array) 
      {
        printDlgt({ "Error: [{0}] wrong ppl_array name[{1}]",function_name,name});
        return false;
      }

      for (int i = 0; i < node_array->_children->size(); i++) 
      {
        if (i >= length) 
        {  // Check bounds
          printDlgt({ "Warning: [{0} [ {1}] index [{2}] is out of bounds", function_name,vector_name,to_string(i)});
          return true;
        }
        tmp = (*(node_array->_children))[i]->value; 
        index_arr = i;

        if (type == "double") 
        {
          double_vectors[index][i] = stod(tmp);
        }
        else if (type == "float") 
        {
          float_vectors[index][i] = stof(tmp);
        }
        else if (type == "decimal") 
        {
          decimal_vectors[index][i] = stod(tmp); // long double for decimal
        }
        else if (type == "bool") 
        {
          tmp = ToLower(tmp); 
          bool_vectors[index][i] = (tmp == "true");
        }
        else if (type == "int") 
        {
          int_vectors[index][i] = stoi(tmp);
        }
        else if (type == "uint") 
        {
          uint_vectors[index][i] = (unsigned int)(stoul(tmp));
        }
        else if (type == "long") 
        {
          long_vectors[index][i] = stoll(tmp);
        }
        else if (type == "ulong") 
        {
          ulong_vectors[index][i] = stoull(tmp);
        }
        else if (type == "string") 
        {
          string_vectors[index][i] = tmp;
        }
      }
    }
    catch (const exception&) 
    {
      printDlgt({ "Error: [{0}] vector[{1}] index [{2}] wrong value[{" + tmp + "{3}]",
         function_name, vector_name, to_string(index_arr), tmp });
      return false;
    }

    return true; 
  }
  //=========================================================================================
  void Vector::Write(vector<string*> v, string print_mode)
  {
    string line;
    if (print_mode == "row")
    {
      for (const auto& str : v)
      {
        line += *(str);
        line += '\t';
      }
      printDlgt({ "{0}",line });
    }
    else
    {
      int j = 0;
      for (const auto& str : v)
      {
        if (print_mode == "col" && *(str) == "0") // Check for zero based on type
          continue;
        printDlgt({ "\t[{0}]\t{1}",to_string(j),*(str) });
        j++;
      }
    }
  }
  //=========================================================================================
  bool Vector::FuncWrite(vector<string> parameters, string& result, Composite* node)
  {
    const string function_name = "Vector.FuncWrite";
  
    if (parameters.size() != 1 && parameters.size() != 2) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    string print_mode = "row"; // Default to row
    string vector_name = parameters[0];
   
    if (parameters.size() == 2) 
    {
      if (parameters[1] == "row") print_mode = "row";
      else if (parameters[1] == "col") print_mode = "col";
      else if (parameters[1] == "col0") print_mode = "col0";
    }
    vector<string*> vstr;
    try 
    {
      bool b = true;
      string type;
      int length = 0;
      int index = 0;

      b = GetVectorProperty(vector_name, type, length, index);
      if (!b) 
      {
        printDlgt({ "Error: [{0}] vector [{1}] does not exist", function_name, vector_name });
        return false;
      }

      printDlgt({ "=====vector [{0}] =====", vector_name });
      if (type == "double")
      {
        double d;
        for (int i = 0; i < length; i++)
        {
          d = double_vectors[index][i];
          vstr.push_back(new string(Format(d)));
        } 
      }

      else if (type == "float")
      {
        float f;
        for (int i = 0; i < length; i++)
        {
          f = float_vectors[index][i];
          vstr.push_back(new string(Format(f)));
        }
      }

      else if (type == "decimal") 
      {
        double d;
        for (int i = 0; i < length; i++)
        {
          d = decimal_vectors[index][i];
          vstr.push_back(new string(Format(d)));
        }
      }       
       
      else if (type == "bool") 
      {
        bool b;
        for (int i = 0; i < length; i++)
        {
          b = bool_vectors[index][i];
          if(b)
            vstr.push_back(new string("true"));
          else
            vstr.push_back(new string("false"));
        }
      }      
       
      else if (type == "int") 
      {
        int i;
        for (int j = 0; j < length; j++)
        {
          i = int_vectors[index][j];
          vstr.push_back(new string(Format(i)));
        }
      }

      else if (type == "uint") 
      {
        unsigned int ui;
        for (int j = 0; j < length; j++)
        {
          ui = uint_vectors[index][j];
          vstr.push_back(new string(Format(ui)));
        }
      }

      else if (type == "long") 
      {
        long l;
        for (int j = 0; j < length; j++)
        {
          l = long_vectors[index][j];
          vstr.push_back(new string(Format(l)));
        }
      }

      else if (type == "ulong") 
      {
        uint64_t ui64;
        for (int j = 0; j < length; j++)
        {
          ui64 = ulong_vectors[index][j];
          vstr.push_back(new string(Format(ui64)));
        }
      }

      else if (type == "string") 
      {
        string str;
        for (int j = 0; j < length; j++)
        {
          str = string_vectors[index][j];
          vstr.push_back(new string(str));
        }
      }

      Write(vstr, print_mode);
      for (auto& d : vstr)
      {
        delete d;
        d = nullptr;
      }
      vstr.clear();
      return true;
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
   
    return true;
  }
  
  //=========================================================================================
  bool Vector::FuncWriteNames(vector<string> parameters, string& result, Composite* node) 
  { 
    const string function_name = "Vector.WriteNames";

    if (!parameters.empty()) 
    {
      printDlgt({"Error: [{0}] wrong format", function_name });
      return false;
    }

    try 
    {
      if (vector_properties.empty()) 
      {
        printDlgt({ "Warning: [{0}] vector_properties is empty",function_name});
      }
      else 
      {
        printDlgt({"====={0}=====", function_name });
        for (const auto& pair : vector_properties) 
        {
          //pair.second.index is index in vector_properties
          string tmp = pair.first + "\t" + pair.second.type + "\t" + to_string(pair.second.length) + "\t[" + to_string(pair.second.index) + "]";
          printDlgt({"{0}",tmp});
        }
      }
    }
    catch (const exception&) 
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
    return true; 
  }
  //=========================================================================================
  bool Vector::FuncDelete(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Vector.Delete";

    if (parameters.size() != 1) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    string vector_name = parameters[0];
    try 
    {
      string type;
      int length = 0;
      int index = 0;

      bool b = GetVectorProperty(vector_name, type, length, index);
      if (!b) 
      {
        printDlgt({ "Error: [{0}] vector [{1}] does not exist", function_name, vector_name });
        return false;
      }

      vector_properties.erase(vector_name);
      if (type == "double") 
      {
        delete[] double_vectors[index];
        double_vectors.erase(double_vectors.begin() + index);
      }
      else if (type == "float") 
      {
        delete[] float_vectors[index];
        float_vectors.erase(float_vectors.begin() + index);
      }
      else if (type == "decimal") 
      {
        delete[] decimal_vectors[index];
        decimal_vectors.erase(decimal_vectors.begin() + index);
      }
      else if (type == "bool") 
      {
        delete[] bool_vectors[index];
        bool_vectors.erase(bool_vectors.begin() + index);
      }
      else if (type == "int") 
      {
        delete[] int_vectors[index];
        int_vectors.erase(int_vectors.begin() + index);
      }
      else if (type == "uint") 
      {
        delete[] uint_vectors[index];
        uint_vectors.erase(uint_vectors.begin() + index);
      }
      else if (type == "long") 
      {
        delete[] long_vectors[index];
        long_vectors.erase(long_vectors.begin() + index);
      }
      else if (type == "ulong") 
      {
        delete[] ulong_vectors[index];
        ulong_vectors.erase(ulong_vectors.begin() + index);
      }
      else if (type == "string") 
      {
        delete[] string_vectors[index];
        string_vectors.erase(string_vectors.begin() + index);
      }
    }
    catch (const exception&) 
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
    return true; 
  }
  //=========================================================================================
  bool Vector::FuncDeleteAll(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Vector.DeleteAll";

    if (!parameters.empty()) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    try
    {
      if (vector_properties.empty())
      {
        {
          printDlgt({ "Warning: [{0}] vector_properties is empty", function_name });
          return true;
        }

        vector_properties.clear();

        for (auto& d : double_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        double_vectors.clear();

        for (auto& d : float_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        float_vectors.clear();

        for (auto& d : decimal_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        decimal_vectors.clear();

        for (auto& d : bool_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        bool_vectors.clear();

        for (auto& d : int_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        int_vectors.clear();

        for (auto& d : uint_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        uint_vectors.clear();

        for (auto& d : long_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        long_vectors.clear();

        for (auto& d : ulong_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }
        ulong_vectors.clear();

        for (auto& d : string_vectors)
        {
          if (d)
          {
            delete[] d;
            d = nullptr;
          }
        }

        string_vectors.clear();
      }
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] [{1}]" , function_name, ex.what()});
      return false;
    }
    return true; 
  }
  //====================================================================
  // FuncSort(name,order)   order = ascend | descend
  bool Vector::FuncSort(vector<string> parameters, string& result, Composite* node)
  {
    const string function_name = "Vector.FuncSort";
    if (parameters.size()!= 2)
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }
    string vector_name = parameters[0];
    string order = parameters[1];
    if ((order != "ascend") && (order != "descend"))
    {
      printDlgt({ "Error: [{0}] wrong order [{1}]", function_name, order });
      return false;
    }
    try
    {
      string type;
      int length = 0;
      int index = 0;
      bool b = GetVectorProperty(vector_name, type, length, index);
      if (!b)
      {
        printDlgt({ "Error: [{0}] vector [{1}] does not exist", function_name, vector_name });
        return false;
      }
      if (type == "double")
      {
        order == "ascend"
          ? sortArrayAscendingOrder<double>(double_vectors[index], length)
          : sortArrayDescendingOrder<double>(double_vectors[index], length);
      }     
      if (type == "float")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<float>(float_vectors[index], length)
        :  sortArrayDescendingOrder<float>(float_vectors[index], length);
      }
      if (type == "decimal")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<double>(decimal_vectors[index], length)
        :  sortArrayDescendingOrder<double>(decimal_vectors[index], length);
      }
      if (type == "bool")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<bool>(bool_vectors[index], length)
        :  sortArrayDescendingOrder<bool>(bool_vectors[index], length);
      }
      if (type == "int")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<int>(int_vectors[index], length)
        :  sortArrayDescendingOrder<int>(int_vectors[index], length);
      }
      if (type == "uint")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<unsigned int>(uint_vectors[index], length)
        :  sortArrayDescendingOrder<unsigned int>(uint_vectors[index], length);
      }
      if (type == "long")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<long>(long_vectors[index], length)
        :  sortArrayDescendingOrder<long>(long_vectors[index], length);
      }
      if (type == "ulong")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<uint64_t>(ulong_vectors[index], length)
        :  sortArrayDescendingOrder<uint64_t>(ulong_vectors[index], length);
      }
      if (type == "string")
      {
        order == "ascend"
        ?  sortArrayAscendingOrder<string>(string_vectors[index], length)
        :  sortArrayDescendingOrder<string>(string_vectors[index], length);
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]" , function_name, ex.what() });
      return false;
    }
    return true;
  }
}
