#include "pch.h"

#include "..\PPL\ppl.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"

#include "File.h"


using namespace std;
namespace PPLNS
{
  static File* FILEInstance = nullptr;

  void File_CreateInstance(PPL* ppl)
  {
    FILEInstance = new File(ppl);
    FILEInstance->AddToKeywordDictionary();
  }

  File::File(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void File::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("ReadAllText", FuncReadAllText);
    AddKeyword("WriteAllText", FuncWriteAllText);
    AddKeyword("ReadAllLines", FuncReadAllLines);
    AddKeyword("WriteAllLines", FuncWriteAllLines);
    AddKeyword("Exists", FuncExists);
    AddKeyword("Delete", FuncDelete);

    help_dict->insert({ "help",          "\tFile.help([name])" });
    help_dict->insert({ "ReadAllText",   "\tReturns all contents of text file: File.ReadAllText(filename)" });
    help_dict->insert({ "WriteAllText",  "\tCreates a new file, write the contents to the file, and then closes the file:\tWriteAllText(var_ppl)(filename)" });
    help_dict->insert({ "ReadAllLines",  "\tReturns string array with lines of text file: File.ReadAllLines(filename)(ppl_array)" });
    help_dict->insert({ "WriteAllLines", "\tCreates a new file, writes one or more strings to the file, and then closes the file: File.WriteAllLines(ppl_array)(filename)" });
    help_dict->insert({ "Exists",        "\tDetermines whether the specified file exists, returns True or False: File.Exists(filename)" });
    help_dict->insert({ "Delete",        "\tDeletes the specified file: File.Delete(filename)" });
    for (const auto pair : *keyword_dict)
    {
      string key = "File." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "File", this });
  }
  //=========================================================
  bool File::FuncReadAllText(vector<string> parameters, string& result, Composite* node)
  {
    // filename
    // output in result
    string func_name = "File.FuncReadAllLines";
    try 
    {
      if (parameters.size() != 1) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 1",func_name });
        return false;
      }

      // Read the file content
      ifstream file(parameters[0]);
      if (!file.is_open()) 
      {
        printDlgt({ "Error: [{0}] Unable to open file", func_name });
        return false;
      }

      result.assign((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
      file.close();

      // Modify result based on conditions
      if (!result.empty() && result[0] == '\"') 
      {
        result = "<" + result;
      }
      if (!result.empty() && result[result.length() - 1] == '\"') 
      {
        result += ">";
      }
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}]  [{1}]" , func_name, ex.what()});
      return false;
    }
    return true;
  }
  //=========================================================
  bool File::FuncWriteAllText(vector<string> parameters, string& result, Composite* node) 
  { 
    // var_ppl, filename
    string func_name = "FuncWriteAllText";
    try 
    {
      if (parameters.size() != 2) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 2",func_name });
        return false;
      }

      //===================================================
      string text = parameters[0];
      string filename = parameters[1];
      string name = "", nodes = "";
      Composite* path = nullptr; // Assuming Composite is defined elsewhere
      bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, text, path, nodes, name);
      if (!b) 
      {
        return false;
      }
      //===================================================

      /*
      Component* var_text = nullptr; 
      for (auto& c1 : *(path->_children)) 
      { 
          if (c1->name == name && dynamic_cast<Component*>(c1)) 
          {
              var_text = c1;
              break;
          }
      }
      if (var_text == nullptr) 
      {
          cerr << "Error: [" << func_name << "] wrong name [" << text << "]" << endl;
          return false;
      }

      if (var_text->value[0] == '<') 
      {
          var_text->value = var_text->value.substr(1);
      }
      if (var_text->value.back() == '>') 
      {
          var_text->value = var_text->value.substr(0, var_text->value.length() - 1);
      }
      ofstream outFile(filename);
      outFile << var_text->value;
      outFile.close();
      */

      // Write text to file
      ofstream outFile(filename);
      if (!outFile.is_open()) 
      {
        printDlgt({ "Error: [{0}] Unable to open file for writing",func_name });
        return false;
      }
      outFile << text;
      outFile.close();
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true; 
  }
  //=========================================================
  bool File::FuncReadAllLines(vector<string> parameters, string& result, Composite* node) 
  { // filename, ppl_array
    string func_name = "File.FuncReadAllLines";
    try
    {
      if (parameters.size() != 2) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 2" ,func_name });
        return false;
      }

      string filePath = parameters[0];
      string ppl_array_result = parameters[1];
      vector<string> arr_lines;

      // Read the file content
      ifstream file(filePath);
      if (!file.is_open()) 
      {
        printDlgt({"Error: [{0}] Unable to open file", func_name});
        return false;
      }

      string line;
      while (getline(file, line)) 
      {
        if (!line.empty() && line[0] == '\"') 
          line = "<" + line;
        if (!line.empty() && line[line.length() - 1] == '\"') 
          line += ">";
        arr_lines.push_back(line);
      }
      file.close();

      // Get path and name
      Composite* path = nullptr;
      string nodes, name;
      bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array_result, path, nodes, name);
      if (!b) return false;

      // Reallocate the array
      ppl->processing->FuncReAllocArray({ ppl_array_result, "", to_string(arr_lines.size()), "" }, result, node);
      
      // Update the values in the composite structure
      for (auto& child : *(path->_children)) 
      {
        if (child->name == ppl_array_result) 
        {
          for (size_t i = 0; i < arr_lines.size(); i++) 
          {
            Composite* c = (Composite*)child;
            (*(c->_children))[i]->value = arr_lines[i];
          }
        }
      }
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}]  [{1}]" , func_name, ex.what() });
      return false;
    }
 
  return true; 
  }
  //=========================================================
  /// <summary>
    /// 
    /// </summary>
    /// <parameters[0] array_ppl></param>
    /// <parameters[1] filename></param>
    /// <returns></returns>
  bool File::FuncWriteAllLines(vector<string> parameters, string& result, Composite* node) 
  {
    // ppl_array, filename
    string func_name = "FuncWriteAllLines";
    try 
    {
      if (parameters.size() != 2) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 2",func_name });
        return false;
      }

      //===================================================
      string text = parameters[0];
      string filename = parameters[1];
      string name = "", nodes = "";
      Composite* path = nullptr; // Assuming Composite is defined elsewhere
      bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, text, path, nodes, name);
      if (!b) 
      {
        return false;
      }
      //===================================================

      Composite* node_array_text = nullptr; // Assuming Composite is defined elsewhere
      for (auto& c2 : *(path->_children)) 
      { // Assuming GetChildren() returns a vector or similar
        if (c2->name == name && dynamic_cast<Composite*>(c2)) 
        {
          node_array_text = dynamic_cast<Composite*>(c2);
          break;
        }
      }
      if (node_array_text == nullptr) 
      {
        printDlgt({ "Error: [{0}] wrong name [{1}]",func_name,name });
        return false;
      }

      vector<string> contents_list;
      for (const auto& c : *(node_array_text->_children)) 
      { 
        string value = c->value;
        if (!value.empty() && value[0] == '<') 
        {
          value = value.substr(1);
        }
        if (!value.empty() && value.back() == '>') 
        {
          value = value.substr(0, value.length() - 1);
        }
        contents_list.push_back(value);
      }

      // Write to file
      ofstream outFile(filename);
      if (!outFile.is_open()) 
      {
        printDlgt({ "Error: [{0}] Unable to open file for writing",func_name });
        return false;
      }
      for (const auto& line : contents_list) 
      {
        outFile << line << NEW_LINE; // Write each line followed by a newline
      }
      outFile.close();
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name, ex.what()});
      return false;
    }
    return true; 
  }
  //=========================================================
  bool File::FuncExists(vector<string> parameters, string& result, Composite* node) 
  { 
    string func_name = "FuncWriteAllLines";
    try 
    {
      if (parameters.size() != 1) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 1",func_name});
        return false;
      }

      // Trim quotes if needed (optional)
      string filePath = parameters[0];
      if (!filePath.empty() && (filePath.front() == '\"' && filePath.back() == '\"')) 
      {
        filePath = filePath.substr(1, filePath.length() - 2);
      }

      // Check if the file exists
      bool exists = filesystem::exists(filePath);
      result = exists ? "True" : "False";
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=========================================================
  bool File::FuncDelete(vector<string> parameters, string& result, Composite* node) 
  { 
    string func_name = "FuncWriteAllLines";
    try 
    {
      if (parameters.size() != 1) 
      {
        printDlgt({ "Error: [{0}] wrong number of parameters != 1",func_name });
        return false;
      }

      string filePath = parameters[0];

      // Check if the file exists
      if (filesystem::exists(filePath)) 
      {
        filesystem::remove(filePath); // Delete the file
      }
      else 
      {
        printDlgt({ "Error: [{0}] wrong path or filename [{1}]",func_name, filePath });
        result = "False";
        return false;
      }
    }
    catch (const exception& ex) 
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name, ex.what() });
      result = "False";
      return false;
    }
    result = "True";
    return true; 
  }
}
