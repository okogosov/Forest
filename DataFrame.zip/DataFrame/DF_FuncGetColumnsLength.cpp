#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  bool DataFrame::FuncGetColumnsLength(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetColumnsLength";

    if (parameters.size() != 1)
    {
      printDlgt({"Error: [{0}] wrong format: DataFrame.FuncGetColumnsLength(DataFrame_name)", func_name});
      return false;
    }

    string df_name = parameters[0];

    try
    {
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      //vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          //ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      result = to_string(comp_df->_children->size() - 1); // without array Settings
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
  //==================================================================================================
  bool DataFrame::FuncGetColumnNames(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetColumnNames";
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [{0}] wrong format: DataFrame.FuncGetColumnNames(DataFrame_name)", func_name});
      return false;
    }
    string df_name = parameters[0];
    try
    {
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      result = join(*ptr_column_names, ",");
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
  //=========================================================================
  string DataFrame::join(const vector<string>& vec, const string& delimiter)
  {
    ostringstream oss;
    for (size_t i = 0; i < vec.size(); ++i)
    {
       oss << vec[i];
       if (i != vec.size() - 1)
         oss << delimiter;
    }
    return oss.str();;
  }
}