#ifndef STRING_H
#define STRING_H

#ifdef STRING_EXPORTS
#define STRING_API __declspec(dllexport)
#else
#define STRING_API __declspec(dllimport)
#endif

namespace PPLNS
{
  class STRING_API String : public BaseClass
  {
  public:
    String(PPL* ppl);
    void AddToKeywordDictionary();
    bool FuncCompare(vector<string> parameters, string& result, Composite* node);
    bool FuncConcat(vector<string> parameters, string& result, Composite* node);
    bool FuncContains(vector<string> parameters, string& result, Composite* node);
    bool FuncFormat(vector<string> parameters, string& result, Composite* node);
    bool FuncIndexOf(vector<string> parameters, string& result, Composite* node);
    bool FuncLastIndexOf(vector<string> parameters, string& result, Composite* node);
    bool FuncInsert(vector<string> parameters, string& result, Composite* node);
    bool FuncRemove(vector<string> parameters, string& result, Composite* node);
    bool FuncDeleteEndOfLine(vector<string> parameters, string& result, Composite* node);
    bool FuncReplace(vector<string> parameters, string& result, Composite* node);
    bool FuncSplit(vector<string> parameters, string& result, Composite* node);
    bool FuncSplitCsv(vector<string> parameters, string& result, Composite* node);
    bool FuncStartsWith(vector<string> parameters, string& result, Composite* node);
    bool FuncSubstring(vector<string> parameters, string& result, Composite* node);
    bool FuncToCharArray(vector<string> parameters, string& result, Composite* node);
    bool FuncToLower(vector<string> parameters, string& result, Composite* node);
    bool FuncToUpper(vector<string> parameters, string& result, Composite* node);
    bool FuncTrim(vector<string> parameters, string& result, Composite* node);
    bool FuncChar(vector<string> parameters, string& result, Composite* node);
  };
  extern "C" void STRING_API String_CreateInstance(PPL* ppl);
}
#endif
