#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Queue.h"

using namespace std;
namespace PPLNS
{
  static Queue* QUEUEInstance = nullptr;

  void Queue_CreateInstance(PPL* ppl)
  {
    QUEUEInstance = new Queue(ppl);
    QUEUEInstance->AddToKeywordDictionary();
  }

  Queue::Queue(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Queue::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Count", FuncCount);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Enqueue", FuncEnqueue);
    AddKeyword("Dequeue", FuncDequeue);
    AddKeyword("Peek", FuncPeek);
    AddKeyword("Clear", FuncClear);
    AddKeyword("Contains", FuncContains);
    AddKeyword("AddArray", FuncAddArray);
    AddKeyword("ToArray", FuncToArray);

    help_dict->insert({ "help", "\tQueue.help([name])" });
    help_dict->insert({ "Create", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    help_dict->insert({ "Count", "\t..." });
    help_dict->insert({ "Write", "\t..." });
    help_dict->insert({ "Enqueue", "\t..." });
    help_dict->insert({ "Dequeue", "\t..." });
    help_dict->insert({ "Peek", "\t..." });
    help_dict->insert({ "Clear", "\t..." });
    help_dict->insert({ "Contains", "\t..." });
    help_dict->insert({ "AddArray", "\t..." });
    help_dict->insert({ "ToArray", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Queue." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Queue", this });
  }
  //=========================================================
  bool Queue::FuncCreate(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncCount(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncWrite(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncEnqueue(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncDequeue(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncPeek(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncClear(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncContains(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncAddArray(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Queue::FuncToArray(vector<string> parameters, string& result, Composite* node) { return true; }
}
