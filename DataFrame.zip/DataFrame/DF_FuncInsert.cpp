#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  /// <summary>
      /// 
      /// </summary>
      /// <param name="df_name"></param>
      /// <param name="index"></param>
      /// <param name="[count = 1]"></param>
      /// <returns></returns>
  bool DataFrame::FuncInsertRows(const vector<string>& parameters_inp, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncInsertRows";
    string err;
    string df_name;
    try
    {
      if ((parameters_inp.size() != 3) && (parameters_inp.size() != 2))
      {
        err = "[" + func_name + "] wrong parameter, format: DataFrame.InsertRows (DataFrame_name)(index)[(number)]";
        printDlgt({ "Error: {0}", err });
        return false;
      }
      vector<string> parameters = parameters_inp;
      if (parameters.size() == 2)
      {
        parameters.push_back("1");
      }
      //=========================================================
      df_name = parameters[0];
      string strLength = "";

      bool b = false;
      string strIndex = "";
      int Index = 0;
      strIndex = parameters[1];
      b = TryParse(strIndex, Index);
      if (b == false)
      {
        err = "[" + func_name + "] [" + df_name + "] index not digital [" + strIndex + "]";
        printDlgt({ "Error: {0}", err });
        return false;
      }

      string strNumberInsertedRows = parameters[2];
      int NumberInsertedRows = 0;
      b = TryParse(strNumberInsertedRows, NumberInsertedRows);
      if (b == false)
      {
        err = "[" + func_name + "] [" + df_name + "] length not digital [" + strNumberInsertedRows + "]";
        printDlgt({ "Error: {0}", err });
        return false;
      }

      Composite* comp_df = GetDataFrameComposite(df_name);
      if (comp_df == nullptr)
      {
        err = "[" + func_name + "] wrong DataFrame name [" + df_name + "]";
        printDlgt({ "Error: {0}", err });
        return false;
      }
      Composite* comp_settings = GetSettingsComposite(comp_df);
      int Length = 0;
      if (comp_settings == nullptr)
      {
        err = "[" + func_name + "] wrong DataFrame name [" + df_name + "]";
        printDlgt({ "Error: {0}", err });
        return false;
      }
      Component* compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");

      if (compRowsLength == nullptr)
      {
        err = "[" + func_name + "] RowsLength is omitted in [" + df_name + "].Settings";
        printDlgt({ "Error: {0}", err });
        return false;
      }
      TryParse(compRowsLength->value,Length);
      int new_length = Length + NumberInsertedRows;
      Composite* compTmp = nullptr;
      for (int i = 1; i < comp_df->_children->size(); i++)
      {
        (*(comp_df->_children))[i]->value = "Array " + to_string(new_length);
        for (int j = Index; j < NumberInsertedRows + 1; j++)
        {
          compTmp = (Composite*)(*(comp_df->_children))[i];
          compTmp->Insert(j, new Leaf("#"));
        }
      }
      compRowsLength->value = to_string(new_length);
    }
    catch (const exception& ex)
    {
      err = "[" + func_name + "]";
      printDlgt({ "Error: {0}", err });
      return false;
    }
    return true;
  }
  //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="df_name"></param>
    /// <param name="InsertBeforeColumn"></param>   
    /// <param name="Column1"></param>
    /// <param name="Column2"></param>
    /// <param name="..."></param>
    /// <returns></returns>
    /// 
  bool DataFrame::FuncInsertColumns(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncInsertColumns";
    string err;
    try
    {
      if (parameters.size() < 3)
      {
        err = "[" + func_name + "] wrong parameter, format: DataFrame.FuncInsertColumns (df_name)(InsertBeforeColumn)(column name1)(column name2)...";
        printDlgt({ "Error: {0}", err });
        return false;
      }

      string df_name = parameters[0];
      string InsertBeforeColumn = parameters[1];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for(int i = 0;i < table_names.size();i++)
      {
        if (table_names[i].name == df_name)
        {
          comp_df = table_names[i].comp_df;
          comp_settings = table_names[i].comp_settings;
          ptr_column_names = &(table_names[i].column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = comp_df->_children->size();
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      TryParse(strLength,Length);
      //====================================================
      string output = "     ";
      vector<string> columns_selected(parameters.begin() + 2, parameters.end());

      //=============Test column names================
      bool b3 = false;
      int IndexInsertBeforeColumn = 0;
      //for (auto c : comp_df->_children)
      for(int i = 0;i < comp_df->_children->size();i++)
      {
        Component* c = (*(comp_df->_children))[i];
        if (InsertBeforeColumn == c->name)
        {
          b3 = true;
          break;
        }
        IndexInsertBeforeColumn++;
      }

      if (!b3)
      {
        err = "[" + func_name + "] [" + df_name + "] wrong InsertBeforeColumn name [" + InsertBeforeColumn + "]";
        return false;
      }

      for (const string& cw : columns_selected)
      {
        bool b2 = false;
        for (int i = 0; i < columns_quantity; i++)
        {
          if ( (*(comp_df->_children))[i]->name == cw)
          {
            err = "[" + func_name + "] [" + df_name + "] column name [" + cw + "] exists";
            printDlgt({ "Error: {0}", err });
            return false;
          }
        }
      }
      //=====================================
      string tmp_result = "";
      string settings = parameters[0] + "." + "Settings";
      for (int i = 2; i < parameters.size(); i++)
      {
        tmp_result = "";
        string name = parameters[i];
        ppl->processing->FuncCreateVariables({ settings + "." + parameters[i] + "Type", "Text" }, tmp_result, node);
        ppl->processing->FuncCreateVariables({ settings + "." + parameters[i] + "Width", "12" }, tmp_result, node);
        Composite* new_array = new Composite(name, "Array " + strLength);
        new_array->nesting = comp_df->nesting + 1;

        for (int j = 0; j < Length; j++)
        {
          new_array->Add(new Leaf("#", ""));
        }

        comp_df->Insert(IndexInsertBeforeColumn, new_array);
        IndexInsertBeforeColumn++;

        if (ppl->Local_dns->empty())
        {
          vector<PPL::DataNameStruct>* ptr = ppl->Global_dns;
          ppl->Global->RefreshDataNameStructure(ppl, *ptr, ppl->Global);
        }
        else
        {
          PPL::LocalDataNameStruct* local_dns = ppl->Local_dns->top();
          local_dns->scope_node->RefreshDataNameStructure(ppl, local_dns->dns, local_dns->scope_node);
        }
      }

      ptr_column_names->clear();
      for (auto*& c : *(comp_df->_children))
      {
        if (c->name == "Settings")
          continue;
        ptr_column_names->push_back(c->name);
      }
    }
    catch (const exception& ex)
    {
      err = "[" + func_name + "]";
      printDlgt({ "Error: {0}", err });
      return false;
    }
    /*
     catch (const exception& ex)
  {
    printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
    return false;
  }
    */
    return true;
  }

}