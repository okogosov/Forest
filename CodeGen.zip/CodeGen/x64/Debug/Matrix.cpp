#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Matrix.h"

using namespace std;
namespace PPLNS
{
  static Matrix* MATRIXInstance = nullptr;

  void Matrix_CreateInstance(PPL* ppl)
  {
    MATRIXInstance = new Matrix(ppl);
    MATRIXInstance->AddToKeywordDictionary();
  }

  Matrix::Matrix(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Matrix::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Get", FuncGet);
    AddKeyword("Set", FuncSet);
    AddKeyword("AddArrayToRow", FuncAddArrayToRow);
    AddKeyword("AddArrayToColumn", FuncAddArrayToColumn);
    AddKeyword("Write", FuncWriteNames);
    AddKeyword("WriteNames", FuncWriteNames);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("DeleteAll", FuncDeleteAll);
    AddKeyword("Rotate", FuncRotate);

    help_dict->insert({ "help", "\tMatrix.help([name])" });
    help_dict->insert({ "Create", "\t..." });
    help_dict->insert({ "Get", "\t..." });
    help_dict->insert({ "Set", "\t..." });
    help_dict->insert({ "AddArrayToRow", "\t..." });
    help_dict->insert({ "AddArrayToColumn", "\t..." });
    help_dict->insert({ "Write", "\t..." });
    help_dict->insert({ "WriteNames", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    help_dict->insert({ "DeleteAll", "\t..." });
    help_dict->insert({ "Rotate", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Matrix." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Matrix", this });
  }
  //=========================================================
  bool Matrix::FuncCreate(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncGet(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncSet(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncAddArrayToRow(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncAddArrayToColumn(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncWrite(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncWriteNames(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncDeleteAll(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Matrix::FuncRotate(vector<string> parameters, string& result, Composite* node) { return true; }
}
