#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "String.h"

using namespace std;
namespace PPLNS
{
  static String* STRINGInstance = nullptr;

  void String_CreateInstance(PPL* ppl)
  {
    STRINGInstance = new String(ppl);
    STRINGInstance->AddToKeywordDictionary();
  }

  String::String(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void String::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Compare", FuncCompare);
    AddKeyword("Concat", FuncConcat);
    AddKeyword("Contains", FuncContains);
    AddKeyword("Format", FuncFormat);
    AddKeyword("IndexOf", FuncIndexOf);
    AddKeyword("LastIndexOf", FuncLastIndexOf);
    AddKeyword("Insert", FuncInsert);
    AddKeyword("Remove", FuncRemove);
    AddKeyword("DeleteEndOfLine", FuncDeleteEndOfLine);
    AddKeyword("Replace", FuncReplace);
    AddKeyword("Split", FuncSplit);
    AddKeyword("SplitCsv", FuncSplitCsv);
    AddKeyword("StartsWith", FuncStartsWith);
    AddKeyword("Substring", FuncSubstring);
    AddKeyword("ToCharArray", FuncToCharArray);
    AddKeyword("ToLower", FuncToLower);
    AddKeyword("ToUpper", FuncToUpper);
    AddKeyword("Trim", FuncTrim);
    AddKeyword("Char", FuncChar);

    help_dict->insert({ "help", "\tString.help([name])" });
    help_dict->insert({ "Compare", "\t..." });
    help_dict->insert({ "Concat", "\t..." });
    help_dict->insert({ "Contains", "\t..." });
    help_dict->insert({ "Format", "\t..." });
    help_dict->insert({ "IndexOf", "\t..." });
    help_dict->insert({ "LastIndexOf", "\t..." });
    help_dict->insert({ "Insert", "\t..." });
    help_dict->insert({ "Remove", "\t..." });
    help_dict->insert({ "DeleteEndOfLine", "\t..." });
    help_dict->insert({ "Replace", "\t..." });
    help_dict->insert({ "Split", "\t..." });
    help_dict->insert({ "SplitCsv", "\t..." });
    help_dict->insert({ "StartsWith", "\t..." });
    help_dict->insert({ "Substring", "\t..." });
    help_dict->insert({ "ToCharArray", "\t..." });
    help_dict->insert({ "ToLower", "\t..." });
    help_dict->insert({ "ToUpper", "\t..." });
    help_dict->insert({ "Trim", "\t..." });
    help_dict->insert({ "Char", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "String." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "String", this });
  }
  //=========================================================
  bool String::FuncCompare(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncConcat(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncContains(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncFormat(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncIndexOf(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncLastIndexOf(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncInsert(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncRemove(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncDeleteEndOfLine(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncReplace(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncSplit(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncSplitCsv(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncStartsWith(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncSubstring(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncToCharArray(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncToLower(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncToUpper(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncTrim(vector<string> parameters, string& result, Composite* node) { return true; }
  bool String::FuncChar(vector<string> parameters, string& result, Composite* node) { return true; }
}
