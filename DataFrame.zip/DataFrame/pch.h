// pch.h: This is a precompiled header file.
// Files listed below are compiled only once, improving build performance for future builds.
// This also affects IntelliSense performance, including code completion and many code browsing features.
// However, files listed here are ALL re-compiled if any one of them is updated between builds.
// Do not add files here that you will be updating frequently as this negates the performance advantage.

#ifndef PCH_H
#define PCH_H

// add headers that you want to pre-compile here
#include <iostream>
#include <cassert>
#include <format>
#include <string>
#include <sstream>
#include <cstdarg>
#include <iterator>
#include <list>
#include <typeinfo>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <vector>
#include <queue>
#include <deque>
#include <typeinfo>
#include <fstream>
#include <regex>
#include <direct.h>
#include <exception>
#include <cmath>
#include <thread>
//#include <mutex>
#include <ctime>
//#include <future>
//#include <ratio>
#include <chrono>

#include <algorithm>
#include <regex>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <cstdlib>
#include <numeric>
#include <functional>
#include "framework.h"
#include <Windows.h>
#include <stdexcept>
//#include <memory>
#include <type_traits>
//#include <execution>

/*
#ifdef _WIN32
    #include <direct.h>
    #define getcwd _getcwd 
#elif
    #include <unistd.h>
*/
#endif //PCH_H
