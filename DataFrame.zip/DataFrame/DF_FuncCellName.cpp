#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  // df,column,row,cell_name
  bool DataFrame::FuncCellName(const vector<string>& parametersInput, string& result, Composite* node)
  {
    const string func_name = "DataFrame.FuncCellName";
    string err;

    // Check parameters count
    if ((parametersInput.size() != 4) && (parametersInput.size() != 3))
    {
      err = "[" + func_name + "] wrong format: DataFrame.CellName[(DataFrame_name)](column)(row)(cell_name)";
      printDlgt({ "Error: {0}",err });
      return false;
    }
    vector<string> parameters = parametersInput;
    string df_name = parameters[0];
    try
    {  
      if (parameters.size() == 4)
        df_name = parameters[0];
      else
      {
        vector<string> tokens = SplitString(parameters[0], '.');
        if (tokens.size() != 2)
        {
          err = "[" + func_name + "] omitted '.' wrong format: DataFrame.GetCell(df.cell_name)";
          printDlgt({ "Error: {0}",err });
          return false;
        }
        parameters.erase(parameters.begin());
        parameters.insert(parameters.begin(), tokens[0]);
        parameters.insert(parameters.begin() + 1, tokens[1]);
        df_name = parameters[0];
      }

      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      TableName* ptr_table_name = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          ptr_table_name = &tn;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] not digital RowsLength [" + str_RowsLength + "]";
        return false;
      }
      int row = 0;
      b = TryParse(parameters[2], row);

      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row not digital [" + parameters[2] + "]";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      if ((row < 0) || (row >= RowsLength))
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row [" + parameters[2] + "] out of bounds";
        printDlgt({ "Error: {0}",err });
        return false;
      }
      CellAddress caddress(parameters[1], row);
  
      string cell_name = parameters[3];
      pair<string, CellAddress> ca(cell_name, caddress);
      if (ptr_table_name->cell_addresses.contains(cell_name))
      {
        printDlgt({ "Warning: [{0}] DataFrame [{1}] cell_name [{2}] is changed", func_name, df_name, cell_name});
        ptr_table_name->cell_addresses.erase(cell_name);
      }
      ptr_table_name->cell_addresses.insert(ca);         
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
}