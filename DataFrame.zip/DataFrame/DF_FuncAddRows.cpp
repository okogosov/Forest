#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  //==========================================================
  /// <summary>
  /// 
  /// </summary>
  /// <param name="[df_name=DF]"></param>
  /// <param name=["number=10]"></param>
  /// <returns></returns>
  bool DataFrame::FuncAddRows(const vector<string>& parameters_inp, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncAddRows";
    try
    {
      vector<string> parameters = parameters_inp;
      if (parameters.empty())
      {
        parameters.push_back("DF");
        parameters.push_back("10");
      }

      string df_name = parameters[0];
      string strLength = "";
      int Length = 0;
      Composite* cTmp = nullptr;
      bool b = false;
      if (parameters.size() == 2)
      {
        strLength = parameters[1];
        if (!TryParse(strLength,Length))
        {
          printDlgt({ "Error: [{0}] [{1}] not digital [{2}]", func_name ,df_name, strLength });
          return false;
        }
      }
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      if (parameters.size() == 1)
      {
        string strReallocIncrement = GetSettingsValue(comp_settings, "ReallocIncrement");
  
          if (!TryParse(strReallocIncrement, Length))
          {
            printDlgt({"Error: [{0}] wrong ReallocIncrement [{1}]", func_name,strReallocIncrement });
            return false;
          }
      }
      printDlgt({"DataFrame [{0}] added [{1}] rows", df_name ,to_string(Length) });

      Composite* compRowsLength = (Composite*)GetComponentSettingsByName(comp_settings, "RowsLength");
      if (compRowsLength == nullptr)
      {
        printDlgt({"Error: [{0}] RowsLength is omitted in [{1}].Settings", func_name,df_name});
        return false;
      }

      int new_length;  
      if (!TryParse(compRowsLength->value,new_length))
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowsLength is not digit", func_name,df_name });
        return false;
      }
      new_length += Length;
      for (size_t i = 1; i < comp_df->_children->size(); i++)
      {
        (*(comp_df->_children))[i]->value = "Array " + to_string(new_length);
        for (int j = 0; j < Length; j++)
        {
          Leaf* leaf = new Leaf("#","");
          cTmp = (Composite*)(*(comp_df->_children))[i];
          cTmp->Add(leaf);
        }
      }
      cTmp = (Composite*)(*(comp_df->_children))[1];
      compRowsLength->value = to_string(cTmp->_children->size());
      string tmp_result = "";
      //ppl->processing->FuncDisplayNodes({ parameters[0] }, tmp_result, node);
    }
    catch (const exception& ex)
    {
      printDlgt({"Error: [{0}] [{1}]", func_name,ex.what() });
      return false;
    }
    return true;
  }
  //==========================================================
 /// <summary>
     /// 
     /// </summary>
     /// <param name="df_name"></param>
     /// <param name="column1"></param>
     /// <param name="column2"></param>
     /// <param name="....."></param>
     /// <returns></returns>
     /// 
  bool DataFrame::FuncAddColumns(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "FuncAddColumns";
    try
    {
      if (parameters.size() < 2)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.FuncAddColumns (df_name)(column name1)(column name2)...", func_name});
        return false;
      }

      string df_name = parameters[0];
      if (ppl->IsDigitsOnly(parameters[1]))
      {
        printDlgt({"Error: [{0}] wrong column name [{1}]", func_name, parameters[1]});
        return false;
      }

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = comp_df->_children->size();
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      //====================================================
      string output = "     ";
      vector<string> columns_selected;

      if (parameters.size() > 1)
      {
        columns_selected.resize(parameters.size() - 1);
        for (size_t i = 1; i < parameters.size(); i++)
        {
          columns_selected[i - 1] = parameters[i];
        }
      }
      //=============Test column names================
      for (const string& cw : columns_selected)
      {
        for (int i = 0; i < columns_quantity; i++)
        {
          if ( (*(comp_df->_children))[i]->name == cw)
          {
            printDlgt({"Error: [{0}] [{1}] column name [{2}] exists", func_name, df_name, cw });
            return false;
          }
        }
      }
      //=====================================
      string tmp_result = "";
      string settings = parameters[0] + ".Settings";
      for (size_t i = 1; i < parameters.size(); i++)
      {
        tmp_result = "";
        string name = df_name + "." + parameters[i];

        ppl->processing->FuncCreateVariables({ settings + "." + parameters[i] + "Type", "Text" }, tmp_result, node);
        ppl->processing->FuncCreateVariables({ settings + "." + parameters[i] + "Width", "12" }, tmp_result, node);
        ppl->processing->FuncCreateArray({ name, strLength }, tmp_result, node);
      }
      ptr_column_names->clear();
      for (auto*& c : *(comp_df->_children))
      {
        if (c->name == "Settings")
          continue;
        ptr_column_names->push_back(c->name);
      }
    }
    catch (const exception& ex)
    {
      printDlgt({"Error: [{0}]  [{1}]", func_name ,ex.what()});
      return false;
    }
    return true;
  }
}