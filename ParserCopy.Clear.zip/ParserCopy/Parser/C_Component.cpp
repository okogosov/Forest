#include <iomanip>
#include <ios>
#include <iostream>
#include "Component.h"

namespace PPLNS
{
  //================================================================
  Component::Component(string _name, string _value = "")
  {
    this->name = _name;
    this->value = _value;
    this->LeafIndex = 0;
    this->parent = nullptr;
  }   
  //================================================================
  Leaf::Leaf(string _name, string _value) : Component(_name, _value)
  {
     constant = false;
     LeafIndex = 0;
     //cout << "  Leaf allocated " << _name << endl;
  }  
  //================================================================
  Leaf::~Leaf()
  {
    //cout << "  Leaf deleted " << name << endl;
  }
  //================================================================
  bool Leaf::Remove(Component* component)
  {
    //std::cout << "Cannot remove from a Leaf" << std::endl;
    return true;
  }
  //================================================================
  void Leaf::Display( int depth, bool only_nodes )
  {
    if (only_nodes)
      return;
    string offset(depth, '-');
    int LeafIndex = parent->leafNumberToDisplay;
    if (value == "")
    {
       cout << offset << "L\t"
        << setw(5) << LeafIndex << "\t"
        << setw(15) << name << "\t"
        << addit_info << endl;
    }
    else
    {
       cout << offset << "L\t"
        << setw(5) << LeafIndex << "\t"
        << setw(15) << name << "\t"
        << setw(15) << value << "\t"
        << addit_info << endl;

    }
  }

  //================================================================
  Composite::Composite(string _name, string _value) : Component(_name, _value)
  {    
    _children = new vector<Component*>;
    nesting = 0;     
    number_component = 0;  
    leafNumberToDisplay = 0;
    LeafIndex = 0;
    if (name == "root")
      nesting = 0;   
  }
  Composite::~Composite() 
  {   
    DeleteAllSuccessors();
    delete _children;
    ClearStack(ChildrenResults);
   
  }
  //================================================================
  void Composite::DeleteAllSuccessors()
  {
    for (Component* c : *_children)
    {
      if (typeid(*c) == typeid(Composite))
      {
        static_cast<Composite*>(c)->DeleteAllSuccessors();
      }
      delete c;
    }
    _children->clear();
  }
  //================================================================
  vector<Component*>* Composite::GetChildren()
  {
    return this->_children;
  }
  //================================================================
  void Composite::Display( int depth, bool only_nodes)
  {
    string offset(depth, '-');
    if (value == "")
      cout << offset << "N\t"
      << setw(5) << to_string(nesting) << "\t"
      << setw(15) << name << "\t"
      << endl;

    else
      cout << offset << "N\t"
      << setw(5) << to_string(nesting) << "\t"
      << setw(15) << name << "\t"
      << value << endl;

    leafNumberToDisplay = 0;
    for (int i = 0; i < _children->size(); i++)
    {
      Component* c = (*_children)[i];
      c->Display(depth + 2, only_nodes);
      if (dynamic_cast<Leaf*>(c))
        leafNumberToDisplay++;
    }
  }
  //================================================================
  Component* Composite::First()
  {
    if (_children->size() != 0)
      return *(_children->begin());
    else
      return nullptr;
  }
  //================================================================
  Component* Composite::Last()
  {
    if (_children->size() != 0)
      return *(_children->end() - 1);
    else
      return nullptr;
  }
  //================================================================
  void Composite::Add(Component* c)
  {
    _children->push_back(c);
    c->parent = this;
    if (dynamic_cast<Leaf*>(c))
      c->LeafIndex = LeafIndex++;
    else
      ((Composite*)c)->nesting = this->nesting + 1;
  }
  //================================================================
  bool Composite::Remove(Component* component)
  {
    auto it = find(_children->begin(), _children->end(), component);
    if (it == _children->end()) 
    {
      return false;
    }
    LeafIndex--;
    _children->erase(it);
    delete component;
    return true;
  }
  //================================================================
  void Composite::Clear()
  {
    LeafIndex = 0;
    _children->clear();
  }
  //================================================================
  bool Composite::Insert(int index, Component* component)
  {
    if (index >= _children->size())
      return false;
    if (dynamic_cast<Leaf*>(component))
      LeafIndex++;
    _children->insert(_children->begin() + index, component);
     component->parent = this;
    return true;
  }
  //================================================================
  void Composite::SetNesting()
  {
    if (parent == nullptr)
      nesting = 1;
    else
      nesting = parent->nesting + 1;
 
    for (Component* component : *(_children)) 
    {
      if (dynamic_cast<Leaf*>(component))
        continue;
      dynamic_cast<Composite*>(component)->SetNesting();
    }
  }
  //================================================================
  Component* Composite::FindEmptyLeaf(Component* TmpComp, string& node_name)
  {
    if (node_name == "")
    {
      node_name = this->name;
      TmpComp = nullptr;
    }
    // Recursively display child nodes
    for(int i = 0;i < _children->size();i++)
    {
      Component* component = (*_children)[i];
      if (dynamic_cast<Leaf*>(component))
      {
        Leaf* cl = (Leaf*)component;
        if (cl->name == "")
        {
          if (cl->LeafIndex == 0)     // only first leaf may be empty
            continue;
          TmpComp = (Component*)cl;
          break;
        }
      }
      else
      {
        Composite* cc = (Composite*)component;
        node_name = cc->name;
        cc->FindEmptyLeaf(TmpComp, node_name);
      }
    }
    return TmpComp;
  }
  Composite* Composite::GetCmdRoot(Composite* CmdRoot)
  {
    if (parent == nullptr)
      return nullptr;
    if (parent->name == "root")
    {
      CmdRoot = (Composite*)parent;
      return CmdRoot;
    }
    else
      ((Composite*)parent)->GetCmdRoot(CmdRoot);
    return CmdRoot;
  }
  //================================================================
  void Composite::GetNodes(string& fullPredecessorName, int nesting0, vector<string>& nodes_names_list)
  {
    // Initialize names and nodes_names_list if they are empty
    if (nodes_names_list.empty())
    {
      fullPredecessorName = "";
    }
    if (this->nesting == nesting0)
    {
      fullPredecessorName += parent->name;
      string fullname = fullPredecessorName + "." + name;
      fullPredecessorName += ".";
      string fpn = this->Get_FullPathName();
      if (StringContains(fpn,"NS.Global."))
        fpn = fpn.substr(10);
      if (StringContains(fpn,"NS.Local."))
        fpn = fpn.substr(9);
      nodes_names_list.push_back(fpn);
      return;
    }
    for(auto& component : *(_children))
    {
      if (dynamic_cast<Leaf*>(component) != nullptr)
        continue;
      ((Composite*)component)->GetNodes(fullPredecessorName, nesting0, nodes_names_list);
    }
    vector<string> tmp = SplitString(fullPredecessorName, '.');
    fullPredecessorName = "";
    for (int i = 0; i < tmp.size() - 1; i++)
      fullPredecessorName += tmp[i] + ".";
  }
}