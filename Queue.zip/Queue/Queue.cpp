#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Queue.h"

using namespace std;
namespace PPLNS
{
  static Queue* QUEUEInstance = nullptr;

  void Queue_CreateInstance(PPL* ppl)
  {
    QUEUEInstance = new Queue(ppl);
    QUEUEInstance->AddToKeywordDictionary();
  }

  Queue::Queue(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void Queue::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Count", FuncCount);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Enqueue", FuncEnqueue);
    AddKeyword("Dequeue", FuncDequeue);
    AddKeyword("Peek", FuncPeek);
    AddKeyword("Clear", FuncClear);
    AddKeyword("Contains", FuncContains);
    AddKeyword("AddArray", FuncAddArray);
    AddKeyword("ToArray", FuncToArray);

    help_dict->insert({ "help",     "\tQueue.help([name])" });
    help_dict->insert({ "Create",   "\tCreate queue: Queue.Create(queue_name)" });
    help_dict->insert({ "Delete",   "\tDelete all queues: Queue.Delete()" });
    help_dict->insert({ "Count",    "\tReturns the number of elements actually contained in the queue: Queue.Count(queue name)" });
    help_dict->insert({ "Write",    "\tWrites queue_names or all elements from the queue_name to the standard output stream:\r\n\tQueue.Write([queue_name])" });
    help_dict->insert({ "Enqueue",  "\tAdds an object to the end of the Queue: Queue.Enqueue(queue name)(string)" });
    help_dict->insert({ "Dequeue",  "\tRemoves and returns the object at the beginning of the  Queue: Queue.Dequeue(queue name)" });
    help_dict->insert({ "Peek",     "\tReturns the object at the beginning of the Queue without removing it: Queue.Peek(queue name)" });
    help_dict->insert({ "Clear",    "\tRemoves all elements from the queue:  Queue.Clear(queue_name)" });
    help_dict->insert({ "Contains", "\tDetermines whether an element is in the queue, returns True or False: Queue.Contains(queue_name)(string)" });
    help_dict->insert({ "AddArray", "\tAdds PPL_array to the end of the queue: Queue.AddArray(\"PPL_array\")(queue_name)" });
    help_dict->insert({ "ToArray",  "\tCopies all elements from queue to new PPL_array: Queue.ToArray(queue_name)(\"PPL_array\")" });

    for (const auto pair : *keyword_dict)
    {
      string key = "Queue." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Queue", this });
  }
  //==========================================================
  bool Queue::FuncCreate(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Queue.FuncCreate] wrong number of parameters != 1"});
      return false;
    }

    string queue_name = trim(parameters[0], "\"");

    for (size_t j = 0; j < named_queues.size(); j++)
    {
      NamedQueue& nqueue1 = named_queues[j];
      if (nqueue1.name == queue_name)
      {
        named_queues.erase(named_queues.begin() + j);
        printDlgt({ "Warning: [Queue.FuncCreate] name [{0}] is created repeatedly", queue_name });
        break;
      }
    }

    NamedQueue Nqueue;
    Nqueue.name = parameters[0];
    Nqueue.nqueue = {};
    named_queues.push_back(Nqueue);
    return true; 
  }
  //==========================================================
  bool Queue::FuncDelete(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 0)
    {
      printDlgt({"Error: [Queue.FuncDelete] wrong number of parameters != 0"});
      return false;
    }

    named_queues.clear();
    return true; 
  }
  //==========================================================
  bool Queue::FuncCount(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Queue.FuncCount] wrong number of parameters != 1"});
      return false;
    }

    string queue_name = trim(parameters[0], "\"");

    NamedQueue* ptr_nqueue;
    if (!GetNamedQueueByName("Queue.FuncCount", parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncCount] wrong name [{0}]",queue_name });
      return false;
    }
    result = to_string(ptr_nqueue->nqueue.size());
        
    return true; 
  }
  //==========================================================
  bool Queue::FuncWrite(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() > 1)
    {
      printDlgt({"Error: [Queue.FuncWrite] wrong number of parameters > 1"});
      return false;
    }

    if (parameters.empty())
    {
      if (named_queues.empty())
      {
        printDlgt({ "table of queues is empty" });
        return true;
      }
      for (const auto& Nqueue : named_queues)
      {
        printDlgt({Nqueue.name});
      }
    }
    else
    {
      string queue_name = trim(parameters[0], "\"");
      printDlgt({"==={0}===",parameters[0]});

      NamedQueue* ptr_nqueue = nullptr;
      if (!GetNamedQueueByName("Queue.FuncWrite", parameters[0], ptr_nqueue))
      { 
        printDlgt({"Error: [Queue.FuncWrite] wrong name [{0}]",queue_name });
        return false;
      }
      queue<string> temp_queue = ptr_nqueue->nqueue; // Copy to a temporary queue to display contents
      while (!temp_queue.empty())
      {
        printDlgt({"\t" + temp_queue.front()});
        temp_queue.pop();
      }
    }
    return true; 
  }
  //==========================================================
  bool Queue::FuncEnqueue(const vector<string>& parameters_inp, string& result, Composite* node) 
  { 
    if (parameters_inp.size() != 2)
    {
      printDlgt({"Error: [Queue.FuncEnqueue] wrong number of parameters != 2 (use empty instead of \"\")"});
      return false;
    }
    vector<string> parameters = parameters_inp;
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");
    NamedQueue* ptr_nqueue;
    if (!GetNamedQueueByName("Queue.FuncEnqueue", parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncToEnqueue] wrong name [{0}]",parameters[0] });
      return false;
    }
    ptr_nqueue->nqueue.push(parameters[1]); // Enqueue the item    
    return true; 
  }
  //==========================================================
  bool Queue::FuncDequeue(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Queue.FuncDequeue] wrong number of parameters != 1"});
      return false;
    }
    
    NamedQueue* ptr_nqueue = nullptr;
    if (!GetNamedQueueByName("Queue.FuncDequeue", parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncDequeue] wrong name [{0}]",parameters[0] });
      return false;
    }

    if (ptr_nqueue->nqueue.empty())
    {
      result = "queue is empty";
    }
    else
    {
      result = ptr_nqueue->nqueue.front(); // Get the front item
      ptr_nqueue->nqueue.pop();            // Remove the front item
    }    
    return true; 
  }
  //==========================================================
  bool Queue::FuncPeek(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Queue.FuncPeek] wrong number of parameters != 1"});
      return false;
    }
    
    NamedQueue* ptr_nqueue;
    if (!GetNamedQueueByName("Queue.FuncPeek", parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncPeek] wrong name [{0}]",parameters[0] });
      return false;
    }

    if (ptr_nqueue->nqueue.empty())
    {
      result = "empty";
    }
    else
    {
      result = ptr_nqueue->nqueue.front(); // Peek the front item
    }
    return true; 
  }
  //==========================================================
  bool Queue::FuncClear(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Queue.FuncClear] wrong number of parameters != 1"});
      return false;
    }

    string name_queue = trim(parameters[0], "\"");

    NamedQueue* ptr_nqueue = nullptr;
    if (!GetNamedQueueByName("Queue.FuncClear", name_queue, ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncClear] wrong name [{0}]",name_queue });
      return false;
    }

    while (!ptr_nqueue->nqueue.empty()) // Clear the queue
    {
      ptr_nqueue->nqueue.pop();
    }
    return true; 
  }
  //==========================================================
  bool Queue::FuncContains(const vector<string>& parameters_inp, string& result, Composite* node) 
  { 
    if (parameters_inp.size() != 2)
    {
      printDlgt({"Error: [Queue.FuncContains] wrong number of parameters != 2"});
      return false;
    }
    vector<string> parameters = parameters_inp;
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");

    NamedQueue* ptr_nqueue;
    if (!GetNamedQueueByName("Queue.FuncContains", parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncContains] wrong name [{0}]",parameters[0] });
      return false;
    }

    // Check if the queue contains the specified element
    queue<string> temp_queue = ptr_nqueue->nqueue; // Copy to a temporary queue
    bool b = false;
    while (!temp_queue.empty())
    {
      if (temp_queue.front() == parameters[1])
        b = true;
      temp_queue.pop();
    }
    result = b ? "True" : "False";
    return true; 
  }
  //==========================================================
  bool Queue::FuncAddArray(const vector<string>& parameters_inp, string& result, Composite* node) 
  { 
    // src - ppl_array,name in named_queues
    string func_name = "Queue.FuncAddArray";
    if (parameters_inp.size() != 2)
    {
      printDlgt({"Error: [Queue.FuncAddArray] wrong number of parameters != 2"});
      return false;
    }
    vector<string> parameters = parameters_inp;
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");

    NamedQueue* ptr_nqueue = nullptr;
    if (!GetNamedQueueByName(func_name, parameters[1], ptr_nqueue))
     {
      printDlgt({"Error: [Queue.FuncAddArray] wrong name [{0}]",parameters[0] });
      return false;
    }
    string fullname = parameters[0];
    string name = "", nodes = "";
    Composite* path = nullptr;
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
    {
      //print
      return false;
    }

    Composite* node_array = nullptr;
    for (auto& child : *(path->_children))
    {
      if (child->name == name && dynamic_cast<Composite*>(child))
      {
        node_array = (Composite*)child;
        break;
      }
    }

    if (node_array == nullptr)
    {
      printDlgt({"Error: [Queue.FuncAddArray] wrong array name [{0}]",name});
      return false;
    }
    for (auto& child : *(node_array->_children))
    {
      ptr_nqueue->nqueue.push(child->value); // Enqueue values from the array
    }
    return true; 
  }
  //==========================================================
  bool Queue::FuncToArray(const vector<string>& parameters_inp, string& result, Composite* node) 
  {
    // copy to new array
    // named_array_list, dest_name_ppl_array
    // Realloc PPL_array and copy to it all Queue  (used queue.ToArray)
    // instead of Queue.CopyTo, which copies to existing array
    if (parameters_inp.size() != 2)
    {
      printDlgt({"Error: [Queue.FuncToArray] wrong number of parameters != 2"});
      return false;
    }
    vector<string> parameters = parameters_inp;
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");

    NamedQueue* ptr_nqueue = nullptr;
    string func_name = "Queue.FuncToArray";
    if (!GetNamedQueueByName(func_name, parameters[0], ptr_nqueue))
    {
      printDlgt({"Error: [Queue.FuncToArray] wrong name [{0}]",parameters[0] });
      return false;
    }

    Composite* path = nullptr;
    string name = "";
    string nodes = "";

    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, parameters[1], path, nodes, name);
    if (!b)
    {
      return false;
    }
    vector<string> tgt_array;
    while (!ptr_nqueue->nqueue.empty())
    {
      tgt_array.push_back(ptr_nqueue->nqueue.front());
      ptr_nqueue->nqueue.pop();
    }

    ppl->processing->FuncReAllocArray({ parameters[1], "", to_string(tgt_array.size()), "" }, result, node);
    Composite* comp = nullptr;
    for (auto& child : *(path->_children))
    {
      if (child->name == name)
      {
        comp = (Composite*)child;
        int i = 0;
        for(auto& s : tgt_array)
          (*(comp->_children))[i++]->value = s;
      }
    }   
    for (auto e : tgt_array)
      ptr_nqueue->nqueue.push(e);
    return true; 
  }
  //==========================================================
  bool Queue::GetNamedQueueByName(string calling_method_name, string name, NamedQueue*& Nqueue)
  {
    size_t j = 0;
    for (j = 0; j < named_queues.size(); j++)
    {
      if (named_queues[j].name == name)
      {
        Nqueue = &named_queues[j];
        return true;
      }
    }
    //printDlgt({ "Error: [Queue.GetNamedQueueByName] [{0}] wrong queue name [{1}]" , calling_method_name, name  });
    return false;
  }
}