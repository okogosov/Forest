bool FuncDisplayNodes(std::vector<std::string> parameters, std::string& result, Composite* node = nullptr)
{
    if (node && node->parent)
    {
        if ((node->parent->name == "var") ||
            (node->parent->name == "const") ||
            (node->parent->name == "array") ||
            (node->parent->name == "storage") ||
            (node->parent->name == "swrite") ||
            (node->parent->name == "createnode"))
        {
            ppl.print("Error: [FuncDisplay] name is keyword [%s(dn)]", (node->parent->name + "(dn)").c_str());
            return false;
        }
    }
    Composite* display_node = ppl.NameSpaces;

    if (parameters.empty())
    {
        display_node->Display(ppl.print, 1, true);
        return true;
    }

    const std::string& param = parameters[0];
    if (param.empty())
    {
        display_node->Display(ppl.print, 1, true);
        return true;
    }
    else if (param == "root")
    {
        ppl.print("-----root-----");
        for (Composite* cc : ppl.root.GetChildren())
        {
            if (cc)
                cc->Display(ppl.print, 1, true);
        }
        return true;
    }
    else if (param == "Functions")
    {
        ppl.print("-----Functions-----");
        for (Composite* cc : ppl.Functions.GetChildren())
        {
            if (cc)
                cc->Display(ppl.print, 1, true);
        }
        return true;
    }
    else if (param == "Configuration")
    {
        ppl.print("-----Configuration-----");
        for (Component* c : ppl.Configuration.GetChildren())
        {
            if (c)
                c->Display(ppl.print, 1, true);
        }
        return true;
    }
    else if (param == "Global")
    {
        ppl.print("-----Global-----");
        ppl.Global.Display(ppl.print, 1, true);
        return true;
    }
    else if (param == "Local")
    {
        ppl.print("-----Local-----");
        ppl.Local.Display(ppl.print, 1, true);
        return true;
    }
    else
    {
        std::vector<std::string> tokens;
        boost::split(tokens, param, boost::is_any_of("."), boost::token_compress_on);
        std::string name = tokens.back();
        if (param.find("Functions") != std::string::npos)
        {
            Component* c = ppl.Functions.GetChildren().find_if([&](Component* item) { return item->name == name; });
            if (!c)
            {
                ppl.print("Error: [FuncDisplayNodes] node %s does not exist", name.c_str());
                return false;
            }
            if (Composite* cc = dynamic_cast<Composite*>(c))
            {
                cc->Display(ppl.print, 1, true);
                return true;
            }
            else
            {
                ppl.print("Error: [FuncDisplayNodes] name %s is Leaf", name.c_str());
                return false;
            }
        }
        else
        {
            Composite* path = nullptr;
            std::string fullname = param;
            std::string nodes = "";
            if (param.find("Global.") != std::string::npos)
                fullname = param.substr(strlen("Global."));
            else if (param.find("Local.") != std::string::npos)
                fullname = param.substr(strlen("Local."));

            bool b = ppl.processing.GetPathAndNameFromGlobalLocal("FuncDisplayNodes", fullname, path, nodes, name);
            if (!b)
            {
                ppl.print("Error: [FuncDisplayNodes] node %s does not exist", fullname.c_str());
                return false;
            }
            Component* c = nullptr;
            b = false;
            for (int m = 0; m < path->GetChildren().size(); m++)
            {
                c = path->GetChildren()[m];
                if (c->name == name)
                {
                    b = true;
                    break;
                }
            }
            if (b)
            {
                ppl.print("-----Variables  and arrays-----");
                c->Display(ppl.print, 1, true);
            }
            else
            {
                ppl.print("Error: [FuncDisplayNodes] wrong name %s", name.c_str());
                return false;
            }
        }
    }
    return true;
}
