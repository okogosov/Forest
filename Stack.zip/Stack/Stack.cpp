#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Stack.h"

using namespace std;
namespace PPLNS
{
  static Stack* STACKInstance = nullptr;

  void Stack_CreateInstance(PPL* ppl)
  {
    STACKInstance = new Stack(ppl);
    STACKInstance->AddToKeywordDictionary();
  }
  //=======================================================
  Stack::Stack(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;  
  }
  //=======================================================
  void Stack::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Count", FuncCount);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Push", FuncPush);
    AddKeyword("Pop", FuncPop);
    AddKeyword("Peek", FuncPeek);
    AddKeyword("Clear", FuncClear);
    AddKeyword("Contains", FuncContains);
    AddKeyword("AddArray", FuncAddArray);
    AddKeyword("ToArray", FuncToArray);
    
    help_dict->insert({ "help", "\tStack.help([name])" });
    
    help_dict->insert({ "Create", "\tCreate stack: Stack.Create(stack_name)" });
    help_dict->insert({ "Delete", "\tDelete all stacks: Stack.Delete()" });
    help_dict->insert({ "Count", "\tReturns the number of elements actually contained in the stack: Stack.Count(stack name)" });
    help_dict->insert({ "Write", "\tWrites stack_names or all elements from the stack_name to the standard output stream:\r\n\tStack.Write([stack_name])" });
    help_dict->insert({ "Push", "\tInserts an object at the top of the stack: Stack.Push(stack name)(string)" });
    help_dict->insert({ "Pop", "\tRemoves and returns the object at the top of the  Stack: Stack.Pop(stack name)" });
    help_dict->insert({ "Peek", "\tReturns the object at the top of the Stack without removing it: Stack.Peek(stack name)" });
    help_dict->insert({ "Clear", "\tRemoves all elements from the stack:  Stack.Clear(stack_name)" });
    help_dict->insert({ "Contains", "\tDetermines whether an element is in the stack, returns True or False: Stack.Contains(stack_name)(string)" });
    help_dict->insert({ "AddArray", "\tAdds PPL_array to the end of the stack: Stack.AddArray(\"PPL_array\")(stack_name)" });
    help_dict->insert({ "ToArray", "\tCopies all elements from stack to new PPL_array: Stack.ToArray(stack_name)(\"PPL_array\")" });
    
    for (const auto pair : *keyword_dict)
    {
      string key = "Stack." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Stack", this });
  }
  //=========================================================
  bool Stack::FuncCreate(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1) 
    {
      printDlgt({ "Error: [Stack.FuncCreate] wrong number of parameters != 1" });
      return false;
    }
    
    parameters[0] = trim(parameters[0],"\"");
    for (size_t j = 0; j < named_stacks.size(); j++) 
    {
      NamedStack& nqueue1 = named_stacks[j];
      if (nqueue1.name == parameters[0]) 
      {
        named_stacks.erase(named_stacks.begin() + j);
        printDlgt({ "Warning: [Stack.FuncCreate] name [" + parameters[0] + "] is created repeatedly" });
        break;
      }
    }

    NamedStack ptr_nstack;
    ptr_nstack.name = parameters[0];
    ptr_nstack.nstack = {}; // Initialize with an empty stack
    named_stacks.push_back(ptr_nstack);
    return true; 
  }
  //=======================================================
  bool Stack::FuncDelete(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 0)
    {
      printDlgt({ "Error: [Stack.FuncDelete] wrong number of parameters != 0" });
      return false;
    }
    named_stacks.clear();
    return true;
  }
  //=======================================================
  bool Stack::FuncCount(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Stack.FuncCount] wrong number of parameters != 1" });
      return false;
    }
    parameters[0] = trim(parameters[0], "\"");

    NamedStack* ptr_nstack;
    if (!GetNamedStackByName("Stack.FuncCount", parameters[0], ptr_nstack))
      return false;
    result = to_string(ptr_nstack->nstack.size());
    return true; 
  }
  //=======================================================
  bool Stack::FuncWrite(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() > 1) 
    {
      printDlgt({ "Error: [Stack.FuncWrite] wrong number of parameters > 1" });
      return false;
    }
    if (parameters.empty()) 
    {
      if (named_stacks.empty())
      {
        printDlgt({ "table of stacks is empty" });
        return true;
      }
      for (const NamedStack& nstack : named_stacks) 
        printDlgt({ nstack.name });
      return true;
    }
    else 
    {
      parameters[0] = trim(parameters[0], "\"");
      NamedStack* ptr_nstack = nullptr;
      if (!GetNamedStackByName("Stack.FuncWrite", parameters[0], ptr_nstack))
        return false;
      vector<string> tgt_vector;
      CopyStackToVector(ptr_nstack->nstack, tgt_vector);
      for(auto& value : tgt_vector)
        printDlgt({ "\t" + value });
    }
    return true; 
  }
  //==============================================================================
  bool Stack::FuncPush(vector<string> parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Stack.FuncPush] wrong number of parameters != 2 (use empty instead of \"\")" });
      return false;
    }
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");
    NamedStack* ptr_nstack = nullptr;
 
    if (!GetNamedStackByName("Stack.FuncPush", parameters[0], ptr_nstack)) 
      return false;

    ptr_nstack->nstack.push(parameters[1]); // Push the second parameter onto the stack
    return true; 
  }
  //=======================================================
  bool Stack::FuncPop(vector<string> parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1) 
    {
      printDlgt({ "Error: [Stack.FuncPop] wrong number of parameters != 1" });
      return false;
    }

    NamedStack* ptr_nstack = nullptr;
    if (!GetNamedStackByName("Stack.FuncPop", parameters[0], ptr_nstack)) 
      return false;

    if (ptr_nstack->nstack.empty()) 
    {
      result = "empty";
    }
    else 
    {
      result = ptr_nstack->nstack.top(); // Get the top element
      ptr_nstack->nstack.pop();          // Remove the top element
    }
    return true; 
  }
  //=======================================================
  bool Stack::FuncPeek(vector<string> parameters, string& result, Composite* node)
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Stack.FuncPeek] wrong number of parameters != 1" });
      return false;
    }

    NamedStack* ptr_nstack = nullptr;
    if (!GetNamedStackByName("Stack.FuncPeek", parameters[0], ptr_nstack))
      return false;

    if (ptr_nstack->nstack.empty())
    {
      result = "empty";
    }
    else
    {
      result = ptr_nstack->nstack.top(); // Get the top element
    }
    return true; 
  }
  //=======================================================
  bool Stack::FuncClear(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Stack.FuncClear] wrong number of parameters != 1" });
      return false;
    }
    parameters[0] = trim(parameters[0], "\"");
    NamedStack* ptr_nstack = nullptr;
    if (!GetNamedStackByName("Stack.FuncClear", parameters[0], ptr_nstack))
      return false;
    ClearStack(ptr_nstack->nstack);
    return true; 
  }
  //=======================================================
  bool Stack::FuncContains(vector<string> parameters, string& result, Composite* node) 
  { 
    // name in named_array_list, string
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Stack.FuncContains] wrong number of parameters != 2" });
      return false;
    }
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");
    NamedStack* ptr_nstack = nullptr;
    if (!GetNamedStackByName("Stack.FuncClear", parameters[0], ptr_nstack))
      return false;
    vector<string> v;
    CopyStackToVector(ptr_nstack->nstack, v);
    if (VectorContains(v, parameters[1]))
      result = "True";
    else
      result = "False";
    return true; 
  }
  //=======================================================
  bool Stack::FuncAddArray(vector<string> parameters, string& result, Composite* node) 
  { 
    // src - ppl_array,name in named_stacks
    string func_name = "Stack.FuncAddArray";
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 2", func_name });
      return false;
    }
    parameters[0] = trim(parameters[0], "\"");
    parameters[1] = trim(parameters[1], "\"");
    NamedStack* ptr_nstack = nullptr;

    if (!GetNamedStackByName(func_name, parameters[1], ptr_nstack))
      return false;
    //===================================================
    string fullname = parameters[0];
    string name = "", nodes = "";
    Composite* path = nullptr;
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (b == false)
      return false;
    //===================================================
    Composite* node_array = nullptr;
    for(auto& c : *(path->_children))
    {
      if ((c->name == name) && (dynamic_cast<Composite*>(c)))
      {
        node_array = (Composite*)c;
        break;
      }
    }
    if (node_array == nullptr)
    {
      printDlgt({ "Error: [Stack.FuncAddArray] wrong array name [{0}]", name });
      return false;
    }
    for(auto& c : *(node_array->_children))
      ptr_nstack->nstack.push(c->value);
    return true; 
  }
  //=======================================================
  bool Stack::FuncToArray(vector<string> parameters, string& result, Composite* node) 
  {     
      // named_stack_list, dest_name_ppl_array
      // Realloc PPL_array and copy to it all Stack
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [Stack.FuncToArray] wrong number of parameters != 2" });
        return false;
      }
      parameters[0] = trim(parameters[0], "\"");
      parameters[1] = trim(parameters[1], "\"");
      NamedStack* ptr_nstack = nullptr;
      string func_name = "Stack.FuncToArray";
      string fullname = parameters[1];
      if (!GetNamedStackByName(func_name, parameters[0], ptr_nstack))
         return false;
      vector<string> tgt_vector;
      CopyStackToVector(ptr_nstack->nstack, tgt_vector);
      //====================================================     
      string name = "";
      //========================================================
      // operator 'array' creates array by name 
      //bool b = ppl.processing.keyword_dict["array"]
      //     (new List<string>() { parameters[1], tgt_array.Length.ToString() }, ref result, node);
      //if (b == false)
      //{
      //  //PPL_array is already created
      //  return false;
      //}
      //========================================================
    Composite* path = nullptr;
    string nodes = "";
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (b == false)
      return false;
    //======================================================
    vector<string> parametersReAlloc = { parameters[1], "", to_string(tgt_vector.size()), ""};
    ppl->processing->FuncReAllocArray(parametersReAlloc, result, node);
    //======================================================  
    Composite* comp = nullptr;
    for(auto& c : *(path->_children))
    {
      if (c->name == name)
      {
        comp = (Composite*)c;
        int i = 0;
        for(auto& s : tgt_vector)
          (*(comp->_children))[i++]->value = s;
      }
    }
    return true; 
  }
  //=======================================================
  bool Stack::GetNamedStackByName(string calling_method_name, string& name, NamedStack*& nstack)
  {
    for(int i = 0;i < named_stacks.size();i++)
    {
      if (named_stacks[i].name == name)
      {
        nstack = &named_stacks[i];
        return true;
      }
    }
    printDlgt({ "Error: [Stack.GetNamedStackByName] [{0}] wrong stack name [{1}]" , calling_method_name, name  });
    return false;
  }
}
