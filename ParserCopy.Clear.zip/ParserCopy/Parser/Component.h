#include <stack>
#include <vector>
#include <string>
using namespace std;

namespace PPLNS
{
  class Composite;
  class  Component
  {
  //protected:
    //================================================================
  public:
    string name;
    string value;
    string addit_info;
    Composite* parent;
    int LeafIndex;
    //================================================================
    Component(string name, string value);
    virtual ~Component() = default;
    virtual void Display(int depth, bool only_nodes = false) = 0;
    virtual bool Remove(Component* component) = 0;

    string trim(const string& source, const string& chars);
    bool IsDigitsOnly(string str);
    bool StringContains(string src, string pattern);
    //void SplitString(vector<string>& v, string input, char delimiter, bool RemoveEmptyToken = true);
    vector<string> SplitString(string input, char delimiter, bool RemoveEmptyToken = true);
    //vector<string> SplitString(string input, vector<string> delimiters, bool RemoveEmptyToken = true);
    template <typename T>
    void ClearStack(stack<T>& myStack)
    {
      while (!myStack.empty())   myStack.pop();
    }
  };
  //==================================================================
  //
  class    Leaf : public Component
  {
  public:
    bool constant;   // flag to set constant var. now used only in Leaf, not in composite
    // Constructor
    Leaf(string _name, string _value = "");
    ~Leaf();
    bool Remove(Component* component);
    void Display( int depth, bool only_nodes = false) override;  
  };
  //================================================================
  class  Composite : public Component
  {
  public:
    vector<Component*>* _children = nullptr;
    int nesting;           
    int number_component; 
    int leafNumberToDisplay;
    bool RunFlag = true;   

    ////LoopStruct loop_struct;
    stack<string> ChildrenResults;

    Composite(string _name, string _value = "");
    //================================================================
    ~Composite();
    void DeleteAllSuccessors();
    //================================================================
    vector<Component*>* GetChildren();
    void Add(Component* c);
    void Display( int depth, bool only_nodes = false) override;
    //Component* CloneNew() override;
    ///void Replace_this_on_StructName(Processing* proc, vector<string> tokens) override;
    ///void DisplayData(int depth, bool only_nodes = false);    
    Component* First();
    Component* Last();
    bool Remove(Component* component);
    //void RemoveNode();   // internal in Remove
    void Clear();
    bool Insert(int index, Component* component);
    void SetNesting();
    //==================================================================
    void ConvertLeafToNode(string name);
    Component* ConvertNodeToLeaf(string node_name, string name);

    void GetPredecessorNode(string name, Composite*& node);
    void GetSuccessorNode(string name, Composite*& node);
    void RestoreExpressionFromTree(Composite* init_node, string& result);
    Component* GetComponentByName(string name);
    void GetComponentByName(Composite*& Node, string fullname, Component*& component,  vector<string>& gcn_tokens, int& gcn_current_level);

    Component* GetNode(string name);
    void Clone(Composite*& clone, Composite*& node_tmp);
    string  Get_FullPathName();
    //==================================================================
    //void SetLoopParameters(bool upward, int size, int& begin_loop, int& end_loop, int& incr);
    bool traversal_return = true;
    ///bool Traversal(bool& StartFlag, Processing* processing, bool upward = true);

    //bool IsAllPredicates(vector<string> v);
    //bool IsAllPredicates(stack<string> stk1);
   // string DeleteBackSlash(string str);
    //==================================================================
    Component* FindEmptyLeaf(Component* TmpComp, string& node_name);
    Composite* GetCmdRoot(Composite* CmdRoot);
    void GetNodes(string& fullPredecessorName, int nesting0, vector<string>& nodes_names_list);
  };
}