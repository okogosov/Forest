#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  /// <summary>
    ///AddressBook,Klim AberCrombie,"(123) 555-0123", "(123) 555-0123", ,someone@example.com);
    // df, column1 data, column2 data,.....
    /// </summary>
    /// <param name="parameters"></param>
    /// <param name="result"></param>
    /// <param name="node"></param>
    /// <returns></returns>
  bool DataFrame::FuncAddRowData(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncAddRowData";

    if (parameters.empty())
    {
      printDlgt({"Error: [{0}] no parameters provided", func_name });
      return false;
    }

    string df_name = parameters[0];

    try
    {
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      //vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          //ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      vector<string> parameters2;
      parameters2.push_back(parameters[0]);
      parameters2.push_back("1");

      //bool b = keyword_dict["AddRows"](parameters2, result, node);   // C#
      bool b = FuncAddRows(parameters2, result, node);
      //int length = stoi(comp_settings->GetComponentByName("RowsLength")->value);
      int length;
      TryParse(comp_settings->GetComponentByName("RowsLength")->value,length);
      parameters2.clear();
      parameters2.push_back(parameters[0]);
      parameters2.push_back(to_string(length - 1));

      for (size_t i = 1; i < parameters.size(); i++)
        parameters2.push_back(parameters[i]);

     // b = keyword_dict["SetRow"](parameters2, result, node);        // C#
      b = FuncSetRow(parameters2, result, node);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
}