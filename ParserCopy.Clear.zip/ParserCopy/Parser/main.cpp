
#include <iostream>
#include "Parser.h"
int main()
{
  PPLNS::PPL* ppl = new PPLNS::PPL();
  std::string input =
  R"(Configuration
  (default_loaded_functions[Functions\CommonFunctions.ppl])
    (Code[scr])
    (Debugppl[no])
    (delete_all_in_readcode[yes])
    (Log[no])
    (stay_interactive[no])

    (Duration[no])

    (UserImport1[Directory])
    (UserImport2[Math])
    (UserImport3[String])
    (UserImport4[File])
    (UserImport5[Console])
  //(UserImport6              [Convert])
    )";
    PPLNS::Composite* root = ppl->Parser(input,true);
  root->Display(1);
}
/*
Result:
-N          0              root
---N        1     Configuration
-----L      0   default_loaded_functions        Functions\CommonFunctions.ppl
-----L      1              Code             scr
-----L      2          Debugppl              no
-----L      3   delete_all_in_readcode              yes
-----L      4               Log              no
-----L      5   stay_interactive                     no
-----L      6          Duration              no
-----L      7       UserImport1       Directory
-----L      8       UserImport2            Math
-----L      9       UserImport3          String
-----L     10       UserImport4            File
-----L     11       UserImport5         Console
*/