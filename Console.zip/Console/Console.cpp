#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Console.h"

using namespace std;
namespace PPLNS
{
  static Console* CONSOLEInstance = nullptr;

  void Console_CreateInstance(PPL* ppl)
  {
    CONSOLEInstance = new Console(ppl);
    CONSOLEInstance->AddToKeywordDictionary();
  }

  Console::Console(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Console::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("ForegroundColor", FuncForegroundColor);
    AddKeyword("BackgroundColor", FuncBackgroundColor);
    AddKeyword("ForegroundPromptColor", FuncForegroundPromptColor);
    AddKeyword("DefaultColors", FuncDefaultColors);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Beep", FuncBeep);
    AddKeyword("Clear", FuncClear);
    AddKeyword("SetCursorPosition", FuncSetCursorPosition);
    AddKeyword("GetCursorPosition", FuncGetCursorPosition);
    AddKeyword("WindowWidth", FuncWindowWidth);
    AddKeyword("WindowHeight", FuncWindowHeight);

    help_dict->insert({ "help", "\tConsole.help([name])" });
    help_dict->insert({ "ForegroundColor", "\tSets the foreground color of the console Console.ForegroundColor(color)" });
    help_dict->insert({ "BackgroundColor", "\tSets the background color of the console Console.BackgroundColor(color)" });
    help_dict->insert({ "ForegroundPromptColor", "\tSets the prompt foreground color of the console Console.ForegroundPromptColor(color)" });
    help_dict->insert({ "DefaultColors", "\tConsole.DefaultColors()" });
    help_dict->insert({ "Write", "\ttWrites the text representation of the specified value or values to the standard output\r\n\tConsole.Write Write [(format)](string)(string)" });
    help_dict->insert({ "Beep", "\tConsole.Beep(frequency)(duration)" });
    help_dict->insert({ "Clear", "\tConsole.Clear()" });
    help_dict->insert({ "SetCursorPosition", "\tConsole.SetCursorPosition(left column cursor position)(top row cursor position)" });
    help_dict->insert({ "GetCursorPosition", "\tConsole.GetCursorPosition()" });
    help_dict->insert({ "WindowWidth", "\tConsole.WindowWidth([width])" });
    help_dict->insert({ "WindowHeight", "\tConsole.WindowHeight([height])" });

    for (const auto pair : *keyword_dict)
    {
      string key = "Console." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Console", this });
  }
  const std::vector<std::string> colors =
  {
    "Black",
    "DarkBlue",
    "DarkGreen",
    "DarkCyan",
    "DarkRed",
    "DarkMagenta",
    "DarkYellow",
    "Gray",
    "DarkGray",
    "Blue",
    "Green",
    "Cyan",
    "Red",
    "Magenta",
    "Yellow",
    "White"
  };
  //=========================================================
  // to upper case => CTRL_SHIFT_U
#define COLOR_BLACK	      0     
#define COLOR_DARKBLUE	   1     
#define COLOR_DARKGREEN	  2     
#define COLOR_DARKCYAN	   3     
#define COLOR_DARKRED	    4     
#define COLOR_DARKMAGENTA	5    
#define COLOR_DARKYELLOW	 6     
#define COLOR_GRAY	       7     
#define COLOR_DARKGRAY	   8     
#define COLOR_BLUE	       9     
#define COLOR_GREEN	      10    
#define COLOR_CYAN	       11    
#define COLOR_RED	        12    
#define COLOR_MAGENTA	    13    
#define COLOR_YELLOW	     14    
#define COLOR_WHITE	      15    
//#define BACKGROUND_BLACK 0x0000

  int  Foreground_Color = COLOR_WHITE;
  int  Background_Color = COLOR_BLACK;
  int  ForegroundPrompt_Color = COLOR_YELLOW;


  void Console::SetForegroundColor(int color)
  {
    Foreground_Color = color;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, Foreground_Color | Background_Color);
  }
  void Console::SetForegroundPromptColor(int color)
  {
    ForegroundPrompt_Color = color;
  }
  void Console::SetBackgroundColor(int color)
  {
    Background_Color = color;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, Foreground_Color | Background_Color);
  }
  //=========================================================
  void Console::SetCursorPosition(int left, int top)
  {
    COORD coord;
    coord.X = left;
    coord.Y = top;

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hConsole, coord);
  }
  //=========================================================
  bool Console::FuncForegroundColor(vector<string> parameters, string& result, Composite* node)
  {
    string func_name = "Console::FuncForegroundColor";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong format: Console.ForegroundColor(color)", func_name });
      return false;
    }
    const std::string& inp_color = parameters[0];
    int color = -1;
    for (int i = 0; i < colors.size(); i++)
    {
      if (colors[i] == inp_color)
      {
        color = i;
        break;
      }
    }
    if (color == -1)
    {
      printDlgt({ "Error:  [{0}] wrong color:  [{0}]", func_name, inp_color });
      return false;
    }
    SetForegroundColor(color);
    return true;
  }
  bool Console::FuncBackgroundColor(vector<string> parameters, string& result, Composite* node)
  {
    string func_name = "Console::FuncBackgroundColor";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong format: Console.BackgroundColor(color)", func_name });
      return false;
    }
    const std::string& inp_color = parameters[0];
    int color = -1;
    for (int i = 0; i < colors.size(); i++)
    {
      if (colors[i] == inp_color)
      {
        color = i;
        break;
      }
    }
    if (color == -1)
    {
      printDlgt({ "Error:  [{0}] wrong color:  [{0}]", func_name, inp_color });
      return false;
    }
    SetBackgroundColor(color);
    return true;
  }
  bool Console::FuncForegroundPromptColor(vector<string> parameters, string& result, Composite* node)
  {
    string func_name = "Console::FuncForegroundPromptColor";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong format: Console.FuncForegroundPromptColor(color)" , func_name });
      return false;
    }
    const std::string& inp_color = parameters[0];
    int color = -1;
    for (int i = 0; i < colors.size(); i++)
    {
      if (colors[i] == inp_color)
      {
        color = i;
        break;
      }
    }
    if (color == -1)
    {
      printDlgt({ "Error:  [{0}] wrong color:  [{0}]", func_name, inp_color });
      return false;
    }
    SetForegroundPromptColor(color);
    return true;
  }
  bool Console::FuncDefaultColors(vector<string> parameters, string& result, Composite* node)
  {
    try
    {
      if (!parameters.empty())
      {
        printDlgt({ "Error: [Console.FuncDefaultColors] wrong format: Console.FuncDefaultColors()" });
        return false;
      }
      SetForegroundColor(COLOR_WHITE);
      SetBackgroundColor(COLOR_BLACK);
      SetForegroundPromptColor(COLOR_YELLOW);
    }
    catch (...)
    {
      printDlgt({ "Error [Console.FuncDefaultColors]: ..." });
      return false;
    }
    return true;
  }
  bool Console::FuncWrite(vector<string> parameters, string& result, Composite* node)
  {
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [Console.FuncWrite] wrong format: Console.FuncWrite(string)" });
        return false;
      }
      //if(!parameters[0].empty())
      cout << parameters[0];
      //else   cout << endl;
    }
    catch (...)
    {
      printDlgt({ "Error: ..." });
      return false;
    }
    return true;
  }
  bool Console::FuncBeep(vector<string> parameters, string& result, Composite* node)
  {
    string tmp;
    try
    {
      if (!parameters.empty() && parameters.size() != 2)
      {
        printDlgt({ "Error: [Console.FuncBeep] wrong format: Console.FuncBeep() | Console.FuncBeep(frequency,duration)" });
        return false;
      }
      if (!parameters.empty())
      {
        Beep(750, 300); // Default beep
      }
      else
      {
        tmp = parameters[0];
        int freq = std::stoi(tmp);
        if (freq < 37 || freq > 32767)
        {
          printDlgt({ "Error: [Console.FuncBeep] The frequency of the beep out of bounds, ranging from 37 to 32767 hertz. [{0}] ",tmp });
          return false;
        }
        tmp = parameters[1];
        int duration = std::stoi(tmp);
        Beep(freq, duration);
      }
    }
    catch (const std::invalid_argument& ex)
    {
      printDlgt({ "Error: [Console.FuncBeep] not digital value [{0}] ",tmp });
      return false;
    }
    catch (const std::out_of_range& ex)
    {
      printDlgt({ "Error: [Console.FuncBeep] value out of range [{0}] ",tmp });
      return false;
    }
    return true;
  }
  bool Console::FuncClear(vector<string> parameters, string& result, Composite* node)
  {
    if (!parameters.empty())
    {
      printDlgt({ "Error: [Console.FuncClear] wrong format: Console.FuncClear()" });
      return false;
    }
#ifdef _WIN32
    // For Windows
    system("CLS");
#else
    // For Unix/Linux and macOS
    system("clear");
#endif
    return true;
  }
  //===========================================================================================
  bool Console::FuncSetCursorPosition(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Console.FuncSetCursorPosition] wrong format: Console.FuncSetCursorPosition(left, top) " });
      return false;
    }
    int left = 0;
    if (!TryParse(parameters[0], left))
    {
      printDlgt({ "Error: [Console.FuncSetCursorPosition]  not digital value [{0}] ",  parameters[0] });
      return false;
    }
    int top = 0;
    if (!TryParse(parameters[1], top))
    {
      printDlgt({ "Error: [Console.FuncSetCursorPosition]  not digital value [{0}] ",  parameters[1] });
      return false;
    }
    SetCursorPosition(left, top);
    return true;
  }
  //===========================================================================================
  pair<int, int> Console::GetCursorPosition()
  {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    if (GetConsoleScreenBufferInfo(hConsole, &csbi)) 
    {
      // csbi.dwCursorPosition contains the current cursor position
      return std::make_pair(csbi.dwCursorPosition.X, csbi.dwCursorPosition.Y);
    }
    else 
    {
      // Handle error as needed
      throw std::runtime_error("Failed to get cursor position.");
    }
  }
  //===========================================================================================
  bool Console::FuncGetCursorPosition(vector<string> parameters, string& result, Composite* node)
  {
    string tmp = "";
    try 
    {
      if (!parameters.empty()) 
      {
        printDlgt({ "Error: [Console.FuncGetCursorPosition] wrong format: Console.FuncGetCursorPosition(left, top)" });
        return false;
      }
      auto coord = GetCursorPosition();
      result = to_string(coord.first) + " , " + to_string(coord.second);
    }
    catch (const std::exception& ex) 
    {
      printDlgt({ "Error: [Console.FuncGetCursorPosition]  [{0}] ", ex.what() });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool Console::IsCurrentProcessAdmin() {
    BOOL isAdmin = FALSE;
    PSID administratorsGroup = NULL;

    // Allocate and initialize a SID for the administrators group.
    SID_IDENTIFIER_AUTHORITY ntAuthority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(
      &ntAuthority,
      2,
      SECURITY_BUILTIN_DOMAIN_RID,
      DOMAIN_ALIAS_RID_ADMINS,
      0, 0, 0, 0, 0, 0,
      &administratorsGroup))
    {

      // Check if the current process token has the administrators group.
      if (!CheckTokenMembership(NULL, administratorsGroup, &isAdmin)) {
        isAdmin = FALSE;
      }

      // Free the SID.
      FreeSid(administratorsGroup);
    }

    return isAdmin == TRUE;
  }
  //===========================================================================================
  int Console::GetConsoleWindowWidth()
  {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    int width = 0;

    // Get the handle to the console screen buffer
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hStdOut != INVALID_HANDLE_VALUE)
    {
      // Retrieve the screen buffer info
      if (GetConsoleScreenBufferInfo(hStdOut, &csbi))
      {
        width = csbi.srWindow.Right - csbi.srWindow.Left + 1;
      }
    }
    return width;
  }
  //===========================================================================================
  int Console::GetConsoleWindowHeight() 
  { 
    CONSOLE_SCREEN_BUFFER_INFO csbi; 
    int height = 0; 
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE); 
    if (GetConsoleScreenBufferInfo(hStdOut, &csbi)) 
    { 
      height = csbi.srWindow.Bottom - csbi.srWindow.Top + 1; 
    } 
    return height; 
  }
  //===========================================================================================
  bool Console::FuncWindowWidth(vector<string> parameters, string& result, Composite* node)
  {
    if (!IsCurrentProcessAdmin())
    {
      printDlgt({ "Warning: [Console.FuncWindowWidth] command 'WindowWidth' is executed in Administrator mode only" });
      return true;
    }
    try
    {
      if (parameters.size() > 1)
      {
        printDlgt({ "Error: [Console.FuncWindowWidth] wrong format: Console.FuncWindowWidth([width])" });
        return false;
      }

      // Get the current console width and height
      int column = GetConsoleWindowWidth();
      int rows = GetConsoleWindowHeight();
      // You might need to implement a way to get the actual console size

      if (parameters.empty())
      {
        result = to_string(column);
      }
      else
      {
        try
        {
          column = stoi(parameters[0]);
          // Set the console size using system calls (platform dependent)
          string command = "mode con: cols=" + to_string(column) + " lines=" + to_string(rows);
          system(command.c_str());
        }
        catch (const std::invalid_argument&)
        {
          printDlgt({ "Error: [Console.FuncWindowWidth] width not integer: [{0}]", parameters[0] });
          return false;
        }
      }
    }
    catch (const std::exception& ex)
    {
      printDlgt({ "Error: [Console.FuncWindowWidth] wrong value: [{0}]", ex.what() });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool Console::FuncWindowHeight(vector<string> parameters, string& result, Composite* node)
  {
    if (!IsCurrentProcessAdmin())
    {
      printDlgt({ "Warning: [Console.FuncWindowHeight] command 'WindowHeight' is executed in Administrator mode only" });
      return true;
    }
    try
    {
      if (parameters.size() > 1)
      {
        printDlgt({ "Error: [Console.FuncWindowHeight] wrong format: Console.FuncWindowHeight([lines])" });
        return false;
      }

      // Get the current console width and height
      int column = GetConsoleWindowWidth();
      int rows = GetConsoleWindowHeight();
      // You might need to implement a way to get the actual console size

      if (parameters.empty())
      {
        result = to_string(rows);
      }
      else
      {
        try
        {
          rows = stoi(parameters[0]);
          // Set the console size using system calls (platform dependent)
          string command = "mode con: cols=" + to_string(column) + " lines=" + to_string(rows);
          system(command.c_str());
        }
        catch (const std::invalid_argument&)
        {
          printDlgt({ "Error: [Console.FuncWindowHeight] width not integer: [{0}]", parameters[0] });
          return false;
        }
      }
    }
    catch (const std::exception& ex)
    {
      printDlgt({ "Error: [Console.FuncWindowHeight] wrong value: [{0}]", ex.what() });
      return false;
    }
    return true;
  }
  
}