#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "String.h"
using namespace std;
namespace PPLNS
{
  static String* StringInstance = nullptr;

  void String_CreateInstance(PPL* ppl)
  {
    StringInstance = new String(ppl);
    StringInstance->AddToKeywordDictionary();
  }

  String::String(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
    // called  via FuncImport() /  String()
  void String::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Compare", FuncCompare);
    AddKeyword("Concat", FuncConcat);
    AddKeyword("Contains", FuncContains);
    AddKeyword("Format", FuncFormat);
    AddKeyword("IndexOf", FuncIndexOf);
    AddKeyword("LastIndexOf", FuncLastIndexOf);
    AddKeyword("Insert", FuncInsert);
    AddKeyword("Remove", FuncRemove);
    AddKeyword("DeleteEndOfLine", FuncDeleteEndOfLine);
    AddKeyword("Replace", FuncReplace);
    AddKeyword("Split", FuncSplit);
    AddKeyword("SplitCsv", FuncSplitCsv);
    AddKeyword("StartsWith", FuncStartsWith);
    AddKeyword("Substring", FuncSubstring);
    AddKeyword("ToCharArray", FuncToCharArray);   // creates array
    AddKeyword("ToLower", FuncToLower);
    AddKeyword("ToUpper", FuncToUpper);
    AddKeyword("Trim", FuncTrim);
    AddKeyword("Char", FuncChar);

    help_dict->insert({ "help","\tString.help([name])" });

    help_dict->insert({ "Compare",     "\tReturn signed int as string String.Compare(stringA)(stringB)" });
    help_dict->insert({ "Concat",      "\tReturn String.Concat(string1)(string2)..." });
    help_dict->insert({ "Contains",    "\tReturn True|False String.Contains(string)(specified substring)" });
    help_dict->insert({ "Format",      "\tString.Format(format)(string1)(string2)..." });
    help_dict->insert({ "IndexOf",     "\tReturn digital string  String.IndexOf(string)(value)[(start_index)][(count)]" });
    help_dict->insert({ "LastIndexOf", "\tReturn digital string  String.LastIndexOf(string)(value)[(start_index)][(count)]" });
    help_dict->insert({ "Insert",      "\tString.Insert(string)(start index)(string to insert)" });
    help_dict->insert({ "Remove",      "\tString.Remove(string)(start index)[(number deleted symbols)]" });
    help_dict->insert({ "DeleteEndOfLine", "\tString.DeleteEndOfLine(string)" });
    help_dict->insert({ "Replace",     "\tString.Replace(string)(old value)(new value)" });
    help_dict->insert({ "Split",       "\tString.DeleteEndOfLine(string)" });
    help_dict->insert({ "SplitCsv",    "\tString.SplitCsv(string)(\"ppl_array_separators\")( getname(ppl_array_result))" });
    help_dict->insert({ "StartsWith",  "\tReturn true|false  String.StartsWith(string)( value)" });
    help_dict->insert({ "Substring",   "\tString.Substring(string)(startIndex)[(length)]" });
    help_dict->insert({ "ToCharArray", "\tString.ToCharArray(string)(char array)" });
    help_dict->insert({ "ToLower",     "\tString.ToLower(string)" });
    help_dict->insert({ "ToUpper",     "\tString.ToUpper(string)" });
    help_dict->insert({ "Trim",        "\tString.Trim(string)[(string)]" });
    help_dict->insert({ "Char",        "\tString.Char(string)(index)" });

    for (const auto pair : *keyword_dict)
    {
      string key = "String." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "String",this });
  }
  //=========================================================
  bool String::FuncCompare(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [String.FuncCompare] number of parameters != 2" });
      return false;
    }
    int i = strcmp(parameters[0].c_str(), parameters[1].c_str());
    result = to_string(i);
    return true;
  }
  //===========================================================================================
  bool String::FuncConcat(vector<string> parameters, string& result, Composite* node)
  {
    //result = "";
    for (size_t i = 0; i < parameters.size(); i++) 
    {
      if (parameters[i] == "#quote#")
        parameters[i] = "\"";
    }
    for (const auto& str : parameters) 
      result += str; // Concatenate each string
    result = "\"" + result + "\"";
    return true;
  }
  //===========================================================================================
  bool String::FuncContains(vector<string> parameters, string& result, Composite* node)
  {
    // return -int; 0; +int
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [String.FuncContains] number of parameters != 2" });
      return false;
    }
    if (StringContains(parameters[0], parameters[1]))
      result = "True";
    else
      result = "False";
    return true;
  }
  //===========================================================================================
  bool String::FuncFormat(vector<string> parameters, string& result, Composite* node)
  {
    try
    {
      vector<string> param(parameters.begin() + 1, parameters.end()); // Exclude the first element
      string format = (string)parameters[0];
      result = format;
      
      for (size_t i = 0; i < param.size(); ++i) 
      {
        string placeholder = "{" + to_string(i) + "}";
        size_t pos = result.find(placeholder);
        if (pos != string::npos) 
          result.replace(pos, placeholder.length(), param[i]);

        else 
        {
          printDlgt({ "Error: [String.FuncFormat] Placeholder not found in format string." });
          return false;
        }
      }
    }
    catch (...)
    {
      printDlgt({ "Error: [String.FuncFormat] wrong format" });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncIndexOf(vector<string> parameters, string& result, Composite* node)
  {
    //int IndexOf (string value, [int startIndex], [int count]);
    if (parameters.size() < 2) 
    {
      printDlgt({ "Error: [String.FuncIndexOf] number of parameters < 2" });
      return false;
    }

    int startIndex = 0;
    int count = 0;
    int index = -1; // Default to -1 for not found

    try 
    {
      switch (parameters.size()) 
      {
      case 2:
        index = parameters[0].find(parameters[1]);
        break;
      case 3:
        startIndex = stoi(parameters[2]);
        index = parameters[0].find(parameters[1], startIndex);
        break;
      case 4:
        // Ensure startIndex is within bounds
        if (startIndex < 0 || startIndex >= parameters[0].size()) 
        {
            index = -1; // Invalid startIndex
        } else 
        {
            // Extract the substring to limit the search area
            string searchArea = parameters[0].substr(startIndex, count);
            index = searchArea.find(parameters[1]);
            
            // Adjust the index based on the startIndex
            if (index != string::npos) 
            {
                index += startIndex; // Adjust to the original string's index
            }
        }
        break;
      default:
        printDlgt({ "Error: [String.FuncIndexOf] wrong number of parameters [0]", to_string(parameters.size()) });
        return false;
      }

      result = to_string(index);
      return true;
    }
    catch (const invalid_argument&) 
    {
      printDlgt({ "Error: [String.FuncIndexOf] not digital value" });
      return false;
    }
    catch (const out_of_range&) 
    {
      printDlgt({ "Error: [String.FuncIndexOf] index out of range" });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncLastIndexOf(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() < 2)
    {
      printDlgt({ "Error: [String.FuncIndexOf] number of parameters < 2" });
      return false;
    }

    int startIndex = 0;
    int count = 0;
    int index = -1; // Default to -1 for not found

    try
    {
      switch (parameters.size())
      {
      case 2:
        index = parameters[0].find_last_of(parameters[1]);
        break;
      case 3:
        startIndex = stoi(parameters[2]);
        index = parameters[0].find_last_of(parameters[1], startIndex);
        break;
      case 4:
        // Ensure startIndex is within bounds
        if (startIndex < 0 || startIndex >= parameters[0].size())
        {
          index = -1; // Invalid startIndex
        }
        else
        {
          // Extract the substring to limit the search area
          string searchArea = parameters[0].substr(startIndex, count);
          index = (int)(searchArea.find_last_of(parameters[1]));

          // Adjust the index based on the startIndex
          if (index != string::npos)
          {
            index += startIndex; // Adjust to the original string's index
          }
        }
        break;
      default:
        printDlgt({ "Error: [String.FuncLastIndexOf] wrong number of parameters [0]", to_string(parameters.size()) });
        return false;
      }

      result = to_string(index);
      return true;
    }
    catch (const invalid_argument&)
    {
      printDlgt({ "Error: [String.FuncLastIndexOf] not digital value" });
      return false;
    }
    catch (const out_of_range&)
    {
      printDlgt({ "Error: [String.FuncLastIndexOf] index out of range" });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncInsert(vector<string> parameters, string& result, Composite* node)
  {  //(string)(start index)(string to insert) 
    if (parameters.size() != 3)
    { 
      printDlgt({ "Error: [String.FuncInsert] wrong cmd, format: String.Insert(string)(start index)(string to insert)" });
      return false;
    }
    string source = parameters[0];
    int startIndex;
    if (!TryParse(parameters[1], startIndex))
    {
      printDlgt({ "Error: [String.FuncInsert] start index [{0}] wrong", parameters[1] });
      return false;
    }
    string string_to_insert = parameters[2];
    result = source.insert(startIndex, string_to_insert);
    return true;
  }
  //===========================================================================================
  bool String::FuncRemove(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2 && parameters.size() != 3)
    {
      printDlgt({ "Error: [String.FuncRemove] wrong cmd, format: String.Remove(string)( startIndex)[(number of deleted symbols)]" });
      return false;
    }
    string tmp = "";
    int startIndex = 0;
    try
    {
      string source = parameters[0];
      if (parameters.size() == 2)
      {
        tmp = parameters[1];
        startIndex = stoi(parameters[1]);
      }
      if (parameters.size() == 3)
      {
        tmp = parameters[1];
        startIndex = stoi(parameters[1]);
        tmp = parameters[2];
        int number_deleted_symbols = stoi(parameters[2]);
        result = source.erase(startIndex, number_deleted_symbols);
      }
      else
        result = source.erase(startIndex);
    }
    catch (exception& e)
    {
      printDlgt({"Error: [String.FuncRemove] start index or number_deleted_symbols [{0}] wrong",  tmp });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncDeleteEndOfLine(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [String.FuncDeleteEndOfLine] wrong cmd, format: String.FuncDeleteEndOfLine(string)" });
      return false;
    }
    try
    {
      //string source = trim(parameters[0],"\"");
      string source = parameters[0];
      if(NEW_LINE == "\r\n")
        result = ReplaceAll(source,"\\r\\n", "");
      else
        result = ReplaceAll(source, "\\n", "");
    }
    catch (...)
    {
      printDlgt({ "Error: [String.FuncDeleteEndOfLine]" });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncReplace(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [String.FuncReplace] wrong cmd, format: String.Replace(string)(old value)(new value)" });
      return false;
    }
    try
    {
      string source = parameters[0];
      string old_value = parameters[1];
      if (old_value == "newline")
        old_value = NEW_LINE;
      string new_value = parameters[2];
      result = ReplaceAll(source,old_value, new_value);
    }
    catch (...)
    {
      printDlgt({ "Error: [String.FuncReplace]" });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncSplit(vector<string> parameters, string& result, Composite* node)
  {
    // text, ppl_array_separators, ppl_array_result
    ////// text, separators, ppl_array
    string func_name = "String.FuncSplit";
    vector<string> words;
    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [{0}] wrong cmd, format: String.Split(string)(array_separators | separator)(ppl_array result)", func_name });
      return false;
    }
    //===================================================
    string text = parameters[0];
    string ppl_array_separators = parameters[1];
    string ppl_array_result = parameters[2];
    string name = "", nodes = "";
    Composite* path = nullptr;
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array_separators, path, nodes, name);
    if (b == false)
      return false;
    //===================================================
    Composite* node_array = nullptr;
    Component* one_separator = nullptr;
    for(auto& c : *(path->_children))
    {
      if ((c->name == name) && dynamic_cast<Composite*>(c))
      {
        node_array = (Composite*)c;
        break;
      }
      if ((c->name == name) && dynamic_cast<Leaf*>(c))
      {
        one_separator = c;
        break;
      }
    }
    vector<string> delimiters;
    if ((node_array == nullptr) && (one_separator != nullptr))
    {
      one_separator->value = trim(one_separator->value,"\"");
      if (one_separator->value == "comma") one_separator->value = ",";
      if (one_separator->value == "")      one_separator->value = " ";
      if (one_separator->value == "\\t")   one_separator->value = "\t";
      if (one_separator->value == "space") one_separator->value = " ";
      if (one_separator->value == "tab")   one_separator->value = "\t";
      delimiters.push_back( one_separator->value );
      words = SplitString(text, delimiters);
    }
    //============================================================
    if ((node_array == nullptr) && (one_separator == nullptr))
    {
      delimiters.push_back(parameters[1]);
      words = SplitString(text, delimiters);
    }
    if ((node_array != nullptr) && (one_separator == nullptr))
    {
      if (node_array->_children->empty())
      {
        printDlgt({ "Error: [{0}] array separator is empty [{1}]",  func_name, node_array->name });
        return false;
      }
      for(auto& c : *(node_array->_children))
      {
        c->value = trim(c->value,"\"");
        if (c->value == "comma")
        {
          delimiters.push_back(","); continue;
        }
        if (c->value == "")
        {
          delimiters.push_back(" "); continue;
        }
        if (c->value == "space")
        {
          delimiters.push_back(" "); continue;
        }
        if (c->value == "\\t")
        {
          delimiters.push_back("\t"); continue;
        }
        if (c->value == "tab")
        {
          delimiters.push_back("\t"); continue;
        }
        else
          delimiters.push_back(c->value);
      }
      words = SplitString(text, delimiters);
    }
      
    //================Create new ppl_array==============
    /// operator 'array' creates array by name
    //b = ppl.processing.keyword_dict["array"]
    //    (new List<string>() { ppl_array_result, words.Length.ToString() }, ref result, node);
    //if (b == false)
    //{
      //PPL_array is already created
    //  return false;
    //}

    if (words.empty())
    {
      printDlgt({ "Error: [{0}] split array is empty", func_name });
      return false;
    }
    name = "";
    nodes = "";
    path = nullptr;
    b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array_result, path, nodes, name);
    if (b == false)
      return false;
    //======================================================
    ppl->processing->FuncReAllocArray({ ppl_array_result, "", to_string(words.size()), "" }, result, node);
    //======================================================  
    // delete EndOfLine in words====================
    for (int i = 0; i < words.size(); i++)
    {
      //if(StringContains(words[i],NEW_LINE))
      //  words[i] = words[i].Replace(Environment.NewLine, "");
      words[i] = ReplaceAll(words[i],NEW_LINE,"");
    }
    //==============================================
    for (int j = 0; j < path->_children->size(); j++)
    {
      Component* c = (*(path->_children))[j];
      if (c->name == ppl_array_result)
      {
        for (int i = 0; i < words.size(); i++)
        {
          Composite* ccomp = (Composite*)c;
          (*(ccomp->_children))[i]->value = words[i];
        }
      }
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncSplitCsv(vector<string> parameters, string& result, Composite* node)
  {
    //text, separator, ppl_array_result
      // separator not whitespace
    string func_name = "String.FuncSplitCsv";
    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [{0}] wrong cmd, format: String.SplitCsv(string)(separators)(ppl_array result)", func_name });
      return false;
    }
    if (parameters[1].empty())
    {
      printDlgt({ "Error: [{0}] empty separator", func_name });
      return false;
    }
    string text = parameters[0];
    char separator;
    if (parameters[1] == "comma")    separator = ',';
    if (parameters[1] == "space")    separator = ' ';
    if (parameters[1] == "tab")      separator = '\t';
    else
      separator = parameters[1][0];
    string ppl_array_result = parameters[2];
    // added in FuncReadAllText 
    /*
    byte[] unicodeBytes = { 0xc2, 0xa7 };   // paragraph
    string unicodeString = Encoding.UTF8.GetString(unicodeBytes);
    if (text[0].ToString() == unicodeString)
      text = text.Substring(1);
    if (text[text.Length - 1].ToString() == unicodeString)
      text = text.Substring(0, text.Length - 1);
    */
    if (text[0] == '<')
      text = text.substr(1);
    if (text[text.size() - 1] == '>')
      text = text.substr(0, text.size() - 1);
    vector<string> words = ppl->processing->SplitCsv(text, separator);

      //==================================================
      /*bool b = ppl.processing.keyword_dict["array"]
          (new List<string>() { ppl_array_result, words.Length.ToString() }, ref result, node);
      if (b == false)
      {
        //PPL_array is already created
        return false;
      }*/


    string name = "", nodes = "";
    Composite* path = nullptr;
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array_result, path, nodes, name);
    if (b == false)
      return false;

    //======================================================
    vector<string> parametersReAlloc = { ppl_array_result, "", to_string(words.size()), "" };
    ppl->processing->FuncReAllocArray(parametersReAlloc,  result, node);
    //======================================================  
    // delete EndOfLine in words====================
    for (int i = 0; i < words.size(); i++)
    {
      //if(StringContains(words[i],NEW_LINE))
      //  words[i] = words[i].Replace(Environment.NewLine, "");
      words[i] = ReplaceAll(words[i], NEW_LINE, "");
    }
    //==============================================
    for (int j = 0; j < path->_children->size(); j++)
    {
      Component* c = (*(path->_children))[j];
      if (c->name == ppl_array_result)
      {
        for (int i = 0; i < words.size(); i++)
        {
          Composite* ccomp = (Composite*)c;
          (*(ccomp->_children))[i]->value = words[i];
        }
      }
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncStartsWith(vector<string> parameters, string& result, Composite* node)
  {
    // Determines whether the beginning of this string instance matches the specified string.
    if (parameters.size() != 2)
    {
      printDlgt({ " Error: [String.FuncStartsWith] wrong cmd, format: String.StartsWith(string)( value) " });
      return false;
    }
    string source = parameters[0];
    string value = parameters[1];
    if (value.size() > source.size()) 
    {
      result = "False";
      return false; // If value is longer than source, it can't start with it
    }
    bool b = (source.substr(0, value.size()) == value);
    result = (b == true) ? "True" : "False";
    return true;
  }
  //===========================================================================================
  bool String::FuncSubstring(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2 && parameters.size() != 3) 
    {
      printDlgt({"Error: [String.FuncSubstring] wrong cmd, format: String.Substring(string)( startIndex)[(length)]" });
      return false;
    }

    string tmp = "";
    try 
    {
      int length = 0;
      vector<string> parameters2 = { node->_children->front()->name, "" };
      bool b = ppl->processing->invokeOperator("length",parameters2, tmp,node); 
      if (!b) 
      {
        printDlgt({ "Error: [String.FuncSubstring] wrong name [{0}]", node->_children->front()->name });
        return false;
      }

      length = stoi(tmp);
      string source = parameters[0];
      int startIndex = stoi(parameters[1]);

      if (startIndex >= length) 
      {
        printDlgt({ "Error: [String.FuncSubstring]  [{0}] start index [{1}] out of bounds", node->_children->at(0)->name, parameters[1] });
        return false;
      }

      if (parameters.size() == 3) 
      {
        tmp = parameters[2];
        length = stoi(parameters[2]);
        result = source.substr(startIndex, length);
      }
      else 
      {
        length -= startIndex;
        if (length < 0) 
        {
          printDlgt({ "Error: [String.FuncSubstring] length [{0}] is wrong",  tmp });
          return false;
        }
        result = source.substr(startIndex, length);
      }
    }
    catch (const exception&) 
    {
      printDlgt({"Error: [String.FuncSubstring] start [{0}] index or length is wrong", tmp });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncToCharArray(vector<string> parameters, string& result, Composite* node)  //  creates array
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [String.FuncToCharArray] wrong cmd, format: String.ToCharArray(string)( char array)" });
      return false;
    }

    string str = parameters[0];
    string fullname = parameters[1];
    string name = "";

    // Convert string to char array
    vector<char> arr(str.begin(), str.end());

    string func_name = "String.FuncToCharArray";
    Composite* path = nullptr;
    string nodes = "";

    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
      return false;

    ppl->processing->FuncReAllocArray({ fullname, "", to_string(arr.size()), "" }, result, node);
    for (Component* c : *(path->_children)) 
    {
      if (c->name == name) 
      {
        vector<Component*>* lc = ((Composite*)c)->_children;
        int i = 0;
        for (char ch : arr) 
        {
          (*lc)[i]->name = "#";
          (*lc)[i++]->value = string(1, ch);
        }
      }
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncToLower(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [String.FuncToLower] wrong cmd, format: String.ToLower(string)" });
      return false;
    }
    //result = parameters[0].ToLower();
    string lowerStr = parameters[0]; // Create a copy of the string
    transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(),
      [](unsigned char c) { return tolower(c); });
    result = lowerStr;
    return true;
  }
  //===========================================================================================
  bool String::FuncToUpper(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [String.FuncToUpper] wrong cmd, format: String.ToUpper(string)" });
      return false;
    }
    string upperStr = parameters[0];
    transform(upperStr.begin(), upperStr.end(), upperStr.begin(),
      [](unsigned char c) { return toupper(c); });
    result = upperStr;
    return true;
  }
  //===========================================================================================
  bool String::FuncTrim(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() < 1)
    {
      printDlgt({ "Error: [String.FuncTrim] wrong cmd, format: String.Trim(string)[(string)]" });
      return false;
    }
    result = "";
    try
    {
      switch (parameters.size())
      {
        case 1:
          result = trim(parameters[0]);   //parameters[0].Trim();
        break;
        case 2:
          result = trim(parameters[0], parameters[1]);
        break;
        default:
          printDlgt({ "Error: [String.FuncTrim] wrong number of argss" });
          return false;
        break;
      }
    }
    catch (...)
    {
      printDlgt({"Error: [String.FuncTrim] [{0}]",parameters[1] });
      return false;
    }
    return true;
  }
  //===========================================================================================
  bool String::FuncChar(vector<string> parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [String.FuncChar] wrong cmd, format: String.Char(string)( Index)" });
      return false;
    }
    result = "";
    string tmp = "";
    string source = parameters[0];
    tmp = parameters[1];
    int index = 0;
    if (!TryParse(parameters[1], index))
    {
      printDlgt({ "Error: [String.FuncChar] index not digit [{0}]", tmp });
      return false;
    }
    if (index >= source.size())
    {
      printDlgt({ "Error: [String.FuncChar] [{0}] index out of bounds[{1}]", source, to_string(index) });
      return false;
    }
    result = source[index];
    return true;
  }
  //===========================================================================================
}