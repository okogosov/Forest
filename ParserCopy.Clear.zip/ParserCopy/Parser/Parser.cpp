//================================================================
#include "Parser.h" 
#include <iostream>
#include <algorithm>
#include <unordered_set>
#include <string>
#include <stack>

using namespace std;

namespace PPLNS
{
   const std::string BLOCK_NAME_INDICATOR = "#";

  // Forward declarations for helper functions used in Parser
  // Assuming these are part of PPL class or static helper functions defined elsewhere
  // (They are defined below in this file, ensuring they are available)
  bool isSingleLineCommentStart(char c1, char c2);
  bool isMultiLineCommentStart(char c1, char c2);
  bool isMultiLineCommentEnd(char c1, char c2);
  bool handleEscapedCharacter(const string& text, long& index);


  //================================================================
  // Utility function to trim whitespace from both ends of a string.
  std::string PPL::trim(const std::string& str, const std::string& chars)
  {
    size_t start = str.find_first_not_of(chars);
    if (start == std::string::npos) {
      return ""; // String contains only whitespace or is empty.
    }
    size_t end = str.find_last_not_of(chars);
    return str.substr(start, end - start + 1);
  }
  //================================================================
  bool PPL::TrimPPL(std::string& text)
  {
    if (text.length() >= 2) // Consider what constitutes a "trim-able" string
    {
      text = trim(text);
      return true;
    }
    return false;
  }

  // Helper function to check if characters indicate a single-line comment start
  bool isSingleLineCommentStart(char c1, char c2)
  {
    return (c1 == '/' && c2 == '/');
  }

  // Helper function to check if characters indicate a multi-line comment start
  bool isMultiLineCommentStart(char c1, char c2)
  {
    return (c1 == '/' && c2 == '*');
  }

  // Helper function to check if characters indicate a multi-line comment end
  bool isMultiLineCommentEnd(char c1, char c2)
  {
    return (c1 == '*' && c2 == '/');
  }

  // Helper function to handle escaped characters within quotes
  // This function is still used by CheckNumberOfParentheses/Quotes
  bool handleEscapedCharacter(const string& text, long& index)
  {
    if (index + 1 < text.length()) // Ensure there's a next character
    {
      if (text[index] == '\\' && (text[index + 1] == '\"' || text[index + 1] == '\\'))
      {
        index++; // Skip the escaped character
        return true;
      }
    }
    return false;
  }

  //================================================================
  // CheckNumberOfParentheses may be used not only in Parser but also in other contexts,
  // so includes commentary in line
  bool PPL::CheckNumberOfParentheses(const string& text)
  {
    bool inSingleLineComment = false;
    bool inMultiLineComment = false;
    bool inQuotes = false;
    int parenthesisCount = 0;

    for (long i = 0; i < text.length(); ++i)
    {
      char currentChar = text[i];
      char nextChar = (i + 1 < text.length()) ? text[i + 1] : '\0';

      if (currentChar == '\"')
      {
        if (!inMultiLineComment && !inSingleLineComment)
        {
          inQuotes = !inQuotes;
        }
        continue;
      }

      if (inQuotes)
      {
        if (handleEscapedCharacter(text, i))
          continue;
      }
      else // Not in quotes
      {
        if (isSingleLineCommentStart(currentChar, nextChar))
        {
          inSingleLineComment = true;
          i++; // Skip next character
          continue;
        }
        if (isMultiLineCommentStart(currentChar, nextChar))
        {
          inMultiLineComment = true;
          i++; // Skip next character
          continue;
        }
        if (isMultiLineCommentEnd(currentChar, nextChar))
        {
          inMultiLineComment = false;
          i++; // Skip next character
          continue;
        }

        if (inMultiLineComment)
          continue;

        if (currentChar == '\n')
        {
          inSingleLineComment = false;
          continue;
        }

        if (!inSingleLineComment) // Only check parentheses if not in any comment
        {
          if (currentChar == '(')
            parenthesisCount++;
          if (currentChar == ')')
            parenthesisCount--;
        }
      }
    }

    if (parenthesisCount != 0)
    {
      cout << "##################" << endl;
      cout << "Error: [CheckNumberOfParentheses] wrong number of parentheses: " << text << endl;
      cout << "##################" << endl;
      return false;
    }
    return true;
  }

  //================================================================
  string PPL::GetString(const string& str, const string& begin, const string& end)
  {
    string ret = "";
    size_t startIndex = str.find(begin);
    if (startIndex == string::npos)
      return "";

    startIndex += begin.length();
    size_t endIndex;

    if (end.empty())
      endIndex = str.length();
    else
      endIndex = str.rfind(end, str.length());

    if (endIndex == string::npos || endIndex < startIndex) // Added check for endIndex < startIndex
      return "";

    ret = str.substr(startIndex, endIndex - startIndex);
    return trim(ret);
  }
  
  //================================================================
  vector<string> PPL::SmartSplitString(string input, string delimiters, bool removeEmptyToken)
  {
    vector<string> result;
    string token;
    bool inQuotes = false;

    for (char c : input)
    {
      if (c == '\0') // End of string
        break;

      if (c == '\"')
      {
        inQuotes = !inQuotes;
      }

      if (inQuotes || delimiters.find(c) == string::npos)
      {
        token += c;
      }
      else
      {
        if (!token.empty() || !removeEmptyToken)
        {
          result.push_back(token);
        }
        token.clear();
      }
    }

    // Add the last token if it's not empty or if empty tokens are allowed
    if (!token.empty() || !removeEmptyToken)
    {
      result.push_back(token);
    }

    return result;
  }

  //================================================================
  // CheckNumberOfQuotes may be used not only in Parser but also in other contexts,
  // so includes commentary in line
  bool PPL::CheckNumberOfQuotes(const string& input)
  {
    if (input.empty())
      return true;

    bool inSingleLineComment = false;
    bool inMultiLineComment = false;
    bool inQuotes = false;

    for (long j = 0; j < input.size(); ++j)
    {
      char currentChar = input[j];
      char nextChar = (j + 1 < input.size()) ? input[j + 1] : '\0';

      // Handle comments first
      if (isSingleLineCommentStart(currentChar, nextChar))
      {
        inSingleLineComment = true;
        j++; // Skip next character
        continue;
      }
      if (isMultiLineCommentStart(currentChar, nextChar))
      {
        inMultiLineComment = true;
        j++; // Skip next character
        continue;
      }
      if (isMultiLineCommentEnd(currentChar, nextChar))
      {
        inMultiLineComment = false;
        j++; // Skip next character
        continue;
      }

      if (inMultiLineComment)
        continue;

      if (currentChar == '\n')
      {
        inSingleLineComment = false;
        continue;
      }

      // Handle quotes outside of comments
      if (!inSingleLineComment && !inMultiLineComment)
      {
        if (currentChar == '\"')
        {
          inQuotes = !inQuotes;
          continue;
        }
      }

      // Handle escaped characters inside quotes
      if (inQuotes)
      {
        if (handleEscapedCharacter(input, j))
          continue;
      }
    }

    if (inQuotes)
    {
      cout << "Error: [CheckNumberOfQuotes] number of opened and closed quotes are not equal: " << input << endl;
      return false;
    }

    return true;
  }

  //=====================================================
  char PPL::GetNextNotWhiteSpaceSymbol(const string& input, long index)
  {
    for (long j = index; j < input.size(); ++j)
    {
      if (!isspace(input[j]))
      {
        return input[j];
      }
    }
    return '\0';
  }

  //=================================================
  string PPL::GetCommand(string input)
  {
    string result = "";
    for (char c : input)
    {
      if (c == ' ' || c == '(' || c == ';' || c == '\r' || c == '\n') 
        break;
      else
        result += c;
    }
    return result;
  }

  //=================================================
  // Add parentheses around all input if they are omitted
  void PPL::AddParentheses(string& input)
  {
    input = trim(input); // Trim first to handle leading/trailing whitespace

    if (input.empty())
      return;

    // Check if parentheses are already present or if it's a special case like a single command without args
    if (input.front() == '(' && input.back() == ')')
    {
      return;
    }

    if (input.back() == ';')
    {
      input = "(" + input.substr(0, input.length() - 1) + ");";
    }
    else
    {
      input = "(" + input + ")";
    }
  }

  //=================================================
  string cmds_OneArgument[]
  { "help", "?",  "import", "readcode", "rc",
              "readdata", "rd",
              "showcode",  "sh", "createnode",
              "d","display", "dd", "dstruct",
              "dn","displaynodes",
              "del", "code", "recreate",
              "debugppl","dbg", "traceppl","log","withset",
              "sumdata",
              "readline", "datanames",
              "writearray",
              "stop",
              "calc","argc", "return", "length", "type" };
  const int cmds_OneArgument_Length = sizeof(cmds_OneArgument) / sizeof(cmds_OneArgument[0]);
  unordered_set<string> set_cmds_OneArgument(cmds_OneArgument, cmds_OneArgument + cmds_OneArgument_Length);

  //=================================================
  string NoParametersCommands[]
  { "display","displaynodes","d","dn", "dstruct","datanames", "funcname", "instancename","continue",
    "dstree",
   "suspend","readline","argc",
    "start","stop",
    "code", "showcode", "recreate", "sumdata","debugppl", "dbg", "traceppl", "log", "return", "getresult"
  };
  const int NoParametersCommands_Length = sizeof(NoParametersCommands) / sizeof(NoParametersCommands[0]);

  //=================================================
  string creation_cmds[] = { "var", "const", "array", "storage" };
  const int creation_cmds_Length = sizeof(creation_cmds) / sizeof(creation_cmds[0]);
  unordered_set<string> set_creation_cmds(creation_cmds, creation_cmds + creation_cmds_Length);

  //=================================================
  void PPL::ClearStackNodes(stack <Composite*> nodes)
  {
    while (!nodes.empty())
    {
      Composite* comp = nodes.top();
      nodes.pop();
      delete comp;
      comp = nullptr;
    }
  }

  //=================================================
  // Removes all single-line and multi-line comments from the input string
  void PPL::RemoveComments(std::string& input)
  {
    bool inQuotes = false;
    bool inSingleLineComment = false;
    bool inMultiLineComment = false;

    for (long k = 0; k < input.size(); ++k)
    {
      char c = input[k];
      char nextChar = (k + 1 < input.size()) ? input[k + 1] : '\0';

      if (inQuotes)
      {
        // Handle escaped quotes or backslashes within quotes
        if (c == '\\' && (nextChar == '\"' || nextChar == '\\'))
        {
          k++; // Skip the escaped character
        }
        else if (c == '\"')
        {
          inQuotes = false; // End of quotes
        }
      }
      else if (inSingleLineComment)
      {
        if (c == '\n')
        {
          inSingleLineComment = false; // End of single-line comment
        }
        input[k] = ' '; // Replace comment character with space
      }
      else if (inMultiLineComment)
      {
        if (c == '*' && nextChar == '/')
        {
          inMultiLineComment = false; // End of multi-line comment
          input[k] = ' '; // Replace '*'
          input[k + 1] = ' '; // Replace '/'
          k++; // Skip next character
        }
        else
        {
          input[k] = ' '; // Replace comment character with space
        }
      }
      else // Not in any special state (quotes, single-line, multi-line comment)
      {
        if (c == '\"')
        {
          inQuotes = true; // Start of quotes
        }
        else if (c == '/' && nextChar == '/')
        {
          inSingleLineComment = true; // Start of single-line comment
          input[k] = ' '; // Replace '/'
          input[k + 1] = ' '; // Replace '/'
          k++; // Skip next character
        }
        else if (c == '/' && nextChar == '*')
        {
          inMultiLineComment = true; // Start of multi-line comment
          input[k] = ' '; // Replace '/'
          input[k + 1] = ' '; // Replace '*'
          k++; // Skip next character
        }
        // Other characters are left as is, as they are not part of a comment
      }
    }
  }

  // Helper for parsing: handles opening parenthesis
  void PPL:: handleOpenParenthesis(char c, stack<char>& parentheses, stack<Composite*>& nodes,
    string& value, string& name)
  {
    if (parentheses.empty())
    {
      parentheses.push(c);
      Composite* root = new Composite("root");
      nodes.push(root);
      value = "";
    }
    else if (parentheses.top() == ')') // This case should ideally not happen if parentheses are balanced.
    {
      parentheses.pop(); // Pop the ')'
      parentheses.push(c); // Push the new '('
      value = "";
    }
    else if (parentheses.top() == '(')
    {
      string value_tmp = "";
      name = "";
      if (!value.empty())
      {
        value = PPL::trim(value);
        size_t bracketPos = value.find("[");
        if (bracketPos != string::npos)
        {
          name = value.substr(0, bracketPos);
          value_tmp = PPL::GetString(value, "[", "]");
        }
        else
        {
          name = value;
        }
      }

      if (name.empty())
      {
        name = BLOCK_NAME_INDICATOR; // Internal block
        value_tmp = "internal_block";
      }

      Composite* node = new Composite(PPL::trim(name), value_tmp);

      value = "";
      Composite* parent = nodes.top();
      parent->Add(node);
      nodes.push(node);
      parentheses.pop(); // Pop the old '('
      parentheses.push(c); // Push the new '('
    }
  }

  // Helper for parsing: handles closing parenthesis
  bool handleCloseParenthesis(char c, stack<char>& parentheses, stack<Composite*>& nodes,
    string& value, string& name, long& counter_leaf, Composite* root)
  {
    if (parentheses.top() == '(')
    {
      string value_tmp = "";
      string value_orig = value; // Keep original value for quoted string check
      name = "";

      if (!value.empty())
      {
        if (value.find('\"') == string::npos) // No quotes in value
        {
          value_tmp = PPL::GetString(value, "[", "]");
          size_t bracketPos = value.find_last_of('[');
          if (bracketPos != string::npos && bracketPos > 0)
          {
            // The check below for CheckNumberOfParentheses on 'value'
            // is for nested parentheses within a value, not overall string balance.
            // This might still be useful for complex leaf values.
            if (!PPL::CheckNumberOfParentheses(value))
            {
              return false; // Error in nested parentheses within a leaf value
            }
            name = value.substr(0, bracketPos);
          }
          else
          {
            name = value;
          }
        }
        else // Value contains quotes
        {
          value = PPL::trim(value);
          if (value.front() == '\"' && value.back() == '\"') // Entire value is a quoted string
          {
            name = PPL::trim(value.substr(1, value.length() - 2)); // Remove outer quotes
            value_tmp = ""; // No additional value if name is the quoted string
          }
          else
          {
            // var(x["===[xxx]==="])
            value_tmp = PPL::GetString(value, "[", "]");
            size_t offset = value.find("[");
            if (offset == 0) // Starts with '['
            {
              name = BLOCK_NAME_INDICATOR;
            }
            else if (offset == string::npos) // No '['
            {
              name = value;
            }
            else
            {
              name = value.substr(0, offset);
            }
          }
        }
      }

      bool cmdFlag = false;
      vector<string> name_split = PPL::SmartSplitString(PPL::trim(name), " ", true); // Trim name before splitting

      // Check if root exists and has children before accessing them
      if (root && root->_children && root->_children->size() > 0)
      {
        Component* firstChild = root->_children->front();
        if (firstChild && firstChild->name != "sinit" && firstChild->name != "sset")
        {
          if (name_split.empty()) // name = "  "
          {
            Leaf* leaf1 = new Leaf(name, ""); // Name might still be empty if trimmed to empty string
            counter_leaf++;
            if (counter_leaf % 100000 == 0)
              cout << "1 " << counter_leaf << " leaf " << leaf1->name << endl;

            parentheses.pop();
            parentheses.push(c);
            Composite* parent1 = nodes.top();
            parent1->Add(leaf1);
            cmdFlag = true;
          }
        }
      }

      if (!name_split.empty() && set_cmds_OneArgument.count(name_split[0]))
      {
        if (name_split.size() == 2)
        {
          Leaf* leaf2 = new Leaf(name_split[1], "");
          counter_leaf++;
          if (counter_leaf % 100000 == 0)
            cout << "3 " << counter_leaf << " leaf " << leaf2->name << endl;
          Composite* node2 = new Composite(name_split[0], "");
          node2->Add(leaf2);
          parentheses.pop();
          parentheses.push(c);
          Composite* parent2 = nodes.top();
          parent2->Add(node2);
          cmdFlag = true;
        }
      }

      if (cmdFlag)
        return true;

      // Final processing for the leaf
      name = PPL::trim(name); // Ensure name is trimmed before creating leaf
      Leaf* leaf = new Leaf(name, value_tmp);
      counter_leaf++;
      if (counter_leaf % 100000 == 0)
        cout << "leaf_counter = " << counter_leaf << " leaf->name = " << ((Component*)leaf)->name << endl;

      value = "";
      parentheses.pop();
      parentheses.push(c);
      Composite* parent = nodes.top();
      parent->Add(leaf);
      return true;
    }
    else if (parentheses.top() == ')')
    {
      if (nodes.empty())
        return true; // Should not happen in balanced parentheses, but defensively
      nodes.pop();
      parentheses.pop();
      parentheses.push(c);
      return true;
    }
    return true; // Should not reach here in a balanced scenario
  }

  //=================================================
  //=================================================
  Composite* PPL::Parser(const string& input0, bool CheckQuotesAndParentheses)
  {
    stack<char> parentheses;
    stack<Composite*> nodes;
    Composite* root = nullptr;

    if (input0.empty())
      return nullptr;

    string input = input0;

    // IMPORTANT: Normalize whitespace, especially the non-breaking space, BEFORE any parsing or checks
    for (char& ch : input) 
    {
      if (ch == '\xA0') 
      { // Non-breaking space
        ch = ' '; // Replace with standard space
      }
    }

    // Perform quote and parenthesis checks on the raw (normalized) input first
    if (CheckQuotesAndParentheses)
    {
      if (!CheckNumberOfQuotes(input))
      {
        ClearStackNodes(nodes);
        return nullptr;
      }
      if (!CheckNumberOfParentheses(input))
      {
        ClearStackNodes(nodes);
        return nullptr;
      }
    }

    RemoveComments(input);

    string cmd1 = GetCommand(input);
    if (set_cmds_OneArgument.count(cmd1))
    {
      string arg = PPL::trim(input.substr(cmd1.length()));
      if (!arg.empty())
      {
        if (arg.front() != '(')
        {
          if (arg.back() != ';')
            arg = "(" + arg + ")";
          else
            arg = "(" + arg.substr(0, arg.length() - 1) + ");";
        }
        input = cmd1 + " " + arg;
      }
    }
    AddParentheses(input);

    string value = "";
    string name = "";
    int open_brackets = 0;
    bool inQuotes = false;
    long counter_leaf = 0;

    // Comment handling logic is now removed from here, as RemoveComments handles it.

    for (long k = 0; k < input.size(); ++k)
    {
      char c = input[k];
      char nextChar = (k + 1 < input.size()) ? input[k + 1] : '\0'; // Still needed for escaped chars etc.

      switch (c)
      {
      case '\"':
        value.push_back(c);
        inQuotes = !inQuotes;
        break;
      case '\\':
      {
        if (k + 1 < input.size())
        {
          if (nextChar == '\\')
          {
            value.push_back('\\');
            k++;
          }
          else if (nextChar == '\"')
          {
            value.push_back('\"');
            k++;
          }
          else
          {
            value.push_back(c); // Unrecognized escaped character, treat as literal backslash
          }
        }
        else
        {
          value.push_back(c); // Trailing backslash
        }
      }
      break;
      case '\t':
      case '\n':
      case '\r':
        // Only append whitespace if within quotes, otherwise skip
        if (inQuotes)
        {
          value.push_back(c);
        }
        break;

      case '[':
        if (!inQuotes)
          open_brackets++;
        value.push_back(c);
        break;
      case ']':
        if (!inQuotes)
          open_brackets--;
        value.push_back(c);
        break;
      case ';':
        if (open_brackets != 0 || inQuotes)
        {
          value.push_back(c);
        }
        break;

      case '(':
        if (open_brackets != 0 || inQuotes)
        {
          value.push_back(c);
        }
        else
        {
          handleOpenParenthesis(c, parentheses, nodes, value, name);
          if (nodes.empty()) // If handleOpenParenthesis failed to push a root
          {
            ClearStackNodes(nodes);
            return nullptr;
          }
          // Ensure root is correctly assigned the very first time it's created.
          // If the first '(' creates the root, it will be the only item on the stack.
          // If subsequent '(' calls create child nodes, 'root' should remain pointing to the top-level root.
          if (root == nullptr) { // Only assign root once at its true creation
            root = nodes.top();
          }
        }
        break;

      case ')':
        if (open_brackets != 0 || inQuotes)
        {
          value.push_back(c);
        }
        else
        {
          if (!handleCloseParenthesis(c, parentheses, nodes, value, name, counter_leaf, root))
          {
            ClearStackNodes(nodes);
            return nullptr;
          }
        }
        break;

      default:
        value.push_back(c);
        break;
      }
    }

    if (open_brackets != 0)
    {
      cout << "Error: [Parser] number of brackets are wrong" << endl;
      ClearStackNodes(nodes);
      if (root) delete root;  // It's good practice to delete 'root' here if it was partially built
      return nullptr;
    }

    if (!parentheses.empty())
      parentheses.pop(); // Pop the last '('
    if (!nodes.empty())
      nodes.pop(); // Pop the root node (it's returned, not deleted by ClearStackNodes unless error path)


    if (root == nullptr) // If parsing didn't create a root (e.g., empty valid input, or errors pre-root)
    {
      return nullptr;
    }

    // Post-parsing validations and transformations
    for (int i = 0; i < NoParametersCommands_Length; i++)
      root->ConvertLeafToNode(NoParametersCommands[i]);

    Component* firstComp = root->First();
    if (firstComp && dynamic_cast<Composite*>(firstComp))
    {
      Composite* ccomp = static_cast<Composite*>(firstComp);
      if (ccomp->_children && !ccomp->_children->empty())
      {
        string name1 = ccomp->First()->name;
        if (set_creation_cmds.count(ccomp->name))
        {
          if (name1 == "all" || name1 == "True" || name1 == "False")
          {
            cout << "Error: [Parser] name [" << name1 << "] can not be name of variable" << endl;
            ClearStackNodes(nodes); // In case any nodes were pushed back
            delete root; // Delete the partially built root
            return nullptr;
          }
        }
      }
    }

    // Handle "set" command special case for empty values
    if (firstComp && firstComp->name == "set")
    {
      Composite* cc = static_cast<Composite*>(firstComp);
      bool hasEmptyChild = false;
      if (cc->_children) { // Ensure _children is not null
        for (Component* child : *(cc->_children))
        {
          if (child->name.empty())
          {
            hasEmptyChild = true;
            break;
          }
          if (dynamic_cast<Composite*>(child))
          {
            Composite* cc2 = static_cast<Composite*>(child);
            if (cc2->_children) { // Ensure _children is not null
              for (Component* c2 : *(cc2->_children))
              {
                if (c2->name == "\"\"\"") // This might be a placeholder. Consider a dedicated constant.
                  c2->name = "#quote#";
              }
            }
          }
        }
      }
      if (hasEmptyChild)
      {
        ClearStackNodes(nodes);
        return root;
      }
    }

    string node_name_for_error = ""; // Pass a string reference to get the node name
    Component* emptyLeafFound = root->FindEmptyLeaf(nullptr, node_name_for_error); 
    if (emptyLeafFound != nullptr)
    {
      cout << "Error: [Parser] empty leaf in node [" << node_name_for_error << "]" << endl;
      ClearStackNodes(nodes);
      delete root; // Delete the partially built root
      return nullptr;
    }

    ClearStackNodes(nodes); 
    return root;
  }
} // namespace PPLNS