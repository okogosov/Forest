#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Array.h"

using namespace std;
namespace PPLNS
{
  static Array* ARRAYInstance = nullptr;

  void ARRAY_CreateInstance(PPL* ppl)
  {
    ARRAYInstance = new Array(ppl);
    ARRAYInstance->AddToKeywordDictionary();
  }

  Array::Array(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Array::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Max", FuncMax);
    AddKeyword("Min", FuncMin);
    AddKeyword("Sum", FuncSum);
    AddKeyword("Average", FuncAverage);
    AddKeyword("Sum2", FuncSum2);
    AddKeyword("Sub2", FuncSub2);
    AddKeyword("Mult2", FuncMult2);
    AddKeyword("Div2", FuncDiv2);
    AddKeyword("Sort", FuncSort);
    AddKeyword("Reverse", FuncReverse);
    help_dict->insert({ "help", "\tArray.help([name])" });
    help_dict.Add("Max", "\t...");
    help_dict.Add("Min", "\t...");
    help_dict.Add("Sum", "\t...");
    help_dict.Add("Average", "\t...");
    help_dict.Add("Sum2", "\t...");
    help_dict.Add("Sub2", "\t...");
    help_dict.Add("Mult2", "\t...");
    help_dict.Add("Div2", "\t...");
    help_dict.Add("Sort", "\t...");
    help_dict.Add("Reverse", "\t...");
    for (const auto pair : *keyword_dict)
    {
      string key = "Array." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList->insert({ "Array", this });
  }
  //=========================================================
  bool Array::FuncMax(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncMin(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncSum(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncAverage(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncSum2(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncSub2(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncMult2(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncDiv2(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncSort(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Array::FuncReverse(vector<string> parameters, string& result, Composite* node) { return true; }
}
