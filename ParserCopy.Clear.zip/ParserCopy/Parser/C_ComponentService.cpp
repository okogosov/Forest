#include "Component.h"
#include <string.h>
#include <iostream>

namespace PPLNS
{
  Component* Composite::GetNode(string name)   
  {
    if (name == "")
      return nullptr;

    Composite* Node = this;
    Component* TmpNode = nullptr;
    vector<string> tokens = SplitString(name, '.');
    try
    {
      int size = (int)(tokens.size());
      for (int j = 0; j < size; j++)
      {
        TmpNode = nullptr;
        for(auto& comp : *(Node->_children))
        {
          if (comp->name == tokens[j])
          {
            TmpNode = comp;
            break;
          }
        }
        if (TmpNode == nullptr)
          return nullptr;

        if (dynamic_cast<Leaf*>(TmpNode))
          return nullptr;
        Node = (Composite*)TmpNode;
      }
      return Node;
    }
    catch (out_of_range const& exc)
    {
      //printDlgt({ "Error: GetNode [{0}]", exc.what() });
      cout << "Error: GetNode [" << exc.what() << "exc.what()" << endl;
      return nullptr;
    }  
  }
  //=====================================================
   //=====================================================
  string Component::trim(const string& source, const string& chars)
  {
    const auto first = source.find_first_not_of(chars);
    if (first == string::npos)
      return ""; // string contains only chars
    const auto last = source.find_last_not_of(chars);
    return source.substr(first, last - first + 1);
  }
  vector<string> Component::SplitString(string input, char delimiter, bool RemoveEmptyToken)
  {
    vector<string> v;
    v.reserve(10);
    string token;
    size_t pos1 = 0;
    size_t pos2 = 0;
    while ((pos2 = input.find(delimiter, pos1)) != string::npos)
    {
      token = input.substr(pos1, pos2 - pos1);
      if (!RemoveEmptyToken)
        v.push_back(token);
      else
      {
        if (!token.empty())
          v.push_back(token);
      }
      pos1 = pos2 + 1;
    }
    // last token
    pos2 = input.size();
    token = input.substr(pos1, pos2 - pos1);
    if (!RemoveEmptyToken)
      v.push_back(token);
    else
    {
      if (!token.empty())
        v.push_back(token);
    }
    return v;
  }
  //=====================================================
  bool Component::IsDigitsOnly(string str)
  {
    if (str == "")
    {
      return false;
    }
    for (char& c : str)
    {
      //if ((c < '0' || c > '9') && (c != '-'))
      if ((c == '.') || (c == '+'))
        continue;
      if ((c < '0' || c > '9') && (c != '-'))
        return false;
    }
    return true;
  }
  //================================================================
  bool Component::StringContains(string src, string pattern)
  {
    if (src.find(pattern) == string::npos)
      return false;
    return true;
  }
  //================================================================   
  // when operator "break" is written  without parentheses and set as Leaf
  // must be convert to Node
  void Composite::ConvertLeafToNode(string name)
  {
    for(int i = 0; i < _children->size();i++)
    {     
      Component* c = (*_children)[i];
      if (dynamic_cast<Leaf*>(c))
      {
        if (c->name == name)
        {
          Composite* comp = new Composite(name, "");
          this->Insert(i, comp);
          this->Remove((*_children)[i + 1]);
        }
      }
      else
        ((Composite*)c)->ConvertLeafToNode(name);
    }
  }
  //======================================================  
  Component* Composite::ConvertNodeToLeaf(string node_name, string name)
  {
    int i = 0;
    for (auto& c : *_children)
    {
       if (dynamic_cast<Composite*>(c))
      {
        if (c->name == node_name)
        {
          Leaf* leaf = new Leaf(name, "");
          Insert(i, (Component*)leaf);
          Remove((*_children)[i + 1]);
          return leaf;
        }
      }
      i++;
    }
    return nullptr;
  }
  //======================================================
  void Composite::GetPredecessorNode(string name, Composite*& node)
  {    
    if (this->name == "root")
    {
      node = nullptr;
      return;
    }
    if (this->name == name)
    {
      node = this;
      return;
    }
    else
    {
      parent->GetPredecessorNode(name, node);
    }
    return;
  }
  //=======================================================
  void Composite::GetSuccessorNode(string name, Composite*& node)
  {
    node = nullptr;
    
    if (this->name == name)
    {
      node = this;
      return;
    }
    vector<Component*>::iterator it;
    for (it = _children->begin(); it != _children->end(); it++)
    {
      if (auto cc = dynamic_cast<Composite*>(*it)) 
      {
        cc->GetSuccessorNode(name, node);
      }
    }
  }
  //=======================================================
  // RestoreExpressionFromTree - to concat & save all names under node to string for evaluation
  // recursive
  void Composite::RestoreExpressionFromTree(Composite* init_node, string& result)
  {
    if (_children->size() == 0) 
    {
      result = "";
      return;
    }
    if (result == "") 
    {
      result = this->name;
      init_node = this;
    }
    for (auto c : *_children)
    {
      if (dynamic_cast<Leaf*>(c))
      {
        if (c->value == "")
          result += "(" + c->name + ")";
        else
          result += "(" + c->name + "[" + c->value + "])";   // index in array
        continue;
      }
      else
      {
        result += "(" + c->name;
        ((Composite*)c)->RestoreExpressionFromTree(init_node, result);
      }
    }
    if (this != init_node)
      result += ")";
  }
  //=======================================================
  // GetComponentByName("do") is called in FuncLoop
  Component* Composite::GetComponentByName(string name)
  {
    // search in this node only
    if (_children->size() == 0)
      return nullptr;
    for (auto c : *_children)
    {
      if (c->name == name)
        return  c;   
    }
    return nullptr;
  }
  //=======================================================
  // recursive
  // working array & var for recursive function instead of static
  //string[] gcn_tokens = null;
  //int gcn_current_level = 0;
  //=======================================================
  void Composite::GetComponentByName(Composite*& Node, string fullname, Component*& component,  vector<string>& gcn_tokens, int& gcn_current_level)

  {  // name = nodes.name
    if (fullname == "")
      return;
    
    component = nullptr;
    if (Node == nullptr)
    {
      string name = fullname;
      if (name.find("NS.") != string::npos)
        name = name.erase(0, 3);
      if (name.find("Global.") != string::npos)
        name = name.erase(0, 7);
      else
      {
        if (name.find("Local.") != string::npos)
          name = name.erase(0, 6);
      }

      Node = this;
      gcn_tokens = SplitString(name, '.');
      gcn_current_level = 1;
    }

    int max_level = (int)(gcn_tokens.size());
    string name0  = gcn_tokens[max_level - 1];

    if (_children->size() == 0)
      return;

    int children_size = (int)(_children->size());
    string node_name;
    string name2;
    Component* comp = nullptr;
    //======================================================
    int j = 0;
    for (auto& comp : *_children)
    {
      node_name = gcn_tokens[gcn_current_level - 1];
      name2 = comp->name;
      if (name2 == node_name)
      {
        if (gcn_current_level == max_level)
        {
          component = comp;
          // Node is component.parent
          return;
        }
        if (dynamic_cast<Composite*>(comp))
        {
          gcn_current_level++;
          Node = (Composite*)((*(Node->_children))[j]);
          Node->GetComponentByName(Node, name, component, gcn_tokens, gcn_current_level);
          return;
        }
      }
      j++;
    }
    //======================================================
    if (gcn_current_level <= max_level - 1)
      Node = nullptr;
 
    return;
  }
  void Composite::Clone(Composite*& clone, Composite*& node_tmp)  
  {
    if (clone == nullptr) 
    {
      clone = node_tmp = new Composite(this->name, this->value);
      clone->parent = this->parent; // Set parent
    }
    //node_tmp->_children->reserve(this->_children->size());
    for (const auto& c : *_children) 
    {
      if (Leaf* leaf = dynamic_cast<Leaf*>(c)) 
      {
        node_tmp->Add(new Leaf(leaf->name, leaf->value));
      }
      else 
      {
        Composite* new_node_tmp = new Composite(c->name, c->value);
        node_tmp->Add(new_node_tmp);
        node_tmp = new_node_tmp;
        //static_cast<Composite*>(c)->Clone(clone, node_tmp);
        ((Composite*)c)->Clone(clone, node_tmp);
      }
    }
    node_tmp = (Composite*)(node_tmp->parent);
    return;
  }
  //===============================================
  string  Composite::Get_FullPathName()
  {
    string name = "";
 
    stack<string> stack_names;
    Composite* node = this;

    while (true) 
    {
      stack_names.push(node->name);
      if (node->name == "root")
        break;
      node = node->parent;
    }
    while (!stack_names.empty()) 
    {
      string tmp = stack_names.top();
      stack_names.pop();
      if (tmp != "root")
        name = name + tmp + ".";
    }
    name = name.substr(0, name.length() - 1);
    return name;
  }
}