#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Convert.h"
#include <bitset>

using namespace std;
namespace PPLNS
{
  static Convert* CONVERTInstance = nullptr;

  void Convert_CreateInstance(PPL* ppl)
  {
    CONVERTInstance = new Convert(ppl);
    CONVERTInstance->AddToKeywordDictionary();
  }

  Convert::Convert(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void Convert::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("StringToInt32Array", FuncStringToInt32Array);
    AddKeyword("StringToHexArray", FuncStringToHexArray);
    AddKeyword("HexToBin", FuncHexToBin);
    AddKeyword("BinToHex", FuncBinToHex);
    AddKeyword("IntToHex", FuncIntToHex);
    AddKeyword("HexToInt", FuncHexToInt);
    AddKeyword("IntToBin", FuncIntToBin);
    AddKeyword("BinToInt", FuncBinToInt);

    help_dict->insert({ "help", "\tConvert.help([name])" });
    help_dict->insert({ "StringToInt32Array", "\tString chararacters convert to int32 array Convert.StringToInt32Array(string)(\"Int32 array\")" });
    help_dict->insert({ "StringToHexArray",   "\tString chararacters convert to hex array Convert.StringToHexArray(string)(\"hex array\")" });
    
    help_dict->insert({ "HexToBin", "\treturns bin value Convert.HexToBin(hex value)" });
    help_dict->insert({ "BinToHex", "\treturns hex value Convert.BinToHex(bin value)" });
    help_dict->insert({ "IntToHex", "\treturns hex value Convert.IntToHex(int value)" });
    help_dict->insert({ "HexToInt", "\treturns int value Convert.HexToInt(hex value)" });
    help_dict->insert({ "IntToBin", "\treturns bin value Convert.IntToBin(int value)" });
    help_dict->insert({ "BinToInt", "\treturns int value Convert.BinToInt(bin value)" });
    for (const auto pair : *keyword_dict)
    {
      string key = "Convert." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Convert", this });
  }
  //=========================================================
  bool Convert::FuncStringToInt32Array(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 2)
    {
      printDlgt({"Error: [Convert.FuncStringToInt32Array] wrong format: Convert.StringToInt32Array(string)( ppl_array)"});
      return false;
    }

    vector<char> arr(parameters[0].begin(), parameters[0].end());
    vector<int32_t> arrInt32(arr.size());

    for (size_t i = 0; i < arrInt32.size(); i++)
    {
      arrInt32[i] = static_cast<int32_t>(arr[i]);
    }

    string fullname = parameters[1];
    string name = "";
    string nodes = "";
    bool b = true;

    string func_name = "Convert.FuncStringToInt32Array";
    Composite* path = nullptr;
    b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
      return false;

    ppl->processing->FuncReAllocArray({ fullname, "", to_string(arr.size()), "" }, result, node);
    
    Composite* ccomp;
    for (Component*& c : *(path->_children))
    {
      if (c->name == name)
      {
        ccomp = (Composite*)c;
        for (int j = 0; j < ccomp->_children->size(); j++)
        {  
          (*(ccomp->_children))[j]->name = "#";
          (*(ccomp->_children))[j]->value = to_string(arrInt32[j]);
        }
      }
    }    
    return true; 
  }
  //=========================================================
  bool Convert::FuncStringToHexArray(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Convert.FuncStringToHexArray] wrong format: Convert.StringToHexArray(string)( ppl_array)" });
      return false;
    }

    vector<char> arr(parameters[0].begin(), parameters[0].end());
    vector<int32_t> arrInt32(arr.size());

    for (size_t i = 0; i < arrInt32.size(); i++)
    {
      arrInt32[i] = static_cast<int32_t>(arr[i]);
    }

    string fullname = parameters[1];
    string name = "";
    string nodes = "";
    bool b = true;

    string func_name = "Convert.FuncStringToHexArray";
    Composite* path = nullptr;
    b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
      return false;

    ppl->processing->FuncReAllocArray({ fullname, "", to_string(arr.size()), "" }, result, node);

    Composite* ccomp;
    for (Component*& c : *(path->_children))
    {
      if (c->name == name)
      {
        ccomp = (Composite*)c;
        for (int j = 0; j < ccomp->_children->size(); j++)
        {
          (*(ccomp->_children))[j]->name = "#";
          ostringstream oss;
          oss << uppercase << hex << arrInt32[j];
          (*(ccomp->_children))[j]->value = oss.str();
        }
      }
    }
    return true; 
  }
  //=========================================================
  bool Convert::FuncHexToBin(const vector<string>& parameters, string& result, Composite* node) 
  { 
    result = "";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Convert.FuncHexToBin] wrong format: Convert.HexToBin(hex value)" });
      return false;
    }
    string hexvalue = parameters[0];
    try
    {
      //result = System.Convert.ToString(System.Convert.ToInt32(hexvalue, 16), 2);
      int intValue = stoi(hexvalue, nullptr, 16);
      string binaryValue = bitset<32>(intValue).to_string(); // Change 32 to the desired bit length

      size_t pos = binaryValue.find('1');        // Remove leading zeros
      if (pos != string::npos)
        result = binaryValue.substr(pos);
      else
        result =  "0";
    }
    catch(...)
    {
      printDlgt({ "Error: [Convert.FuncHexToBin] wrong data [{0}]", hexvalue });
      return false;
    }
    return true; 
  }
  //=========================================================
  bool Convert::FuncBinToHex(const vector<string>& parameters, string& result, Composite* node) 
  {
    result = "";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Convert.FuncBinToHex] wrong format: Convert.BinToHex(hex value)" });
      return false;
    }
    string intValue = parameters[0];
    try
    {
      int hexValue = stoi(intValue, nullptr, 2);
      string binaryValue = bitset<32>(intValue).to_string(); 

      ostringstream oss;
      oss << uppercase << hex << hexValue; // Convert to hex and make uppercase
      result = oss.str();
    }
    catch (const invalid_argument& e)
    {
      printDlgt({ "Error: [Convert.FuncBinToHex] Invalid binary string: [{0}]", e.what()});
      return false; 
    }
    catch (const out_of_range& e)
    {
      printDlgt({ "Error: [Convert.FuncBinToHex] Binary value out of range: [{0}]", e.what() });
      return false; 
    }
    return true; 
  }
  //=========================================================
  bool Convert::FuncIntToHex(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Convert.FuncIntToHex] wrong format: Convert.IntToHex(int value)" });
      return false;
    }

    try
    {
      int i = stoi(parameters[0]); // Convert to integer
      ostringstream oss;
      oss << uppercase << hex << i; // Convert to hexadecimal
      result = oss.str();
    }
    catch (const invalid_argument& e)
    {
      printDlgt({ "Error: [Convert.FuncIntToHex] wrong data [{0}]", parameters[0] });
      return false;
    }
    catch (const out_of_range& e)
    {
      printDlgt({"Error: [Convert.FuncIntToHex] out of range [{0}]", parameters[0]});
      return false;
    }

    return true; 
  }
  //=========================================================
  bool Convert::FuncHexToInt(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Convert.FuncHexToInt] wrong format: Convert.HexToInt(hex value)" });
      return false;
    }
    string hexvalue = parameters[0];
    try
    {
      if (hexvalue.find("0x") == string::npos) // "142CBD"
      {
        // Convert hex string to integer
        int intValue;
        stringstream ss;
        ss << hex << parameters[0]; // Assuming parameters[0] is the hex string
        ss >> intValue;
        result = to_string(intValue);
      }
      else
      {
        // Convert hex string with "0x" prefix to integer
        int intValue = stoi(hexvalue, nullptr, 16); // "0x142CBD"
        result = to_string(intValue);
      }

    }
    catch(...)
    {
      printDlgt({"Error: [Convert.FuncHexToInt] wrong data [{0}]", hexvalue });
      return false;
    }
    return true; 
  }
  //=========================================================
  bool Convert::FuncIntToBin(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Convert.FuncIntToBin] wrong format: Convert.IntToBin(int value)"});
      return false;
    }
    result = "";
    try
    {
      // Convert string to integer
      int value = stoi(parameters[0]);

      // Convert integer to binary string
      result = bitset<32>(value).to_string(); // 32 bits for the binary representation

      // Remove leading zeros
      size_t pos = result.find('1');
      if (pos != string::npos)
        result = result.substr(pos); // Get substring from the first '1'
      else
        result = "0"; 
    }
    catch(...)
    {
      printDlgt({"Error: [Convert.FuncIntToBin] wrong data [{0}]", parameters[0] });
      return false;
    }
    return true; 
  }
  //=========================================================
  bool Convert::FuncBinToInt(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Convert.FuncBinToInt] wrong format: Convert.BinToInt(bin value)" });
      return false;
    }
    string bin_value = parameters[0];
    result = "";
    try
    {
      //result = System.Convert.ToInt32(bin_value, 2).ToString();
      result = stoi(bin_value, nullptr, 2);
    }
    catch(...)
    {
      printDlgt({"Error: [Convert.FuncBinToInt] wrong data [{0}]", bin_value });
      return false;
    }
    return true; 
  }
}
