#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  //  df,index row,column_from,[column_to],"array"
  bool DataFrame::FuncGetSliceColumnArray(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetSliceColumnArray";

    if ((parameters.size() != 4) && (parameters.size() != 5))
    {
      printDlgt({ "Error: [{0}] wrong format: DataFrame.GetSliceColumnArray(DataFrame_name)(row)(column_from)[(column_to)](array)", func_name });
      return false;
    }

    string df_name = parameters[0];
    try
    {
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] not digital RowsLength [{2}]", func_name,df_name,  str_RowsLength });
        return false;
      }

      int row = 0;
      b = TryParse(parameters[1], row);
      if (!b)
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] row not digital [{2}]", func_name,df_name, parameters[1] });
        return false;
      }

      if ((row < 0) || (row >= RowsLength))
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] row [{2}] out of bounds", func_name,df_name, parameters[1] });
        return false;
      }

      //==================================
      vector<string> column_names = *ptr_column_names;
      string str_column_from = trim(parameters[2], "\"");
      int index = VectorIndexOf(column_names, str_column_from);
      if (index == -1)
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] wrong column_from [{2}]", func_name,df_name, str_column_from });
        return false;
      }
      //==================================
      int length;
      if (parameters.size() == 4)
        length = column_names.size() - index;   // to the end of the row
      else
      {
        string str_column_to = trim(parameters[3], "\"");
        length = VectorIndexOf(column_names, str_column_to);
        if (length == -1)
        {
          printDlgt({ "Error: [{0}] DataFrame [{1}] wrong column_to [{2}]", func_name,df_name, str_column_to });
          return false;
        }
      }
      //==================================
      string array_result_name;
      if (parameters.size() == 4)
        array_result_name = parameters[3];
      else
        array_result_name = parameters[4];

      Composite* array_result = static_cast<Composite*>(ppl->processing->GetComponentFromDataNames(array_result_name));
      if (array_result == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] wrong array name [{2}]",func_name,df_name, array_result_name });
        return false;
      }
      //==================================
      for (size_t i = index; i < index + length; i++)
      {
        Composite* c = static_cast<Composite*>(ppl->processing->GetComponentFromDataNames(df_name + "." + column_names[i]));
        if (c == nullptr)
        {
          printDlgt({ "Error: [{0}] DataFrame [{1}] column [{2}] is absent",func_name,df_name, column_names[i] });
          return false;
        }
        array_result->Add(new Leaf("#", (*(c->_children))[row]->value));
      }
      array_result->value = "Array " + to_string(length);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
}