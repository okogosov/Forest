#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Console.h"

using namespace std;
namespace PPLNS
{
  static Console* CONSOLEInstance = nullptr;

  void Console_CreateInstance(PPL* ppl)
  {
    CONSOLEInstance = new Console(ppl);
    CONSOLEInstance->AddToKeywordDictionary();
  }

  Console::Console(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Console::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("ForegroundColor", FuncForegroundColor);
    AddKeyword("BackgroundColor", FuncBackgroundColor);
    AddKeyword("ForegroundPromptColor", FuncForegroundPromptColor);
    AddKeyword("DefaultColors", FuncDefaultColors);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Beep", FuncBeep);
    AddKeyword("Clear", FuncClear);
    AddKeyword("SetCursorPosition", FuncSetCursorPosition);
    AddKeyword("GetCursorPosition", FuncGetCursorPosition);
    AddKeyword("WindowWidth", FuncWindowWidth);
    AddKeyword("WindowHeight", FuncWindowHeight);

    help_dict->insert({ "help", "\tConsole.help([name])" });
    help_dict->insert({ "ForegroundColor", "\t..." });
    help_dict->insert({ "BackgroundColor", "\t..." });
    help_dict->insert({ "ForegroundPromptColor", "\t..." });
    help_dict->insert({ "DefaultColors", "\t..." });
    help_dict->insert({ "Write", "\t..." });
    help_dict->insert({ "Beep", "\t..." });
    help_dict->insert({ "Clear", "\t..." });
    help_dict->insert({ "SetCursorPosition", "\t..." });
    help_dict->insert({ "GetCursorPosition", "\t..." });
    help_dict->insert({ "WindowWidth", "\t..." });
    help_dict->insert({ "WindowHeight", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Console." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Console", this });
  }
  //=========================================================
  bool Console::FuncForegroundColor(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncBackgroundColor(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncForegroundPromptColor(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncDefaultColors(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncWrite(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncBeep(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncClear(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncSetCursorPosition(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncGetCursorPosition(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncWindowWidth(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Console::FuncWindowHeight(vector<string> parameters, string& result, Composite* node) { return true; }
}
