#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Math.h"
#include <numbers> 
using namespace std;

//std::ostringstream out;
//out << std::fixed << std::setprecision(12) << number;
//std::string formattedNumber = out.str();
//std::cout << formattedNumber << std::endl; // Output: 123.456789012345

namespace PPLNS
{
  static Math* MathInstance = nullptr;

  //void AddKeywordToMainDictionary(const std::string& Key, std::function<bool(std::vector<std::string>, std::string&, Composite*)> Function) {
  //  // Implementation of the function
  //  ppl->processing->keyword_dict->insert({ Key, Function });
  //}

  void Math_CreateInstance(PPL* ppl)
  {
    MathInstance = new Math (ppl);
    MathInstance->AddToKeywordDictionary();
  }
  
  Math::Math (PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }    

  //=======================================================
  // called  via FuncImport() /  Math()
  void Math::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp)
    AddKeyword("PI", FuncPI)
    AddKeyword("E",   FuncE)
    AddKeyword("Max", FuncMax)
    AddKeyword("Min", FuncMin)
    AddKeyword("BigMul", FuncBigMul)
    AddKeyword("Sqrt", FuncSqrt)
    AddKeyword("Round", FuncRound)
    AddKeyword("Abs", FuncAbs)
    AddKeyword("Acos", FuncAcos)
    AddKeyword("Asin", FuncAsin);

    AddKeyword("Atan", FuncAtan)
    AddKeyword("Atan2", FuncAtan2)
    AddKeyword("Ceiling", FuncCeiling)
    AddKeyword("Cos", FuncCos)
    AddKeyword("DivRem", FuncDivRem)
    AddKeyword("Exp", FuncExp)
    AddKeyword("Floor", FuncFloor)
    AddKeyword("Log", FuncLog)
    AddKeyword("Log10", FuncLog10)
    AddKeyword("Pow", FuncPow)
    AddKeyword("Sign", FuncSign)
    AddKeyword("Sin", FuncSin)
    AddKeyword("Tan", FuncTan)
    AddKeyword("Truncate", FuncTruncate)
    AddKeyword("Sinh", FuncSinh)
    AddKeyword("Tanh", FuncTanh)
    AddKeyword("Cosh", FuncCosh)

    //AddKeywordToMainDictionary("Math.Min", FuncMin);

    help_dict->insert({ "help","\tMath.help([name])" });
    help_dict->insert({ "Max","\tReturns the larger of two double-precision floating-point numbers: \r\n\tMath.Max(double d1)(double d2)" });
    
    help_dict->insert({"Min", "\tReturns the smaller of two double-precision floating-point numbers:  \r\n\tMath.Min(double d1)(double d2)"});
    help_dict->insert({"BigMul", "\tProduces the full product of two 32-bit numbers: \r\n\tMath.BugMul(Int32 n1)(Int32 n2)"});
    help_dict->insert({"Sqrt", "\tReturns the square root of a specified number: \r\n\tMath.Sqrt(double d1)"});
    help_dict->insert({"Round", "\tRounds a double-precision floating-point value to a specified number:  \r\n\tMath.Round (double value)[(Int32 digits)]"});
    help_dict->insert({"Abs", "\tReturns the absolute value of a double-precision floating-point number: \r\n\tMath.Abs(double value)"});


    help_dict->insert({"Acos", "\tReturns the angle whose cosine is the specified number: \r\n\tMath.Acos(double d)"});
    help_dict->insert({"Asin", "\tReturns the angle whose sine is the specified number: \r\n\tMath.Asin(double d)"});
    help_dict->insert({"Atan", "\tReturns the angle whose tangent is the specified number: \r\n\tMath.Atan(double d)"});
    help_dict->insert({"Atan2", "\tReturns the angle whose tangent is the quotient of two specified numbers: \r\n\tMath.Atan2(double d1)(double d2)"});
    help_dict->insert({"Ceiling", "\tReturns the smallest integral value greater than or equal to the specified number: \r\n\tMath.Ceiling(double d)"});
    help_dict->insert({"Cos", "\tReturns the cosine of the specified angle: \r\n\tMath.Cos(double d)"});
    help_dict->insert({"DivRem", "\tReturns the quotient and remainder as result: \r\n\tMath.DivRem(Int64 n1)(Int64 n2)"});

    help_dict->insert({"PI", "\tRepresents the ratio of the circumference of a circle to its diameter: \r\n\tMath.PI()"});
    help_dict->insert({"E", "\tRepresents the natural logarithmic base: \r\n\tMath.E()"});
    //help_dict->insert({"Tau",  "Represents the number of radians in one turn: \r\n\tMath.Tau()"});

    help_dict->insert({"Exp", "\tReturns e raised to the specified power: \r\n\tMath.Exp(double value)"});
    help_dict->insert({"Floor", "\tReturns the largest integral value less than or equal to the specified number: \r\n\tMath.Floor(double value)"});
    help_dict->insert({"Log", "\tReturns the logarithm of a specified number: \r\n\tMath.Log(double value)"});
    help_dict->insert({"Log10", "\tReturns the base 10 logarithm of a specified number: \r\n\tMath.Log10(double value)"});
    help_dict->insert({"Pow", "\tReturns a specified number raised to the specified power: \r\n\tMath.Pow(double value)(double power)"});
    help_dict->insert({"Sign", "\tReturns an integer that indicates the sign of a double-precision floating-point number: \r\n\tMath.Sign(double value)"});
    help_dict->insert({"Sin", "\tReturns the sine of the specified angle: \r\n\tMath.Sin(double value)"});
    help_dict->insert({"Tan", "\tReturns the tangent of the specified angle: \r\n\tMath.Tan(double value)"});
    help_dict->insert({"Truncate", "\tCalculates the integral part of a number: \r\n\tMath.Truncate(double value)"});
    help_dict->insert({"Tanh", "\tReturns the hyperbolic tangent of the specified angle: \r\n\tMath.Tanh(double value)"});
    help_dict->insert({"Cosh", "\tReturns the hyperbolic cosine of the specified angle: \r\n\tMath.Cosh(double value)"});
    help_dict->insert({"Sinh", "\tReturns the hyperbolic sine of the specified angle: \r\n\tMath.Sinh(double value)"});

     
    for (const auto pair : *keyword_dict)
    {
      string key = "Math." + pair.first;
      //function<bool(vector<string>, string&, Composite*)> value = pair.second;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }

    ppl->ImportList.insert({ "Math",this });
    // test
    //vector<string> v = { "1","2" };
    //string res;
    //bool r = MathInstance->FuncMax(v,res,nullptr);
  }

  //============================================================================
  //bool Math::FuncHelp(const vector<string>& parameters, string& result, Composite* node)
  //{
  //  BaseClass::FuncHelp(parameters,result,node);
  //  return true;
  //}
  bool Math::FuncPI(const vector<string>& parameters, string& result, Composite* node)
  {
    result = "3.14159265358979323846"; // to_string(numbers::pi);
    return true;
  }
  //===========================================================================
  bool Math::FuncE(const vector<string>& parameters, string& result, Composite* node)
  {
    result = PPLNS::FormatDouble(exp(1.0));
    return true;
  }
  //============================================================================
  bool Math::FuncMax(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({"Error: [Math.FuncMax] wrong number of parameters != 2 ", });
      return false;
    }
    double d1;
    if (!TryParse(parameters[0], d1))
    {
      printDlgt({ "Error: [Math.FuncMax] not digital [{0}]",  parameters[0] });
      return false;
    }
    double d2;
    if (!TryParse(parameters[1], d2))
    {
      printDlgt({ "Error: [Math.FuncMax] not digital [{0}]",  parameters[1] });
      return false;
    }
    result = PPLNS::FormatDouble(max(d1, d2));
    return true;
  }
  //===========================================================================
  bool Math::FuncMin(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Math.FuncMin] wrong number of parameters != 2 ", });
      return false;
    }
    double d1 = 0;
    if (!TryParse(parameters[0], d1))
    {
      printDlgt({ "Error: [Math.FuncMin] not digital [{0}]",  parameters[0] });
      return false;
    }
    double d2 = 0;
    if (!TryParse(parameters[1], d2))
    {
      printDlgt({ "Error: [Math.FuncMin] not digital [{0}]",  parameters[1] });
      return false;
    }
    result = PPLNS::FormatDouble(min(d1, d2));
    return true;
  }
  //===========================================================================
  bool Math::FuncBigMul(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Math.FuncBigMul] wrong number of parameters != 2 " });
      return false;
    }
    int x;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncBigMul] not digital [{0}]",  parameters[0] });
      return false;
    }
    int y;
    if (!TryParse(parameters[1], y))
    {
      printDlgt({ "Error: [Math.FuncBigMul] not digital [{0}]",  parameters[1] });
      return false;
    }
    result = to_string (static_cast<int64_t>(x) * static_cast<int64_t>(y));
    return true;
  }
  //===========================================================================
  bool Math::FuncSqrt(const vector<string>& parameters, string& result, Composite* node)
  {
    string tmp = "";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncSqrt] wrong number of parameters != 1}" });
      return false;
    }
    double d = 0;
    if (!TryParse(parameters[0], d))
    {
      printDlgt({ "Error: [Math.FuncSqrt] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(sqrt(d));
    return true;
  }
  //===========================================================================
  bool Math::FuncRound(const vector<string>& parameters, string& result, Composite* node)
  {
    double d = 0;
    bool b = true;
    int precision = 0;
    switch (parameters.size())
    {
      case 1:
        b = TryParse(parameters[0], d);
        if (!b)
        {
          printDlgt({ "Error: [Math.FuncRound] not digital  {0} ", parameters[0]});
          return false;
        }
      break;
      case 2:
        b = TryParse(parameters[0], d);
        if (!b)
        {
          printDlgt({ "Error: [Math.FuncRound] not digital  {0} ", parameters[0] });
          return false;
        }
        b = TryParse(parameters[1], precision);
        if (!b)
        {
          printDlgt({ "Error: [Math.FuncRound] not digital  {0} ", parameters[1] });
          return false;
        }
      break;
      default:
        printDlgt({"Error: [Math.FuncRound] wrong number of parameters  {0}", to_string(parameters.size())});
      return false;
    }
    //double dres = round(d, precision);
    float power_of_10 = pow(10, precision);
    result = PPLNS::FormatDouble(round(d * power_of_10) / power_of_10);
    int i = result.size() - 1;
    while (true)
    {
      if (result[i] == '.')
      {
        result = result.substr( 0, i);
        break;
      }
      if (result[i] == '0')
      {
        result = result.substr(0, i);
        i = result.size() - 1;
        continue;
      }
      else
        break;
    }
    return true;
  }
  //===========================================================================
  bool Math::FuncAbs(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncAbs] wrong number of parameters != 1}" });
      return false;
    }
    double d = 0;
    if (!TryParse(parameters[0], d))
    {
      printDlgt({ "Error: [Math.FuncAbs] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(abs(d));
    return true;
  }
  //===========================================================================
  bool Math::FuncAcos(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncAcos] wrong number of parameters != 1}" });
      return false;
    }
    double d = 0;
    if (!TryParse(parameters[0], d))
    {
      printDlgt({ "Error: [Math.FuncAcos] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(acos(d));
    return true;
  }
  //===========================================================================
  bool Math::FuncAsin(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncAsin] wrong number of parameters != 1}" });
      return false;
    }
    double d = 0;
    if (!TryParse(parameters[0], d))
    {
      printDlgt({ "Error: [Math.FuncAsin] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(asin(d));
    return true;
  }
  //===========================================================================
  bool Math::FuncAtan(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncAtan] wrong number of parameters != 1}" });
      return false;
    }
    double d = 0;
    if (!TryParse(parameters[0], d))
    {
      printDlgt({ "Error: [Math.FuncAtan] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(atan(d));
    return true;
  }
  //===========================================================================
  bool Math::FuncAtan2(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Math.FuncAtan2] wrong number of parameters != 2}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncAtan2] not digital [{0}]",  parameters[0] });
      return false;
    }
    double y = 0;
    if (!TryParse(parameters[1], y))
    {
      printDlgt({ "Error: [Math.FuncAtan2] not digital [{0}]",  parameters[1] });
      return false;
    }
    result = PPLNS::FormatDouble(atan2(x,y));
    return true;
  }
  //===========================================================================
  bool Math::FuncCeiling(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncCeiing] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncCeiing] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(ceil(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncCos(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncCos] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncCos] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(cos(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncDivRem(const vector<string>& parameters, string& result, Composite* node)
  {
    /*div_t result = std::div(x, y);
    int quotient = result.quot;
    int remainder = result.rem;*/

    //Calculates the quotient of two 32-bit signed integers 
    //and also returns the remainder in an output parameter.
    //int DivRem (int a, int b, out int result);
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Math.FuncDivRem] wrong number of parameters != 2 " });
      return false;
    }
    long x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncDivRem] not digital [{0}]",  parameters[0] });
      return false;
    }
    long y = 0;
    if (!TryParse(parameters[1], y))
    {
      printDlgt({ "Error: [Math.FuncDivRem] not digital [{0}]",  parameters[1] });
      return false;
    }
    ldiv_t lresult = ldiv(x, y);
    long quotient = lresult.quot;
    long remainder = lresult.rem;
    result = PPLNS::FormatDouble(quotient) + ";" + PPLNS::FormatDouble(remainder);
    return true;
  }
  //===========================================================================
  bool Math::FuncExp(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncExp] wrong number of parameters != 1}" });
      return false;
    }
    double d;
    bool b = TryParse(parameters[0],d);
    if (!b)
    {
      printDlgt({ "Error: [Math.FuncExp] not digital value {0}", parameters[0]});
      return false;
    }
    d = exp(d);
    result = PPLNS::FormatDouble(d);
    return true;
  }
  //===========================================================================
  bool Math::FuncFloor(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncFloor] wrong number of parameters != 1" });
      return false;
    }
    double x;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncFloor] not digital value {0}",  parameters[0] });
      return false;
    }
    double d = floor(x);
    result = PPLNS::FormatDouble(d);
    return true;
  }
  //===========================================================================
  bool Math::FuncLog(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncLog] wrong number of parameters != 1" });
      return false;
    }
    double x;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncLog] not digital value {0}",  parameters[0] });
      return false;
    }
    double d = std::log(x);
    result = PPLNS::FormatDouble(d);
    return true;
  }
  //===========================================================================
  bool Math::FuncLog10(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncLog10] wrong number of parameters != 1" });
      return false;
    }
    double x;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncLog10] not digital value {0}",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(log10(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncPow(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Math.FuncPow] wrong number of parameters != 2" });
      return false;
    }
    double x;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncPow] not digital value {0}",  parameters[0] });
      return false;
    }
    double y;
    if (!TryParse(parameters[1], y))
    {
      printDlgt({ "Error: [Math.FuncPow] not digital value {0}",  parameters[1] });
      return false;
    }
    result = PPLNS::FormatDouble(pow(x, y));
    return true;
  }
  //===========================================================================
  bool Math::FuncSign(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncSign] wrong number of parameters != 2}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncSign] not digital [{0}]",  parameters[0] });
      return false;
    }
    if (x > 0)
    {
      result = "1"; 
      return true;
    }
    if (x < 0)
    {
      result = "-1"; 
      return true;
    }
    if (x == 0)
      result = "0";
    return true;
  }
  //===========================================================================
  bool Math::FuncSin(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncSin] wrong number of parameters != 2}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncSin] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(sin(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncTan(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncTan] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncTan] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(tan(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncTruncate(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncTruncate] wrong number of parameters != 1" });
      return false;
    }
    double x;
    if (TryParse(parameters[0], x))
    {
      result = PPLNS::FormatDouble(trunc(x));
      return true;
    }
    else
    {
      printDlgt({"Error: [Math.FuncTruncate] not digital value {0}", parameters[0]});
      return false;
    }
  }
  //===========================================================================
  bool Math::FuncSinh(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncSinh] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncSinh] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(sinh(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncTanh(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncTanh] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncTanh] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(tanh(x));
    return true;
  }
  //===========================================================================
  bool Math::FuncCosh(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Math.FuncCosh] wrong number of parameters != 1}" });
      return false;
    }
    double x = 0;
    if (!TryParse(parameters[0], x))
    {
      printDlgt({ "Error: [Math.FuncCosh] not digital [{0}]",  parameters[0] });
      return false;
    }
    result = PPLNS::FormatDouble(cosh(x));
    return true;
  }
}
