#include "Component.h"
namespace PPLNS
{
  // The PPL class will encapsulate the parsing logic.
  class  PPL
  {
  public:
    static Composite* Parser(const std::string& input0, bool checkQuotesAndParentheses);
    static std::string trim(const std::string& str, const std::string& chars = " \n\r\t\f\v");
    static  bool TrimPPL(string& text);
    static void ClearStackNodes(stack <Composite*> nodes);
    static std::string GetString(const std::string& str, const std::string& begin, const std::string& end);
    static char GetNextNotWhiteSpaceSymbol(const std::string& input, long index);
    static std::string GetCommand(std::string input);
    static void AddParentheses(std::string& input);
    static vector<std::string> SmartSplitString(std::string input, std::string delimiters, bool RemoveEmptyToken = true);
    static bool CheckNumberOfParentheses(const std::string& text);
    static bool CheckNumberOfQuotes(const std::string& input);
    static void handleOpenParenthesis(char c, stack<char>& parentheses, stack<Composite*>& nodes, std::string& value, std::string& name);
    static void RemoveComments(std::string& input);
  };
} // namespace PPLNS


