#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  /// <summary>
  /// 
  /// </summary>
  /// <param name="df_name"></param>
  /// <param name="[number from]"></param>
  /// <param name="[number to]"></param>
  /// <returns></returns>
  /// RemoveRows(df_name) - remove all rows
  /// RemoveRows(df_name)(number row) - remove 1 row
  /// RemoveRows(df_name)(number from)(*) - remove from number till end
  /// RemoveRows(df_name)(number from)(number to) - remove rows from number_from to number_to
  bool DataFrame::FuncRemoveRows(const vector<string>& parametersInput, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncRemoveRows";
    vector<string> parameters = parametersInput;

    try 
    {
      if (parameters.size() < 1 ) 
      {
        printDlgt({ "Error: [{0}] wrong format: DataFrame.RemoveRows(df_name)[(number from)[(number to)]]",func_name });
        return false;
      }
      if ( parameters.size() > 3)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}] wrong parameter, format: DataFrame.RemoveRows(df_name)[(number from)[(number to)]]",
          func_name, parameters[0] });
        return false;
      }
      string df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = comp_df->_children->size();
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      if (!TryParse(strLength, Length))
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] not digital RowsLength [{2}]",func_name, df_name, strLength });
        return false;
      }
      int NumberFrom = 0;
      int NumberTo = 0;

      if (parameters.size() == 1) 
      { // remove all
        parameters.push_back("0");
        parameters.push_back(to_string(Length - 1));
      }
      if (parameters.size() == 2) 
      { // remove 1 row
        parameters.push_back(parameters[1]);
      }
      if (parameters.size() == 3 && parameters[2] == "*") 
      { // remove to last row
        parameters[2] = to_string(Length - 1);
      }
      string strNumberFrom = parameters[1];
      string strNumberTo = parameters[2];

      if (!TryParse(strNumberFrom, NumberFrom))
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] not digital NumberFrom [{2}]",func_name, df_name, strNumberFrom });
        return false;
      }

      if (!TryParse(strNumberTo, NumberTo))
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] not digital NumberTo [{2}]",func_name, df_name, strNumberTo });
        return false;
      }

      //for (size_t i = 1; i < comp_df->_children->size(); i++) 
      for (auto& c : *comp_df->_children)
      {
        //Component* c = (*(comp_df->_children))[i];
        if (dynamic_cast<Leaf*>(c)) 
        {
          printDlgt({"Warning: [{0}] DataFrame [{1}] var [{2}] not usable",func_name,df_name, c->name });
          continue;
        }
        Composite* comp = dynamic_cast<Composite*>(c);
        int delta = NumberTo - NumberFrom;
        for (int j = NumberFrom; j < comp->_children->size(); j++) 
        {
          comp->Remove(c);
          j--;
          if (delta == 0)
            break;
          delta--;
        }
        strLength = to_string(comp->_children->size());
        comp->value = "Array " + strLength;
      }

      Component* c = GetComponentSettingsByName(comp_settings, "RowsLength");
      c->value = strLength;
    }
    catch (const exception& ex) 
    {
      printDlgt({"Error: [{0}] [{1}]",func_name,ex.what()});
      return false;
    }
    return true;
  }
  //=========================================================================================
  bool DataFrame::FuncRemoveColumns(const vector<string>& parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncRemoveColumns";
    try
    {
      if (parameters.size() < 1)
      {
        printDlgt({ "Error: [{0}] wrong format: DataFrame.RemoveColumns(df_name)[(column1)(column2)...]",func_name });
        return false;
      }
      string df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = comp_df->_children->size(); 
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      if (!TryParse(strLength, Length))
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] not digital RowsLength [{2}]",func_name, df_name, strLength });
        return false;
      }
      //====================================================
      vector<string> columns_selected;

      if (parameters.size() > 1)
      {
        columns_selected.reserve(parameters.size() - 1);
        for (size_t i = 1; i < parameters.size(); i++)
          columns_selected.push_back(parameters[i]);
      }

      //=============Test column names================
      if (!columns_selected.empty())
      {
        for (const string& cw : columns_selected)
        {
          bool b2 = false;

          for (int i = 0; i < columns_quantity; i++)
          {
            if ((*(comp_df->_children))[i]->name == cw)
            {
              b2 = true;
              break;
            }
          }

          if (!b2)
          {
            printDlgt({"Error: [{0}] DataFrame [{1}] wrong column name [{2}]",func_name,df_name,cw});
            return false;
          }
        }
      }
      //=========================================================
      for (size_t i = 0; i < comp_df->_children->size(); i++)
      {
        Component* c = (*(comp_df->_children))[i];
        if (c->name == "Settings")
          continue;

        if (dynamic_cast<Leaf*>(c))
        {
          printDlgt({ "Warning: [{0}] DataFrame [{1}] var [{2}] not usable",func_name,df_name, c->name });
          continue;
        }

        if (!columns_selected.empty())
        {
          if (find(columns_selected.begin(), columns_selected.end(), c->name) == columns_selected.end())
            continue;
        }

        Component* comp = GetComponentSettingsByName(comp_settings, c->name + "Type");
        comp_settings->Remove(comp);

        comp = GetComponentSettingsByName(comp_settings, c->name + "Width");
        comp_settings->Remove(comp);

        c->parent->Remove(c);
        i--;
      }

      ptr_column_names->clear();
      for (auto*& c : *(comp_df->_children))
      {
        if (c->name == "Settings")
          continue;
        ptr_column_names->push_back(c->name);
      }
    }
    catch (const exception& ex)
    {
      printDlgt({"Error: [{0}] [{1}]",func_name,ex.what()});
      return false;
    }
    return true;
  }
}