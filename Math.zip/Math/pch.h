#ifndef PCH_H
#define PCH_H

// add headers that you want to pre-compile here
#include <iostream>
#include <cassert>
#include <format>
#include <string>
#include <sstream>
#include <cstdarg>
#include <iterator>
#include <list>
#include <typeinfo>
#include <stack>
#include <unordered_map>
#include <map>
#include <vector>
#include <queue>
#include <typeinfo>
#include <fstream>
#include <regex>
#include <direct.h>
#include <exception>
//#include <limits>

#include <thread>
#include <atomic>
#include <mutex>
//#include "jthread.hpp"

#include <chrono>
#include <algorithm>
#include <regex>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <cstdlib>
#include <numeric>
#include "framework.h"
#include <Windows.h>
#include <cmath>
#include <functional>
//#include <execution>
#endif //PCH_H
