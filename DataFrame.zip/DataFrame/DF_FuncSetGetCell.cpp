#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  // df,column,row,data | df.cell_name,data
  bool DataFrame::FuncSetCell(const vector<string>& parametersInput, string & result, Composite * node)
  {
    string func_name = "DataFrame.FuncSetCell";
    string err;

    if ((parametersInput.size() != 4) && (parametersInput.size() != 2))
    {
      err = "[" + func_name + "] wrong format: DataFrame.SetCell(DataFrame_name)(column)(row)(data) | (df.cell_name)(data)";
      printDlgt({"Error: {0}",err});
      return false;
    }
    string df_name;
    vector<string> parameters = parametersInput;
    try
    {
      if (parameters.size() == 4)
        df_name = parameters[0];
      else
      {
        vector<string> tokens = SplitString(parameters[0], '.');
        if (tokens.size() != 2)
        {
          err = "[" + func_name + "] omitted '.' wrong format: DataFrame.SetCell(df.cell_name)(data)";
          printDlgt({ "Error: {0}",err });
          return false;
        }
        parameters.erase(parameters.begin());
        parameters.insert(parameters.begin(), tokens[0]);
        parameters.insert(parameters.begin() + 1, tokens[1]);
        df_name = parameters[0];
      }

      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] not digital RowsLength [" + str_RowsLength + "]";
        printDlgt({ "Error: {0}",err });
        return false;
      }
      vector<string> column_names = *ptr_column_names;
      int column_index = 0;
      string column = trim(parameters[1], "\"");
      if (parameters.size() == 4)
      {
        column_index = VectorIndexOf(column_names, column);
        if (column_index == -1)
        {
          err = "[" + func_name + "] DataFrame [" + df_name + "] wrong index [" + column + "]";
          printDlgt({ "Error: {0}",err });
          return false;
        }
      }

      string defined_column = "";
      int defined_row = 0;
      b = false;

      if (parameters.size() == 3)
      {
        for (const TableName& tn : table_names)
        {
          if (tn.name != df_name)
            continue;

          for (const auto& pair : tn.cell_addresses)
          {
            if (pair.first == parameters[1])
            {
              defined_column = pair.second.column;
              defined_row = pair.second.row;
              column = parameters[1] = defined_column;
              string tmp = parameters[2];
              parameters[2] = to_string(defined_row);
              parameters.push_back(tmp);
              b = true;
            }
          }
          if (!b)
          {
            err = "[" + func_name + "] DataFrame [" + df_name + "] wrong defined name [" + parameters[1] + "]";
            printDlgt({ "Error: {0}",err });
            return false;
          }
        }
      }

      int row = 0;
      b = TryParse(parameters[2], row);
      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row not digital [" + parameters[2] + "]";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      if ((row < 0) || (row >= RowsLength))
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row [" + parameters[2] + "] out of bounds";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      Component* comp_type = comp_settings->GetComponentByName(column + "Type");
      Composite* comp_column = static_cast<Composite*>( (*(comp_df->_children))[column_index + 1]);

      if (comp_type->value == "Number")
      {
        double d = 0;
        b = TryParse(parameters[3], d);
        if (!b)
        {
          err = "[" + func_name + "] DataFrame [" + df_name + "] data not digital [" + parameters[3] + "]";
          printDlgt({ "Error: {0}",err });
          return false;
        }
      }

      (*(comp_column->_children))[row]->value = parameters[3];
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
  //====================================================================
  bool DataFrame::FuncGetCell(const vector<string>& parametersInput, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetCell";
    string err;

    if ((parametersInput.size() != 3) && (parametersInput.size() != 1))
    {
      err = "[" + func_name + "] wrong format: DataFrame.GetCell(DataFrame_name)(column)(row) | (df.cell_name)";
      printDlgt({"Error: {0}",err});
      return false;
    }
    string df_name;
    vector<string> parameters = parametersInput;
    try
    {
      if (parameters.size() == 3)
        df_name = parameters[0];
      else
      {
        vector<string> tokens = SplitString(parameters[0], '.');
        if (tokens.size() != 2)
        {
          err = "[" + func_name + "] omitted '.' wrong format: DataFrame.GetCell(df.cell_name)";
          printDlgt({ "Error: {0}",err });
          return false;
        }
        parameters.erase(parameters.begin());
        parameters.insert(parameters.begin(), tokens[0]);
        parameters.insert(parameters.begin() + 1, tokens[1]);
        df_name = parameters[0];
      }

      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] not digital RowsLength [" + str_RowsLength + "]";
        return false;
      }
      vector<string> column_names = *ptr_column_names;
      int column_index = 0;
      string column = parameters[1];
      column.erase(remove(column.begin(), column.end(), '\"'), column.end());

      if (parameters.size() == 3)
      {
        column_index = VectorIndexOf(column_names, column);
        if (column_index == -1)
        {
          err = "[" + func_name + "] DataFrame [" + df_name + "] wrong index [" + column + "]";
          printDlgt({ "Error: {0}",err });
          return false;
        }
      }
      string defined_column = "";
      int defined_row = 0;
      b = false;

      if (parameters.size() == 2)
      {
        for (const TableName& tn : table_names)
        {
          if (tn.name != df_name)
          {
            continue;
          }
          for (const auto& pair : tn.cell_addresses)
          {
            if (pair.first == parameters[1])
            {
              defined_column = pair.second.column;
              defined_row = pair.second.row;
              column = parameters[1] = defined_column;
              parameters.push_back(to_string(defined_row));
              b = true;
            }
          }

          if (!b)
          {
            err = "[" + func_name + "] DataFrame [" + df_name + "] wrong defined name [" + parameters[1] + "]";
            printDlgt({ "Error: {0}",err });
            return false;
          }
        }
      }

      int row = 0;
      b = TryParse(parameters[2], row);

      if (!b)
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row not digital [" + parameters[2] + "]";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      if ((row < 0) || (row >= RowsLength))
      {
        err = "[" + func_name + "] DataFrame [" + df_name + "] row [" + parameters[2] + "] out of bounds";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      Composite* comp_column = static_cast<Composite*>( (*(comp_df->_children))[column_index + 1]);
      result = (*(comp_column->_children))[row]->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
}