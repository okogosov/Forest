#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Matrix.h"

using namespace std;
namespace PPLNS
{
  static Matrix* MATRIXInstance = nullptr;

  void Matrix_CreateInstance(PPL* ppl)
  {
    MATRIXInstance = new Matrix(ppl);
    MATRIXInstance->AddToKeywordDictionary();
  }

  Matrix::Matrix(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Matrix::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Get", FuncGet);
    AddKeyword("Set", FuncSet);
    AddKeyword("AddArrayToRow", FuncAddArrayToRow);
    AddKeyword("AddArrayToColumn", FuncAddArrayToColumn);
    AddKeyword("Write", FuncWrite);
    AddKeyword("WriteNames", FuncWriteNames);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("DeleteAll", FuncDeleteAll);
    AddKeyword("Rotate", FuncRotate);
    AddKeyword("Sort",   FuncSort);

    help_dict->insert({ "help", "\tMatrix.help([name])" });
    help_dict->insert({ "Create", "\tMatrix.Create(name)(rows)(columns)(type)\r\n\ttype=double|float|decimal|bool|int|uint|long|ulong|string"});
    help_dict->insert({ "Get", "\tMatrix.Get(name)(row)(column)" });
    help_dict->insert({ "Set", "\tMatrix.Set(name)(row)(column)(value)" });
    help_dict->insert({ "AddArrayToRow", "\tMatrix.AddRow(matrix_name)(row)(ppl_array)" });
    help_dict->insert({ "AddArrayToColumn", "\tMatrix.AddColumn(matrix_name)(column)(ppl_array)" });
    help_dict->insert({ "Write", "\tMatrix.Write(matrix_name)" });
    help_dict->insert({ "WriteNames", "\tMatrix.WriteNames()" });
    help_dict->insert({ "Delete", "\tMatrix.Delete(matrix_name)" });
    help_dict->insert({ "DeleteAll", "\tMatrix.DeleteAll" });
    help_dict->insert({ "Rotate", "\tMatrix.Rotate(\"matrix_name\")(\"cw\" | \"ccw\")" });
    help_dict->insert({ "Sort", "\tMatrix.Sort(\"matrix_name\")(column number| order)" });

   for (const auto pair : *keyword_dict)
    {
      string key = "Matrix." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Matrix", this });
  }
  //=========================================================
  //=========================================================
  void Matrix::checkMemoryLeak()
  {
    if (allocated_matrixes > 0 || allocated_rows > 0)
    {
      cout << "Memory leak detected: "
        << allocated_matrixes << " matrix(es) and "
        << allocated_rows << " row(s) still allocated!" << endl;
    }
    else
    {
      cout << "No memory leaks detected!" << endl;
    }
  }
  //=========================================================
  //FuncCreate name,rows,columns,type
  bool Matrix::FuncCreate(vector<string> parameters, string& result, Composite* node) 
  { 
    const string function_name = "Matrix.FuncCreate";
    string err;
    if (parameters.size() != 4) 
    {
      printDlgt({"Error: [{0}] wrong format", function_name});
      return false;
    }

    try 
    {
      string name = parameters[0];
      if (matrix_properties.find(name) != matrix_properties.end()) 
      {
        if (ppl->Recreate == "yes")
        {
          err = "[" + function_name + "] vector[" + name + "] recreates";
          printDlgt({ "Warning: {0}",err });
          vector<string> param;
          param.push_back(name);
          this->FuncDelete(param, result, node);
        }
        else
        {
          printDlgt({ "Error: [{0}] vector[{1}] exists", function_name,name });
          return false;
        }
      }

      int rows = stoi(parameters[1]);
      int columns = stoi(parameters[2]);
      string type = parameters[3];

      if (find(array_types.begin(), array_types.end(), type) == array_types.end()) 
      {
        printDlgt({ "Error: [{0}] [{1}] wrong type [{2}]", function_name,name,type });
        return false;
      }

      MatrixProperty vp;
      vp.type = type;
      vp.rows = rows;
      vp.columns = columns;
      vp.index = 0;

      if (type == "double") 
      {
        double** d = allocateMatrix<double>(rows, columns);
        double_matrixes.push_back(d);
        vp.index = double_matrixes.size() - 1;
      }
      else if (type == "float") 
      {
        float_matrixes.push_back(allocateMatrix<float>(rows, columns));
        vp.index = float_matrixes.size() - 1;
      }
      else if (type == "decimal") 
      {
        decimal_matrixes.push_back(allocateMatrix<double>(rows, columns)); // Using long double for decimal
        vp.index = decimal_matrixes.size() - 1;
      }
      else if (type == "bool") 
      {
        bool_matrixes.push_back(allocateMatrix<bool>(rows, columns) );
        vp.index = bool_matrixes.size() - 1;
      }
      else if (type == "int") 
      {
        int_matrixes.push_back(allocateMatrix<int>(rows, columns));
        vp.index = int_matrixes.size() - 1;
      }
      else if (type == "uint") 
      {
        uint_matrixes.push_back(allocateMatrix<unsigned int>(rows, columns));
        vp.index = uint_matrixes.size() - 1;
      }
      else if (type == "long") 
      {
        long_matrixes.push_back(allocateMatrix<long>(rows, columns));
        vp.index = long_matrixes.size() - 1;
      }
      else if (type == "ulong") 
      {
        ulong_matrixes.push_back(allocateMatrix<uint64_t>(rows, columns));
        vp.index = ulong_matrixes.size() - 1;
      }
      else if (type == "string") 
      {
        string_matrixes.push_back(allocateMatrix<string>(rows, columns));
        vp.index = string_matrixes.size() - 1;
      }

      matrix_properties[name] = vp;

      if (ppl->debugppl == "yes") 
      {
        printDlgt({"Info: [{0}] matrix [{1}] is created", function_name,name});
      }
    }
    catch (const invalid_argument&) 
    {
      printDlgt({ "Error: [{0}] invalid argument", function_name });
      return false;
    }
    catch (const out_of_range&) 
      {
      printDlgt({"Error: [{0}] out of range", function_name});
      return false;
    }
    catch (...) 
      {
      printDlgt({"Error: [{0}]",function_name });
      return false;
    }

    return true; 
  }
  
  //=====================================================================
  bool Matrix::GetMatrixProperty(string name, string& type, int& rows, int& columns, int& index) 
  {
    auto it = matrix_properties.find(name);
    if (it == matrix_properties.end()) 
    {
      return false; // Matrix not found
    }

    MatrixProperty vp = it->second;
    type = vp.type;
    rows = vp.rows;
    columns = vp.columns;
    index = vp.index;
    return true; 
  }
  //=====================================================================
  bool Matrix::FuncGet(vector<string> parameters, string& result, Composite* node) 
  { 
    string function_name = "Matrix.FuncGet";
    string strTemp;
    if (parameters.size() != 3)
    {
      strTemp = "[" + function_name + "] wrong format";
      printDlgt({ "Error: {0}",strTemp });
      return false;
    }
    string matrix_name = parameters[0];
    int ind_row = 0;
    int ind_column = 0;
    try
    {
      string type = "";
      int rows = 0;
      int columns = 0;
      int index = 0;
      bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b)
      {
        strTemp = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
        printDlgt({ "Errror: {0}",strTemp });
        return false;
      }
      b = TryParse(parameters[1], ind_row);
      if (b == false)
      {
        printDlgt({ "Error: [{0}] [{1}] not digital value [{2}]", function_name, matrix_name, parameters[1] });
        return false;
      }
      b = TryParse(parameters[2], ind_column);
      if (b == false)
      {
        printDlgt({ "Error: [{0}] [{1}] not digital value [{2}]", function_name, matrix_name, parameters[2] });
        return false;
      }
      if (ind_row < 0 || ind_row >= rows)
      {
        strTemp = "[" + function_name + "] [" + matrix_name + "] row_number [" + to_string(ind_row) + "] is out of bounds";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }
      if (ind_column < 0 || ind_column >= columns)
      {
        strTemp = "[" + function_name + "] [" + matrix_name + "] column_number [" + to_string(ind_column) + "] is out of bounds";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }

      if (type == "double")
      {
        result = to_string( double_matrixes[index][ind_row][ind_column] );
      }
      
      else if (type == "float")
      {
        result = to_string( float_matrixes[index][ind_row][ind_column] );
      }
      else if (type == "decimal")
      {
        result = to_string( decimal_matrixes[index][ind_row][ind_column] );
      }
      else if (type == "bool")
      {
        if(bool_matrixes[index][ind_row][ind_column] == true)
          result =  "True";
        else
          result = "False";
      }
      else if (type == "int")
      {
        result = to_string( int_matrixes[index][ind_row][ind_column] );
      }
      else if (type == "uint")
      {
        result = to_string( uint_matrixes[index][ind_row][ind_column] );
      }
      else if (type == "long")
      {
        result = to_string( long_matrixes[index][ind_row][ind_column] );
      }
      else if (type == "ulong")
      {
        result = to_string( ulong_matrixes[index][ind_row][ind_column] );
      }
      
      else if (type == "string")
      {
        result = string_matrixes[index][ind_row][ind_column];
      }

    }
    catch (const std::exception& ex)
    {
      printDlgt({ "Error: [{0}]  matrix_name [{1}] [{2}]", function_name, matrix_name, ex.what()});
      return false;
    }
    return true; 
  }
  //======================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <param name="name"></param>
  /// <param name="index row"></param>
  /// <param name="index column"></param>
  /// <param name="value"></param>
  bool Matrix::FuncSet(vector<string> parameters, string& result, Composite* node) 
  { 
    string function_name = "Matrix.FuncSet";
    string strTemp;
    if (parameters.size() != 4) 
    {
        strTemp = "[" + function_name + "] wrong format";
        printDlgt({ "Error: {0}",strTemp });
        return false;
    }
    string matrix_name = parameters[0];
    int ind_row = 0;
    int ind_column = 0;
    try
    {
      string type = "";
      int rows = 0;
      int columns = 0;
      int index = 0;
      bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b) 
      {
        strTemp = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }
      ind_row = stoi(parameters[1]);
      if (ind_row < 0 || ind_row >= rows) 
      {
          strTemp = "[" + function_name + "] [" + matrix_name + "] row_number [" + to_string(ind_row) + "] is out of bounds";
          printDlgt({ "Error: {0}",strTemp });
          return false;
      }
      ind_column = stoi(parameters[2]);
      if (ind_column < 0 || ind_column >= columns) 
      {
          strTemp = "[" + function_name + "] [" + matrix_name + "] column_number [" + to_string(ind_column) + "] is out of bounds";
          printDlgt({ "Error: {0}",strTemp });
          return false;
      }
       
      if (type == "double") 
      {
          double_matrixes[index][ind_row][ind_column] = stod(parameters[3]);
      } 
      else if (type == "float") 
      {
          float_matrixes[index][ind_row][ind_column] = stof(parameters[3]);
      } 
      else if (type == "decimal")
      {
        decimal_matrixes[index][ind_row][ind_column] = stod(parameters[3]); // long double for decimal
      }
      else if (type == "bool")
      {
        string tmp = ToLower(parameters[3]);
        bool_matrixes[index][ind_row][ind_column] = (tmp == "true");
      }
      else if (type == "int")
      {
        int_matrixes[index][ind_row][ind_column] = stoi(parameters[3]);
      }
      else if (type == "uint")
      {
        uint_matrixes[index][ind_row][ind_column] = (unsigned int)(stoul(parameters[3]));
      }
      else if (type == "long")
      {
        long_matrixes[index][ind_row][ind_column] = stoll(parameters[3]);
      }
      else if (type == "ulong")
      {
        ulong_matrixes[index][ind_row][ind_column] = stoull(parameters[3]);
      }
      else if (type == "string")
      {
        string_matrixes[index][ind_row][ind_column] = parameters[3];
      }
    }
    catch(const std::exception& e)
    {
      printDlgt({"Error: [{0}]  matrix_name [{1}] wrong value [{2}]", 
                 function_name, matrix_name,parameters[3] });
      return false;
    }
    
    return true; 
  }
  //======================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <parameters [0]="matrix_name"></parameters>
  /// <parameters [1]="row_number"></parameters>
  /// <parameters [2]="ppl_array"></parameters>
  bool Matrix::FuncAddArrayToRow(vector<string> parameters, string& result, Composite* node) 
  { 
    string function_name = "Matrix.FuncAddArrayToRow";
    string strTemp = "";
    if (parameters.size() != 3) 
    {
        strTemp = "[" + function_name + "] wrong format";
        printDlgt({ "Error: {0}",strTemp });
        return false;
    }
    
    string matrix_name = parameters[0];
    string nrow = parameters[1];
    string ppl_array = parameters[2];
    int index_in_row = 0;
    string tmp = "";

    try 
    {
        string type = "";
        int rows = 0, columns = 0, index = 0;
        bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
        if (!b) 
        {
            strTemp = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
            printDlgt({ "Error: {0}",strTemp });
            return false;
        }

        int row_number = stoi(nrow);
        if (row_number < 0 || row_number >= rows) 
        {
            strTemp = "[" + function_name + "] [" + matrix_name + "] row_number [" + nrow + "] is out of bounds";
            printDlgt({ "Error: {0}",strTemp });
            return false;
        }

        string name, nodes;
        Composite* path = nullptr;
        b = ppl->processing->GetPathAndNameFromGlobalLocal(function_name, ppl_array, path, nodes, name);
        if (!b) return false;

        Composite* node_array = nullptr;
        for (auto& c : *(path->_children))
        {
            if (c->name == name) 
            {
                node_array = static_cast<Composite*>(c);
                break;
            }
        }

        if (node_array == nullptr) 
        {
            strTemp = "[" + function_name + "] wrong ppl_array name [" + name + "]";
            printDlgt({"Error: {0}",strTemp});
            return false;
        }

        for (size_t i = 0; i < (node_array->_children)->size(); i++) 
        {
            if (i >= columns) 
            { // Check Bounds
                strTemp = "[" + function_name + "] [" + matrix_name + "] column index [" + to_string(i) + "] is out of bounds";
                printDlgt({ "Warning: {0}",strTemp });
                return true;
            }
            tmp = (*(node_array->_children))[i]->value; 
            index_in_row = i;

            if (type == "double") 
            {
                double_matrixes[index][row_number][i] = stod(tmp);
            } 
            else if (type == "float") 
            {
                float_matrixes[index][row_number][i] = stof(tmp);
            } 
            else if (type == "decimal")
            {
              decimal_matrixes[index][row_number][i] = stod(tmp); // long double for decimal
            }
            else if (type == "bool")
            {
              tmp = ToLower(tmp);
              bool_matrixes[index][row_number][i] = (tmp == "true");
            }
            else if (type == "int")
            {
              int_matrixes[index][row_number][i] = stoi(tmp);
            }
            else if (type == "uint")
            {
              uint_matrixes[index][row_number][i] = (unsigned int)(stoul(tmp));
            }
            else if (type == "long")
            {
              long_matrixes[index][row_number][i] = stoll(tmp);
            }
            else if (type == "ulong")
            {
              ulong_matrixes[index][row_number][i] = stoull(tmp);
            }
            else if (type == "string")
            {
              string_matrixes[index][row_number][i] = tmp;
            }

        }
    } 
    catch (const exception& ex) 
    {
        strTemp = "[" + matrix_name + "]   wrong value";
        printDlgt({ "Error: {0}",strTemp });
        return false;
    }
    return true; 
  }
  //======================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <parameters [0]="matrix_name"></parameters>
  /// <parameters [1]="column_number"></parameters>
  /// <parameters [2]="ppl_array"></parameters>
  bool Matrix::FuncAddArrayToColumn(vector<string> parameters, string& result, Composite* node) 
  { 
    string function_name = "Matrix.FuncAddArrayToColumn";
    string strTemp = "";
    if (parameters.size() != 3) 
    {
        strTemp = "[" + function_name + "] wrong format";
        printDlgt({ "Error: {0}",strTemp });
        return false;
    }
    string matrix_name = parameters[0];
    string ncolumn = parameters[1];
    string ppl_array = parameters[2];
    int index_in_row = 0;
    string tmp = "";
    try
    {
        string type = "";
        int rows = 0, columns = 0, index = 0;
        bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
        if (!b) 
        {
            strTemp = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
            printDlgt({ "Error: {0}",strTemp });
            return false;
        }
        int column_number = stoi(ncolumn);
        if (column_number < 0 || column_number >= rows) 
        {
            strTemp = "[" + function_name + "] [" + matrix_name + "] column_number [" + ncolumn + "] is out of bounds";
            printDlgt({ "Error: {0}",strTemp });
            return false;
        }
        string name, nodes;
        Composite* path = nullptr;
        b = ppl->processing->GetPathAndNameFromGlobalLocal(function_name, ppl_array, path, nodes, name);
        if (!b) return false;
        Composite* node_array = nullptr;
        for (auto& c : *(path->_children))
        {
            if (c->name == name) 
            {
                node_array = static_cast<Composite*>(c);
                break;
            }
        }
        if (node_array == nullptr) 
        {
            strTemp = "[" + function_name + "] wrong ppl_array name [" + name + "]";
            printDlgt({"Error: {0}",strTemp});
            return false;
        }
        for (size_t i = 0; i < (node_array->_children)->size(); i++) 
        {
            if (i >= rows) 
            { // Check Bounds
                strTemp = "[" + function_name + "] [" + matrix_name + "] row index [" + to_string(i) + "] is out of bounds";
                printDlgt({ "Warning: {0}",strTemp });
                return true;
            }
            tmp = (*(node_array->_children))[i]->value; 
            index_in_row = i;

            if (type == "double") 
            {
                double_matrixes[index][i][column_number] = stod(tmp);
            } 
            else if (type == "float") 
            {
                float_matrixes[index][i][column_number] = stof(tmp);
            } 
            else if (type == "decimal")
            {
              decimal_matrixes[index][i][column_number] = stod(tmp); // long double for decimal
            }
            else if (type == "bool")
            {
              tmp = ToLower(tmp);
              bool_matrixes[index][i][column_number] = (tmp == "true");
            }
            else if (type == "int")
            {
              int_matrixes[index][i][column_number] = stoi(tmp);
            }
            else if (type == "uint")
            {
              uint_matrixes[index][i][column_number] = (unsigned int)(stoul(tmp));
            }
            else if (type == "long")
            {
              long_matrixes[index][i][column_number] = stoll(tmp);
            }
            else if (type == "ulong")
            {
              ulong_matrixes[index][i][column_number] = stoull(tmp);
            }
            else if (type == "string")
            {
              string_matrixes[index][i][column_number] = tmp;
            }
        }
    }
    
    catch (const exception& ex) 
    {
        strTemp = "[" + matrix_name + "]   wrong value";
        printDlgt({ "Error: {0}",strTemp });
        return false;
    }
    return true; 
  }
  //======================================================================  
  bool Matrix::FuncWrite(vector<string> parameters, string& result, Composite* node) 
  { 
    string function_name = "Matrix.FuncWrite";

    if (parameters.size() < 1 || parameters.size() > 2) 
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    string matrix_name = parameters[0];
    string print_mode = "row"; // row, col, col0

    if (parameters.size() == 2) 
    {
      if (parameters[1] == "row") print_mode = "row";
      else if (parameters[1] == "col") print_mode = "col";
      else if (parameters[1] == "col0") print_mode = "col0";
    }

    try 
    {
      bool b = true;
      string type;
      int length = 0;
      int rows = 0;
      int columns = 0;
      int index = 0;

      b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b) 
      {
        printDlgt({ "Error: [{0}] matrix [{1}] does not exist", function_name, matrix_name });
        return false;
      }

      printDlgt({"=====matrix {0}=====\n", matrix_name});
      if (type == "double") 
      {
        double** d = double_matrixes[index];
        Write<double>(d,rows,columns, print_mode);
      }
      
      else if (type == "float") 
      {
        Write<float>(float_matrixes[index],rows,columns,print_mode);
      }      
      else if (type == "decimal") 
      {
        Write<double>(decimal_matrixes[index], rows,columns,print_mode);
      }
      else if (type == "bool") 
      {
        Write<bool>(bool_matrixes[index],rows,columns, print_mode);
      }
      else if (type == "int") 
      {
        Write<int>(int_matrixes[index],rows,columns, print_mode);
      }
      else if (type == "uint") 
      {
        Write<unsigned int>(uint_matrixes[index],rows,columns, print_mode);
      }
      else if (type == "long") 
      {
        Write<long>(long_matrixes[index],rows,columns, print_mode);
      }
      else if (type == "ulong") 
      {
        Write<uint64_t>(ulong_matrixes[index],rows,columns, print_mode);
      }
      else if (type == "string") 
      {
        Write<string>(string_matrixes[index],rows,columns, print_mode);
      }
    }
    catch (const exception& e) 
    {
      printDlgt({ "Error: [{0}] [{1}]", string(e.what()) });
      return false;
    }
    return true; 
  }
  //======================================================================
  bool Matrix::FuncWriteNames(vector<string> parameters, string& result, Composite* node) 
  { 
    const string function_name = "Matrix.WriteNames";

    if (!parameters.empty())
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    try
    {
      if (matrix_properties.empty())
      {
        printDlgt({ "Warning: [{0}] matrix_properties is empty",function_name });
      }
      else
      {
        printDlgt({ "====={0}=====", function_name });
        for (const auto& pair : matrix_properties)
        {
          //pair.second.index is index in vector_properties
          string tmp = pair.first + "\t" + pair.second.type + "\t" + to_string(pair.second.rows) + "\t";
          tmp += to_string(pair.second.columns) + "\t[" + to_string(pair.second.index) + "]";
          printDlgt({ "{0}",tmp });
        }
      }
    }
    catch (const exception&)
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
    return true; 
  }
  //======================================================================
  bool Matrix::FuncDelete(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Matrix.Delete";

    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }

    string matrix_name = parameters[0];
    try
    {
      string type;
      int rows = 0;
      int columns = 0;
      int index = 0;

      bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b)
      {
        printDlgt({ "Error: [{0}] matrix [{1}] does not exist", function_name, matrix_name });
        return false;
      }
      
      if (type == "double")
      {
        deallocateMatrix(double_matrixes[index], rows);
        double_matrixes.erase(double_matrixes.begin() + index);

      }
      else if (type == "float")
      {
        deallocateMatrix(float_matrixes[index], rows);
        float_matrixes.erase(float_matrixes.begin() + index);
      }
      else if (type == "decimal")
      {
        deallocateMatrix(decimal_matrixes[index], rows);
        decimal_matrixes.erase(decimal_matrixes.begin() + index);
      }
      else if (type == "bool")
      {
        deallocateMatrix(bool_matrixes[index], rows);
        bool_matrixes.erase(bool_matrixes.begin() + index);
      }
      else if (type == "int")
      {
        deallocateMatrix(int_matrixes[index], rows);
        int_matrixes.erase(int_matrixes.begin() + index);
      }
      else if (type == "uint")
      {
        deallocateMatrix(uint_matrixes[index], rows);
        uint_matrixes.erase(uint_matrixes.begin() + index);
      }
      else if (type == "long")
      {
        deallocateMatrix(long_matrixes[index], rows);
        long_matrixes.erase(long_matrixes.begin() + index);
      }
      else if (type == "ulong")
      {
        deallocateMatrix(ulong_matrixes[index], rows);
        ulong_matrixes.erase(ulong_matrixes.begin() + index);
      }
      else if (type == "string")
      {
        deallocateMatrix(string_matrixes[index], rows);
        string_matrixes.erase(string_matrixes.begin() + index);
      }

      matrix_properties.erase(matrix_name);
    }
    catch (const exception&)
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
    return true; 
  }
  //======================================================================
  bool Matrix::FuncDeleteAll(vector<string> parameters, string& result, Composite* node) 
  {
    const string function_name = "Matrix.DeleteAll";

    if (parameters.size() != 0)
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }
    try
    {
      if (matrix_properties.empty())
      {
        printDlgt({ "Warning: [{0}] matrix_properties is empty", function_name });
        return true;
      }
      bool b;
      string type;
      int rows = 0;
      int columns = 0;
      int index = 0;
      for (auto& mp : matrix_properties)
      {
        //GetMatrixProperty(mp.first, type, rows, columns, index);
        rows = mp.second.rows;
        columns = mp.second.columns;
        index = mp.second.index;
        if(type == "double")
          deallocateMatrix(double_matrixes[index], rows);
        if (type == "float")
          deallocateMatrix(float_matrixes[index], rows);
        if (type == "decimal")
          deallocateMatrix(decimal_matrixes[index], rows);
        if (type == "bool")
          deallocateMatrix(bool_matrixes[index], rows);
        if (type == "int")
          deallocateMatrix(int_matrixes[index], rows);
        if (type == "uint")
          deallocateMatrix(uint_matrixes[index], rows);
        if (type == "long")
          deallocateMatrix(long_matrixes[index], rows);
        if (type == "ulong")
          deallocateMatrix(ulong_matrixes[index], rows);
        if (type == "string")
          deallocateMatrix(string_matrixes[index], rows);
      }
      matrix_properties.clear();
      double_matrixes.clear();
      float_matrixes.clear();
      decimal_matrixes.clear();
      bool_matrixes.clear();
      int_matrixes.clear();
      uint_matrixes.clear();
      long_matrixes.clear();
      ulong_matrixes.clear();
      string_matrixes.clear();

    }
    catch (const exception&)
    {
      printDlgt({ "Error: [{0}] ..." , function_name });
      return false;
    }
    return true; 
  }
  //======================================================================
  /// <summary>
  /// 
  /// </summary>
  /// <param name="matrix_ name"></param>
  /// <param name="cw | ccw"></param>
  /// <returns></returns>
  bool Matrix::FuncRotate(vector<string> parameters, string& result, Composite* node) 
  {
    string function_name = "Matrix.FuncRotate";
    string strTemp = "";
    if (parameters.size() != 2) 
    {
      strTemp = "[" + function_name + "] wrong format";
      printDlgt({"Error: {0}",strTemp });
      return false;
    }
    string matrix_name = parameters[0];
    try 
    {
      string type = "";
      int rows = 0, columns = 0, index = 0;

      bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b)
      {
        strTemp = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }

      if (columns != rows) 
      {
        strTemp = "[" + function_name + "] matrix [" + matrix_name + "] is not square";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }

      string direction = parameters[1];
      direction = ToLower(direction);
      if (direction != "cw" && direction != "ccw") 
      {
        strTemp = "[" + function_name + "] [" + matrix_name + "] wrong direction[" + direction + "]";
        printDlgt({ "Error: {0}",strTemp });
        return false;
      }

      // Rotate based on type
      if (type == "double") 
      {
        Rotate<double>(double_matrixes, index, rows,columns, direction);
      }
      else if (type == "float")
      {
        Rotate<float>(float_matrixes, index, rows,columns, direction);
      }
      else if (type == "decimal") 
      {
        Rotate<double>(decimal_matrixes, index, rows,columns, direction);
      }
      else if (type == "bool")
      {
        Rotate<bool>(bool_matrixes, index, rows,columns, direction);
      }

      else if (type == "int")
      {
        Rotate<int>(int_matrixes, index, rows,columns, direction);
      }
      else if (type == "uint")
      {
        Rotate<unsigned int>(uint_matrixes, index, rows,columns, direction);
      }

      else if (type == "long") 
      {
        Rotate<long>(long_matrixes, index, rows,columns, direction);
      } 
      else if (type == "ulong")
      {
        Rotate<uint64_t>(ulong_matrixes, index, rows,columns, direction);
      }
      else if (type == "string")
      {
        Rotate<string>(string_matrixes, index, rows,columns, direction);
      }  
   }
    catch (const exception& ex) 
    {
      strTemp = "[" + function_name + "] " + ex.what();
      printDlgt({ "Error: {0}",strTemp });
      return false;
    }
    return true; 
  }
  //======================================================
  // Function to sort the matrix by a specific column
  void sortMatrixByColumn(std::vector<std::vector<double>>& matrix, int column) 
  {
    sort(matrix.begin(), matrix.end(), [column](const vector<double>& a, const vector<double>& b) 
    {
      return a[column] < b[column];
    });
  }
  //======================================================
  ////template<typename T>
  //// Function to sort a matrix in ascending order based on a specified column
  //void Matrix::sortMatrixAscendingOrder(double** matrix, int columns, int rows, int column_index) 
  //{
  //  sort(matrix, matrix + rows, [column_index](double* a, double* b) 
  //    {
  //    return a[column_index] < b[column_index];
  //    });
  //}

  //// Function to sort a matrix in descending order based on a specified column
  //void Matrix::sortMatrixDescendingOrder(double** matrix, int columns, int rows, int column_index) 
  //{
  //  sort(matrix, matrix + rows, [column_index](double* a, double* b) 
  //    {
  //    return a[column_index] > b[column_index];
  //    });
  //}
  //======================================================
  // Matrix::FuncSort(matrix_name)(column_index)(order)
  // order:= ascend | descend
  bool Matrix::FuncSort(vector<string> parameters, string& result, Composite* node)
  {
    string function_name = "Matrix.FuncSort";
    string err = "";
    if (parameters.size() != 3)
    {
      err = "[" + function_name + "] wrong format";
      printDlgt({ "Error: {0}",err });
      return false;
    }
    string matrix_name = parameters[0];
    string order = parameters[2];
    //vector<double**> double_matrixes;
    try
    {
      string type = "";
      int rows = 0, columns = 0, index = 0;

      bool b = GetMatrixProperty(matrix_name, type, rows, columns, index);
      if (!b)
      {
        err = "[" + function_name + "] matrix [" + matrix_name + "] does not exist";
        printDlgt({ "Error: {0}",err });
        return false;
      }
      int column_index = 0;
      if (parameters[1].empty())
      {
        printDlgt({ "Error: [{0}] matrix_name [{1}] index_column is empty",function_name, matrix_name });
        return false;
      }
      if (!TryParse(parameters[1], column_index))
      {
        printDlgt({ "Error: [{0}] matrix_name [{1}] index_column is nor digit [{2}]",function_name, matrix_name, parameters[1]});
        return false;
      }
      if ((column_index < 0) || (column_index >= columns))
      {
        printDlgt({ "Error: [{0}] matrix_name [{1}] index_column out of range [{2}]",function_name, matrix_name, parameters[1] });
        return false;
      }
      if (type == "double")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<double>(double_matrixes[index], columns,rows, column_index);
        else
          sortMatrixDescendingOrder<double>(double_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "float")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<float>(float_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<float>(float_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "decimal")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<double>(decimal_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<double>(decimal_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "bool")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<bool>(bool_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<bool>(bool_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "int")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<int>(int_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<int>(int_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "uint")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<unsigned int>(uint_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<unsigned int>(uint_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "long")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<long>(long_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<long>(long_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "ulong")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<uint64_t>(ulong_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<uint64_t>(ulong_matrixes[index], columns, rows, column_index);
      }
      //========
      if (type == "string")
      {
        if (order == "ascend")
          sortMatrixAscendingOrder<string>(string_matrixes[index], columns, rows, column_index);
        else
          sortMatrixDescendingOrder<string>(string_matrixes[index], columns, rows, column_index);
      }
      //========
    }
    catch (const exception& ex)
    {
      err = "[" + function_name + "] " + ex.what();
      printDlgt({ "Error: {0}",err });
      return false;
    }
    return true;
  }

}

