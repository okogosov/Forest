#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  // SetRow(DataFrame_name)(row)(\"ppl_array\") 
  bool DataFrame::FuncSetRow(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "FuncSetRow";
    string tmp;   // for print preparation
    try
    {
      if (parameters.size() < 3)
      {
        tmp = "[" + func_name + "] wrong parameter, format: DataFrame.SetRow (df_name)(row number)(\"ppl_array\")";
        printDlgt({ "Error: {0}",tmp });
        return false;
      }

      string df_name = parameters[0];
      string ppl_array = parameters[2];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      int columns_quantity = (int)(comp_df->_children->size());
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      TryParse(strLength,Length);
      int index = 0;
      if (parameters[1].empty())
      {
        printDlgt({ "Error: [{0}] index is empty",func_name });
        return false;
      }
      bool b = IsDigitsOnly(parameters[1]);  //(parameters[1].find_first_not_of("0123456789") == string::npos);
      if (!b)
      {
        tmp = "[" + func_name + "] [" + df_name + "] index not digital [" + parameters[1] + "]";
        printDlgt({ "Error: {0}",tmp });
        return false;
      }

      if (!TryParse(parameters[1], index))
      {
        printDlgt({ "Error: {0} dataframe [{1}] row not digit [{2}]",func_name, df_name, parameters[1]});
        return false;
      }
      if (index >= Length)
      {
        tmp = "[" + func_name + "] [" + df_name + "] index [" + to_string(index) + "] out of bounds";
        printDlgt({ "Error: {0}",tmp });
        return false;
      }

      Composite* cc = GetArrayComposite(ppl_array);
      if (cc == nullptr)
        return false;

      int real_count = cc->_children->size();
      if (real_count > columns_quantity)
      {
        real_count = columns_quantity;
        tmp = "[" + func_name + "] [" + df_name + "] number of elements [" + to_string(real_count) + "] > columns_number [" + to_string(Length) + "]";
        printDlgt({ "Warning: {0}",tmp });
      }

      for (int i = 0; i < real_count; i++)
      {  // comp_df._children[0] - settings
        string column_name = (*(comp_df->_children))[i + 1]->name;
        string type = GetSettingsValue(comp_settings, column_name + "Type");
        if (type == "Number")
        {
          double d = 0;
          if ((*(cc->_children))[i]->value.empty() ||
            !stod((*(cc->_children))[i]->value)) // Check if conversion is possible
          {
            //comp_df->_children->at(i + 1)->_children[index]->value = "*error";
            Composite* comp1 = (Composite*)(comp_df->_children->at(i + 1));
            (*(comp1->_children))[index]->value = "*error";
            continue;
          }
        }

        if ((*(cc->_children))[i]->value == "\"\"")
          (*(cc->_children))[i]->value = "";

        //comp_df->_children->at(i + 1)->_children[index]->value = cc->_children[i]->value;
        Composite* comp2 = (Composite*)(comp_df->_children->at(i + 1));
        (*(comp2->_children))[index]->value = (*(cc->_children))[i]->value;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}]  {1}", func_name, ex.what() });
      return false;
    }
    return true;
  }
  // SetColumn(DataFrame_name)(col)(\"ppl_array\") 
  bool DataFrame::FuncSetColumn(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "FuncSetColumn";
    string err;
    try
    {
      if (parameters.size() != 3)
      {
        err = "[" + func_name + "] wrong parameter, format: DataFrame.SetColumn (df_name)(column name)(ppl_array)";
        printDlgt({ "Error: {0}",err });
        return false;
      }
      string df_name = parameters[0];
      string column_name = parameters[1];
      string ppl_array = parameters[2];

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      int columns_quantity = comp_df->_children->size();
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      string type = GetSettingsValue(comp_settings, column_name + "Type");
      int Length; 
      if (!TryParse(strLength, Length))
      {
        printDlgt({ "Error: {0} dataframe [{1}] RowsLength not digit [{2}]",func_name, df_name, strLength });
        return false;
      }


      Composite* column_node = nullptr;
      for (int i = 0; i < columns_quantity; i++)
      {
        if ((*(comp_df->_children))[i]->name == column_name)
        {
          column_node = (Composite*)((*(comp_df->_children))[i]);
          break;
        }
      }
      if (column_node == nullptr)
      {
        err = "[" + func_name + "] [" + df_name + "] wrong column name [" + column_name + "]";
        printDlgt({ "Error: {0}",err });
        return false;
      }

      Composite* cc = GetArrayComposite(ppl_array);  // ppl.processing.
      if (cc == nullptr)
        return false;

      //==============================================
      int real_count = cc->_children->size();
      if (real_count > Length)
      {
        real_count = Length;
        err = "[" + func_name + "] [" + df_name + "] number of elements [" + to_string(real_count) + "] > df.Length [" + to_string(Length) + "]";
        printDlgt({ "Warning: {0}",err });
      }
      for (int i = 0; i < real_count; i++)
      {
        if (type == "Number")
        {
          double d = 0;
          if (!stod((*(cc->_children))[i]->value), &d)
          {
            (*(column_node->_children))[i]->value = "*error";
            continue;
          }
        }
        (*(column_node->_children))[i]->value = (*(cc->_children))[i]->value;
      }
    }
    catch (const exception& ex)
    {
      err = "[" + func_name + "] " + string(ex.what());
      printDlgt({ "Error: {0}",err });
      return false;
    }
    return true;
  }
}