#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Directory.h"

using namespace std;
namespace PPLNS
{
  static Directory* DIRECTORYInstance = nullptr;

  void Directory_CreateInstance(PPL* ppl)
  {
    DIRECTORYInstance = new Directory(ppl);
    DIRECTORYInstance->AddToKeywordDictionary();
  }

  Directory::Directory(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Directory::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("GetFiles", FuncGetFiles);
    AddKeyword("GetDirectories", FuncGetDirectories);
    AddKeyword("SetCurrentDirectory", FuncSetCurrentDirectory);
    AddKeyword("GetCurrentDirectory", FuncGetCurrentDirectory);
    AddKeyword("GetParent", FuncGetParent);
    AddKeyword("CreateDirectory", FuncCreateDirectory);
    AddKeyword("Exists", FuncExists);
    AddKeyword("Delete", FuncDelete);

    help_dict->insert({ "help",                "\tDirectory.help([name])" });
    help_dict->insert({ "GetFiles",            "\tDirectory.GetFiles(\"node of PPL array\")(\"path\")" });
    help_dict->insert({ "GetDirectories",      "\tDirectory.GetDirectories(\"node of PPL array\")(\"path\")" });
    help_dict->insert({ "SetCurrentDirectory", "\tDirectory.SetCurrentDirectory(\"path\")" });
    help_dict->insert({ "GetCurrentDirectory", "\tDirectory.GetCurrentDirectory()" });
    help_dict->insert({ "GetParent",           "\tDirectory.GetParent(\"path\")" });
    help_dict->insert({ "CreateDirectory",     "\tDirectory.CreateDirectory(\"path\")" });
    help_dict->insert({ "Exists",              "\tDirectory.Exists(\"path\")" });
    help_dict->insert({ "Delete",              "\tDirectory.Delete(\"path\")" });

    for (const auto pair : *keyword_dict)
    {
      string key = "Directory." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Directory", this });
  }
  //=============================================================
  bool Directory::FuncGetFiles(vector<string> parameters, string& result, Composite* node) 
  {
    // params: string_array name, dir_name
    if (parameters.size() != 2) 
    {
      printDlgt({ "Error: [Directory.FuncGetFiles] wrong format: Directory.GetFiles(node of PPL array)(path)" });
      return false;
    }

    string dir_name = parameters[1];
    dir_name.erase(0, dir_name.find_first_not_of("\"")); // Trim leading quotes
    dir_name.erase(dir_name.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    if (dir_name.length() == 2 && dir_name[1] == ':') 
    {
      dir_name += "\\";
    }

    if (!filesystem::exists(dir_name)) 
    {
      printDlgt({ "Error: [Directory.FuncGetFiles] Directory [{0}] is omitted",dir_name });
      return false;
    }

    vector<string> arr;
    for (const auto& entry : filesystem::directory_iterator(dir_name)) 
    {
      arr.push_back(entry.path().string());
    }

    string name;
    string fullname = parameters[0]; 
    string func_name = "Directory.FuncGetFiles";
    Composite* path = nullptr;
    string nodes;

    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b) 
    {
      return false;
    }

    ppl->processing->FuncReAllocArray({ fullname, "", to_string(arr.size()), "" }, result, node);

    for (auto& c : *(path->_children)) 
    {
      if (c->name == name) 
      {
        Composite* comp = dynamic_cast<Composite*>(c);
        vector<Component*> lc = *(comp->_children);
        int i = 0;
        for (const string& s : arr)
          lc[i++]->value = s;
      }
    }
    return true; 
  }
  //=============================================================
  bool Directory::FuncGetDirectories(vector<string> parameters, string& result, Composite* node) 
  {
    // params: string_array name, dir_name
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Directory.FuncGetDirectories] wrong format: Directory.GetDirectories(node of PPL array)(path)" });
      return false;
    }

    string dir_name = parameters[1];
    dir_name.erase(0, dir_name.find_first_not_of("\"")); // Trim leading quotes
    dir_name.erase(dir_name.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    if (!filesystem::exists(dir_name))
    {
      printDlgt({ "Error: [Directory.FuncGetDirectories] Directory [{0}] is omitted", dir_name });
      return false;
    }

    vector<string> arr;
    for (const auto& entry : filesystem::directory_iterator(dir_name))
    {
      arr.push_back(entry.path().string());
    }

    string name;
    string fullname = parameters[0]; 
    string func_name = "Directory.FuncGetDirectories";
    Composite* path = nullptr;
    string nodes;

    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
    {
      return false;
    }

    ppl->processing->FuncReAllocArray({ fullname, "", to_string(arr.size()), "" }, result, node);

    for (auto& c : *(path->_children))
    {
      if (c->name == name)
      {
        Composite* comp = dynamic_cast<Composite*>(c);
        vector<Component*> lc = *(comp->_children);
        int i = 0;
        for (const string& s : arr)
          lc[i++]->value = s;
      }
    }
    return true; 
  }
  //=============================================================
  bool Directory::FuncSetCurrentDirectory(vector<string> parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Directory.FuncSetCurrentDirectory] wrong format: Directory.SetCurrentDirectory(name)" });
      return false;
    }

    string dir_name = parameters[0];
    dir_name.erase(0, dir_name.find_first_not_of("\"")); // Trim leading quotes
    dir_name.erase(dir_name.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    try
    {
      filesystem::current_path(dir_name);
    }
    catch (const filesystem::filesystem_error& e)
    {
      printDlgt({ "Error: [Directory.FuncSetCurrentDirectory] The specified directory does not exist. " + string(e.what()) });
      return false;
    }
    return true; 
  }
  //=============================================================
  bool Directory::FuncGetCurrentDirectory(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() > 1)
    {
      printDlgt({ "Error: [Directory.FuncGetCurrentDirectory] wrong format: Directory.GetCurrentDirectory()" });
      return false;
    }
    result = filesystem::current_path().string();
    return true; 
  }
  //=============================================================
  bool Directory::FuncGetParent(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Directory.FuncGetParent] wrong format: Directory.FuncGetParent(path)" });
      return false;
    }

    string path = parameters[0];
    path.erase(0, path.find_first_not_of(" \n\r\t")); // Trim leading whitespace
    path.erase(path.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    filesystem::path fs_path(path);
    if (fs_path.has_parent_path())
    {
      result = fs_path.parent_path().string();
    }
    else
    {
      result = ""; // No parent directory
    }
    return true; 
  }
  //=============================================================
  bool Directory::FuncCreateDirectory(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Directory.FuncCreateDirectory] wrong format: Directory.FuncCreateDirectory(path)" });
      return false;
    }

    string path = parameters[0];
    path.erase(0, path.find_first_not_of(" \n\r\t")); // Trim leading whitespace
    path.erase(path.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    filesystem::path fs_path(path);
    filesystem::create_directories(fs_path); // Create directory (and parent directories if needed)

    auto creation_time = filesystem::last_write_time(fs_path);
    auto sctp = chrono::time_point_cast<chrono::system_clock::duration>(creation_time - filesystem::file_time_type::clock::now() + chrono::system_clock::now());
    time_t cftime = chrono::system_clock::to_time_t(sctp);
    //result = ctime(&cftime); // Convert to string
    char str[26];
    ctime_s(str,sizeof str,&cftime);
    result = str;
    return true; 
  }
  //=============================================================
  bool Directory::FuncExists(vector<string> parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Directory.FuncExists] wrong format: Directory.FuncExists(path)" });
      return false;
    }

    string path = parameters[0];
    path.erase(0, path.find_first_not_of(" \n\r\t")); // Trim leading whitespace
    path.erase(path.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    bool exists = filesystem::exists(path);
    result = exists ? "True" : "False";
    return true; 
  }
  //=============================================================
  void Directory::DeleteDirectory(string target_dir)
  {
    vector<string> files;
    vector<string> dirs;

    // Get all files and directories in the target directory
    for (const auto& entry : filesystem::directory_iterator(target_dir))
    {
      if (entry.is_regular_file())
      {
        files.push_back(entry.path().string());
      }
      else if (entry.is_directory())
      {
        dirs.push_back(entry.path().string());
      }
    }

    // Delete all files
    for (const auto& file : files)
    {
      filesystem::remove(file);
    }

    // Recursively delete all directories
    for (const auto& dir : dirs)
    {
      DeleteDirectory(dir);
    }

    // Finally, delete the target directory
    filesystem::remove(target_dir);
  }
  //=============================================================
  bool Directory::FuncDelete(vector<string> parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Directory.FuncDelete] wrong format: Directory.FuncDelete(path)" });
      result = "False";
      return false;
    }

    string path = parameters[0];
    path.erase(0, path.find_first_not_of(" \n\r\t")); // Trim leading whitespace
    path.erase(path.find_last_not_of(" \n\r\t") + 1); // Trim trailing whitespace

    try
    {
      DeleteDirectory(path);
    }
    catch (const exception& e)
    {
      printDlgt({ "Error: [Directory.FuncDelete] [{0}]", string(e.what()) });
      result = "False";
      return false;
    }
    result = "True";
    return true; 
  }
}
