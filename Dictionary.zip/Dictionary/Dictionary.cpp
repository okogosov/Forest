#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Dictionary.h"

using namespace std;
namespace PPLNS
{
  static Dictionary* DICTIONARYInstance = nullptr;

  void Dictionary_CreateInstance(PPL* ppl)
  {
    DICTIONARYInstance = new Dictionary(ppl);
    DICTIONARYInstance->AddToKeywordDictionary();
  }

  Dictionary::Dictionary(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void Dictionary::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Count", FuncCount);
    AddKeyword("Add", FuncAdd);
    AddKeyword("GetValue", FuncGetValue);
    AddKeyword("SetValue", FuncSetValue);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Clear", FuncClear);
    AddKeyword("ContainsKey", FuncContainsKey);
    AddKeyword("Remove", FuncRemove);
    AddKeyword("AddArray", FuncAddArray);
    AddKeyword("ToArray", FuncToArray);

    help_dict->insert({ "help",   "\tDictionary.help([name])" });
    help_dict->insert({ "Create", "\tCreates Dictionary: Dictionary.Create(name)" });
    help_dict->insert({ "Delete", "\tDelete all dictionaries: Dictionary.Delete()\r\n\tor one dictionary: Dictionary.Delete(dictionary_name)" });
    help_dict->insert({ "Count",  "\tReturns the number of elements actually contained in Dictionary: Dictionary.Count(dictionary_name)" });
    help_dict->insert({ "Add",    "\tAdds the specified key and value to the Dictionary: Dictionary.Add(dictionary_name)(key)(value)" });
    help_dict->insert({ "GetValue", "\treturn True or False: Dictionary.GetValue(dictionary name)(key)(var name for return)" });
    help_dict->insert({ "SetValue", "\treturn True or False: Dictionary.SetValue(dictionary name)(key)(value)" });
    help_dict->insert({ "Write", 
      "\tWrites dictionary names or all elements from the specified Dictionary to the standard output stream:\r\n\tDictionary.Write() or Dictionary.Write(dictionary name)" });
    help_dict->insert({ "Clear", 
      "\tRemoves all objects from the Dictionary: Dictionary.Clear(dictionary_name)" });
    help_dict->insert({ "ContainsKey", 
      "\tDetermines whether the Dictionary contains the specified key, returns True or False:\r\n\tDictionary.ContainsKey(dictionary_name)(key)" });
    help_dict->insert({ "Remove", 
      "\tRemoves the value with the specified key from the Dictionary:\r\n\tDictionary.Remove(dictionary_name)(value)" });
    help_dict->insert({ "AddArray", 
      "\tAdds PPL array to the Dictionary: Dictionary.AddArray(\"PPL array\")(dictionary name)" });
    help_dict->insert({ "ToArray", 
      "\tCopies all elements from Dictionary  to new PPL array:\r\n\tDictionary.ToArray(dictionary name)(\"PPL array\")" });
    
    for (const auto pair : *keyword_dict)
    {
      string key = "Dictionary." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Dictionary", this });
  }
  //=======================================================
  bool Dictionary::eraseElement(vector<NamedDictionary>& named_dictionaries, const string& target_name)
  {
      bool found = false;
      for (const auto& nd : named_dictionaries)
      {
        if (nd.name == target_name)
        {
          found = true;
          break;
        }
      }
      if (found)
      {
        auto it = remove_if(named_dictionaries.begin(), named_dictionaries.end(),
          [&target_name](const NamedDictionary& nd)
          {
            return nd.name == target_name;
          });
        named_dictionaries.erase(it, named_dictionaries.end());
        return true;
      }
      else
        return false;
  }
  //=======================================================
  bool Dictionary::GetNamedDictionaryByName(string calling_method_name, string name, NamedDictionary*& ndict)
  {
    int j = 0;
    for (j = 0; j < named_dictionaries.size(); j++)
    {
      ndict = &(named_dictionaries[j]);
      if (ndict->name == name)
        break;
    }
    if (j == named_dictionaries.size())
    {
      printDlgt({"Error: [Dictionary.GetNamedDictionaryByName] [{0}] wrong name [{1}]", calling_method_name, name });
      return false;
    }
    return true;
  }
  //=======================================================
  bool Dictionary::FuncCreate(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({"Error: [Dictionary.FuncCreate] wrong number of parameters != 1"});
      return false;
    }
    string dict_name = parameters[0];
    dict_name = trim(dict_name, "\"");

    for (size_t j = 0; j < named_dictionaries.size(); j++)
    {
      NamedDictionary& nht1 = named_dictionaries[j];
      if (nht1.name == dict_name)
      {
        named_dictionaries.erase(named_dictionaries.begin() + j);   // Delete from vector
        printDlgt({"Warning: [Dictionary.FuncCreate] Dictionary [{0}] is recreated",dict_name });
        break;
      }
    }

    NamedDictionary ndict;
    ndict.name = dict_name;
    ndict.dictionary = unordered_map<string, string>();
    named_dictionaries.push_back(ndict);
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncDelete(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() > 1)
    {
      printDlgt({ "Error: [Dictionary.FuncDelete] wrong number of parameters > 1" });
      return false;
    }
    if (parameters.empty())
      named_dictionaries.clear();
    else
    {
      string dict_name = trim(parameters[0], "\"");
      for (auto& ndict : named_dictionaries)
      {
        if (ndict.name == dict_name)
        {
          if(eraseElement(named_dictionaries, dict_name))
            return true;
          else
          {
            printDlgt({ "Error: [Dictionary.FuncDelete] dictionary [{0}] not found" , dict_name});
            return false;
          }
        }
      }
      return false;
    }
  }
  //=======================================================
  bool Dictionary::FuncCount(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Dictionary.FuncCount] wrong number of parameters != 1" });
      return false;
    }
    string dict_name = trim(parameters[0],"\"");

    NamedDictionary* ndict = nullptr;

    if (GetNamedDictionaryByName("Dictionary.FuncCount", dict_name, ndict) == false)
      return false;
    result = to_string(ndict->dictionary.size());
    return true; 
  }
  //=======================================================
  // name, key, value
  bool Dictionary::FuncAdd(const vector<string>& parameters, string& result, Composite* node) 
  {
    result = "False";
    if (parameters.size() != 3)
    {
      printDlgt({"Error: [Dictionary.FuncAdd] wrong number of parameters != 3"});
      return false;
    }

    string dict_name = trim(parameters[0], "\"");
    string key       = trim(parameters[1], "\"");
    string value     = trim(parameters[2], "\"");

    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName("Dictionary.Add", dict_name, ndict) == false)
      return false;
    if (ndict->dictionary.find(key) != ndict->dictionary.end())
    {
      printDlgt({ "Error: [Dictionary.FuncAdd] Dictionary [{0}] key [{1}] is already existed",dict_name, key });
      return false;
    }
    else
      ndict->dictionary[key] = value; // Add key-value pair
    result = "True";
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncGetValue(const vector<string>& parameters, string& result, Composite* node) 
  {
    // name, key, out value, return result = True or False
    // value is ppl var
    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [Dictionary.FuncGetValue] wrong number of parameters != 3" });
      return false;
    }

    result = "";
    string dict_name = trim(parameters[0], "\"");
    string key = trim(parameters[1], "\"");
    string value = trim(parameters[2], "\"");

    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName("Dictionary.FuncGetValue", dict_name, ndict) == false)
      return false;
    //========================================================
    Composite* path = nullptr;
    string nodes = "";
    string name = "";
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal("Dictionary.FuncGetValue", value, path, nodes, name);

    if (b == false)
      return false;

    Component* c = nullptr;
    for (size_t j = 0; j < path->_children->size(); j++)
    {
      c = (*(path->_children))[j];
      if (c->name == name)
        break;
    }
    if (c == nullptr)
      return false;

    auto it = ndict->dictionary.find(key);
    if (it != ndict->dictionary.end())
    {
      c->value = it->second; // Assign the found value
      result = "True"; // Indicate success
      return true;
    }
    else
    {
      result = "False"; // Indicate failure
      printDlgt({"Error: [Dictionary.FuncGetValue] Dictionary [{0}] wrong key [{1}]",parameters[0],parameters[1]});
      return false;
    }
  }
  //=======================================================
  bool Dictionary::FuncSetValue(const vector<string>& parameters, string& result, Composite* node) 
  { 
    // dict_name = parameters[0],
    // key = parameters[1],
    // value = parameters[2],  // value is ppl var
    // return result = True or False
    string func_name = "Dictionary.FuncSetValue";

    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 3",func_name });
      return false;
    }
    string dict_name = trim(parameters[0],"\"");
    string key       = trim(parameters[1], "\"");
    string value     = trim(parameters[2], "\"");

    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName(func_name, dict_name, ndict) == false)
      return false;
    //========================================================
    Composite* path = nullptr;
    string nodes = "";
    string name = "";
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, value, path, nodes, name);

    if (b == false)
      return false;

    Component* c = nullptr;
    for (size_t j = 0; j < path->_children->size(); j++)
    {
      c = (*(path->_children))[j];
      if (c->name == name)
        break;
    }

    if (c == nullptr)
    {
      printDlgt({ "Error: [{0}] wrong name [{1}]",func_name, value });
      return false;
    }

    // Check if the key exists in the dictionary
    auto it = ndict->dictionary.find(key);
    if (it == ndict->dictionary.end())
    {
      result = "False"; // Key does not exist
      printDlgt({ "Error: [Dictionary.FuncSetValue] Dictionary [{0}] wrong key [{1}]",dict_name, key });
      return false;
    }

    // Set the value in the dictionary
    ndict->dictionary[key] = value;
    result = "True"; // Indicate success
    return true;
  }
  //=======================================================
  bool Dictionary::FuncWrite(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() > 1)
    {
      printDlgt({ "Error: [Dictionary.FuncWrite] wrong number of parameters > 1" });
      return false;
    }
    result = "";
    string dict_name;
    if (parameters.empty())
    {
      for (const NamedDictionary& ndict : named_dictionaries)
        printDlgt({"{0}",ndict.name });
    }
    else
    {
      dict_name = trim(parameters[0],"\"");
      printDlgt({"Dictionary.Write [{0}]",dict_name});

      NamedDictionary* ndict = nullptr;
      if (GetNamedDictionaryByName("Dictionary.Write", dict_name, ndict) == false)
        return false;

      if (ndict->dictionary.empty())
      {
        printDlgt({ "\tdictionary [{0}] is empty",dict_name });
      }
      else
      {
        for (const auto& pair : ndict->dictionary)
        {
          printDlgt({ "\t{0,-20}\t{1}" , pair.first, pair.second });
        }
      }
    }
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncClear(const vector<string>& parameters, string& result, Composite* node) 
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [Dictionary.FuncClear] wrong number of parameters != 1" });
      return false;
    }
    string dict_name = trim(parameters[0],"\"");
    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName("Dictionary.FuncClear", dict_name, ndict) == false)
      return false;
    ndict->dictionary.clear();
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncContainsKey(const vector<string>& parameters, string& result, Composite* node)
  {
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Dictionary.FuncContainsKey] wrong number of parameters != 2" });
      return false;
    }
    string dict_name = trim(parameters[0], "\"");
    string key       = trim(parameters[1], "\"");
    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName("Dictionary.FuncContainsKey", dict_name, ndict) == false)
      return false;
    if (ndict->dictionary.find(key) != ndict->dictionary.end())
      result = "True";
    else
      result = "False";
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncRemove(const vector<string>& parameters, string& result, Composite* node) 
  { 
    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [Dictionary.FuncRemove] wrong number of parameters != 2" });
      return false;
    }
    string dict_name = trim(parameters[0], "\"");
    string key = trim(parameters[1], "\"");
    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName("Dictionary.FuncRemove", dict_name, ndict) == false)
      return false;
    auto it = ndict->dictionary.find(key);
    if (it != ndict->dictionary.end())
    {
      ndict->dictionary.erase(it);
      return true;
    }
    else
    {
      printDlgt({ "Error: [Dictionary.FuncRemove] Dictionary [{0}] key [{1}] is not exist",dict_name, key });
      return false;
    }    
  }
  //=======================================================
  bool Dictionary::FuncAddArray(const vector<string>& parameters, string& result, Composite* node) 
  { 
    // ppl_array, dict_name
    string func_name = "Dictionary.FuncAddArray";

    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 3",func_name });
      return false;
    }
    string ppl_array = trim(parameters[0], "\"");
    string dict_name = trim(parameters[1], "\"");
    
    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName(func_name, dict_name, ndict) == false)
      return false;
    //========================================================
    Composite* path = nullptr;
    string nodes = "";
    string name = "";
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array, path, nodes, name);

    if (b == false)
      return false;

    Component* c = nullptr;
    for (size_t j = 0; j < path->_children->size(); j++)
    {
      c = (*(path->_children))[j];
      if (c->name == name)
        break;
    }

    if (c == nullptr)
    {
      printDlgt({ "Error: [{0}] wrong name of ppl_array [{1}]",func_name, ppl_array });
      return false;
    }
    Composite* node_array = (Composite*)c;
    for (Component*& c1 : *(node_array->_children))
    {
      auto it = ndict->dictionary.find(c1->name);
      if (it != ndict->dictionary.end())
      {
        // checked by setkvp
        printDlgt({ "Error: [Dictionary.FuncAddArray] Dictionary [{0}] file [{1}] key [{2}] is already existed",dict_name, ppl_array, c1->name });
        return false;
      }
      ndict->dictionary[c1->name] = c1->value;
    }
    return true; 
  }
  //=======================================================
  bool Dictionary::FuncToArray(const vector<string>& parameters, string& result, Composite* node) 
  { 
    // name in named_dictionaries, dest_name_ppl_array
    // realloc PPL_array and copy to it all from named dictionary
    string func_name = "Dictionary.FuncToArray";

    if (parameters.size() != 2)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 3",func_name });
      return false;
    }
    string dict_name = trim(parameters[0], "\"");
    string ppl_array = trim(parameters[1], "\"");

    NamedDictionary* ndict = nullptr;
    if (GetNamedDictionaryByName(func_name, dict_name, ndict) == false)
      return false;
    //========================================================
    Composite* path = nullptr;
    string nodes = "";
    string name = "";
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, ppl_array, path, nodes, name);

    if (b == false)
      return false;

    Component* c = nullptr;
    for (size_t j = 0; j < path->_children->size(); j++)
    {
      c = (*(path->_children))[j];
      if (c->name == name)
        break;
    }

    if (c == nullptr)
    {
      printDlgt({ "Error: [{0}] wrong name of ppl_array [{1}]",func_name, ppl_array });
      return false;
    }
    Composite* node_array = (Composite*)c;
    vector<string> parameters_realloc = { ppl_array, "", to_string(ndict->dictionary.size()), "" };
    ppl->processing->FuncReAllocArray(parameters_realloc, result, node);
    Composite* comp = nullptr;
  
    int i = 0;
    for (auto& pair : ndict->dictionary)
    {
      (*(node_array->_children))[i]->name = pair.first;
      (*(node_array->_children))[i]->value = pair.second;
      i++;
    }
    return true; 
  }
}
