#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Erato.h"

using namespace std;
namespace PPLNS
{
  static Erato* ERATOInstance = nullptr;

  void Erato_CreateInstance(PPL* ppl)
  {
    ERATOInstance = new Erato(ppl);
    ERATOInstance->AddToKeywordDictionary();
  }

  Erato::Erato(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Erato::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Solve", FuncSolve);

    help_dict->insert({ "help", "\tErato.help([name])" });
    help_dict->insert({ "Solve", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Erato." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Erato", this });
  }
  //=========================================================
  bool Erato::FuncSolve(vector<string> parameters, string& result, Composite* node) { return true; }
}
