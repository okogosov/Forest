#ifndef NOTATION_TRANSFORMATIONS_H
#define NOTATION_TRANSFORMATIONS_H

#include <string>
#include <vector>
#include <stack>
#include <map>
#include <algorithm> // For std::remove_if
#include <cctype>    // For std::isspace

class NotationTransformations
{
public:
  // Checks if the number of opening and closing parentheses are equal.
  static bool checkParenthesesBalance(const std::string& expression);

  // Transforms a logical infix expression to prefix notation with parentheses.
  static std::string Logical_InfixToParentheses(const std::string& infixExpression);

  // Transforms a mathematical infix expression to prefix notation with parentheses.
  static std::string Math_InfixToParentheses(const std::string& infixExpression);

private:
  // Helper function to get precedence of mathematical operators
  static int getMathPrecedence(char op);
  // Helper function to get precedence of logical operators
  static int getLogicalPrecedence(const std::string& op);
  // Helper to check if a character is an operator
  static bool isMathOperator(char c);
  // Helper to check if a string is a logical or relational operator
  static bool isLogicalOrRelationalOperator(const std::string& s);
  // New generic helper for infix to prefix conversion with parentheses for every element
  static std::string infixToPrefixParenthesized(const std::string& infixExpression, bool isMath);
};

#endif // NOTATION_TRANSFORMATIONS_H