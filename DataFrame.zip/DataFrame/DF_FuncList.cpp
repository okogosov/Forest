#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  // df
  bool DataFrame::FuncList(vector<string> parameters, string& result, Composite* node)
  {
    const string func_name = "DataFrame.FuncList";
    string err;
    string df_name;
    try
    {
      /*if (parameters.size() != 1)
      {
        err = "[" + func_name + "] wrong format: DataFrame.List()";
        printDlgt({ "Error: {0}",err });
        return false;
      }*/
     
      //vector<string> column_names = *ptr_column_names;
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      TableName* ptr_table_name = nullptr;

      for (auto& tn : table_names)
      {
        df_name = tn.name; 
        comp_df = tn.comp_df;
        comp_settings = tn.comp_settings;
        ptr_column_names = &(tn.column_names);
        ptr_table_name = &tn;
        printDlgt({ "====={0}=====", tn.name });
        printDlgt({ "  Settings" });
        for (auto*& comp : *(tn.comp_settings->_children) )
        {
          printDlgt({ "\t{0} = {1}",comp->name, comp->value});
        }

        if (tn.cell_addresses.size() != 0)
        {
          printDlgt({ "  defined names in DataFrame [{0}]",tn.name });
          printDlgt({ "\t{0,-15}  {1,-8}  {2}", "name", "column", "row" });
          for (const auto& pair : tn.cell_addresses)
          {
            string cell_name = pair.first;
            string column = pair.second.column;
            string row = to_string(pair.second.row);
            printDlgt({ "\t{0,-15} {1,-8} {2}", cell_name,column,  row });
          }
        }
      }
      return true;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
  }
}