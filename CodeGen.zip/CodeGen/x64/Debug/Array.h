#ifndef ARRAY_H
#define ARRAY_H

#ifdef ARRAY_EXPORTS
#define ARRAY_API __declspec(dllexport)
#else
#define ARRAY_API __declspec(dllimport)
#endif

namespace PPLNS
{
  class ARRAY_API Array : public BaseClass
  {
  public:
    Array(PPL* ppl);
    void AddToKeywordDictionary();
    bool FuncMax(vector<string> parameters, string& result, Composite* node);
    bool FuncMin(vector<string> parameters, string& result, Composite* node);
    bool FuncSum(vector<string> parameters, string& result, Composite* node);
    bool FuncAverage(vector<string> parameters, string& result, Composite* node);
    bool FuncSum2(vector<string> parameters, string& result, Composite* node);
    bool FuncSub2(vector<string> parameters, string& result, Composite* node);
    bool FuncMult2(vector<string> parameters, string& result, Composite* node);
    bool FuncDiv2(vector<string> parameters, string& result, Composite* node);
    bool FuncSort(vector<string> parameters, string& result, Composite* node);
    bool FuncReverse(vector<string> parameters, string& result, Composite* node);
  };
  extern "C" void ARRAY_API Array_CreateInstance(PPL* ppl);
}
#endif
