#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  template <typename T>
  struct ValueIndex
  {
  public:
    ValueIndex(T value, int index)
    {
      this->value = value;
      this->i = index;
    }

    T value;
    int i;
  };
  //============================================================
  //string 
  bool DataFrame::FuncSort(vector<string> parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncSort";

    try
    {
      if (parameters.size() != 3)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.Sort (DataFrame_name)(ascend|descend)(column)", func_name});
        return false;
      }

      string df_name = parameters[0];
      string order = parameters[1];
      string column_name = parameters[2];

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      Component* compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
      if (order != "ascend" && order != "descend")
      {
        order = "ascend";
        printDlgt({"Warning: [{0}] [{1}] accepted ascend order", func_name,df_name });
      }

      if (compRowsLength == nullptr)
      {
        printDlgt({"Error: [{0}] RowsLength is omitted in [{1}].Settings", func_name,df_name});
        return false;
      }

      int Length;
      TryParse(compRowsLength->value,Length);
      string type = GetSettingsValue(comp_settings, column_name + "Type");
      Composite* sorted_column = nullptr;

      for (size_t i = 1; i < comp_df->_children->size(); i++)
      {
        if ( (*(comp_df->_children))[i]->name == column_name)
        {
          sorted_column = static_cast<Composite*>( (*(comp_df->_children))[i]);
          break;
        }
      }

      if (sorted_column == nullptr)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] wrong name [{2}]", func_name,df_name,column_name});
        return false;
      }

      int columns_quantity = comp_df->_children->size();

      if (type == "Text")
      {
        vector<ValueIndex<string>> value_indexes;

        for (size_t i = 0; i < sorted_column->_children->size(); i++)
          value_indexes.emplace_back( (*(sorted_column->_children))[i]->value, i);

        if (order == "ascend")
        {
          sort(value_indexes.begin(), value_indexes.end(), [](const ValueIndex<string>& a, const ValueIndex<string>& b) {
            return a.value < b.value;
            });
        }
        else
        {
          sort(value_indexes.begin(), value_indexes.end(), [](const ValueIndex<string>& a, const ValueIndex<string>& b) {
            return a.value > b.value;
            });
        }

        for (size_t i = 1; i < columns_quantity; i++)
        {
          Component* c = (*(comp_df->_children))[i];
          if ( c->name == column_name)
          {
            for (int j = 0; j < Length; j++)
            {
              (*(static_cast<Composite*>(c)->_children))[j]->value = value_indexes[j].value;
            }
            continue;
          }

          vector<string> tmp_array(Length);
          for (int j = 0; j < Length; j++)
          {
            tmp_array[j] = (*(static_cast<Composite*>(c)->_children))[j]->value;
          }

          for (int j = 0; j < Length; j++)
          {
            int index = value_indexes[j].i;
            (*(static_cast<Composite*>(c)->_children))[j]->value = tmp_array[index];
          }
        }
      }
      if (type == "Number")
      {
        vector<ValueIndex<double>> value_indexes;

        for (size_t i = 0; i < sorted_column->_children->size(); i++)
        {
          double d = 0;
          string tmp = (*(sorted_column->_children))[i]->value;
          if (!TryParse(tmp, d))
          {
            printDlgt({ "Warning: [{0}] [{1}] not digital [{2}]",func_name, df_name, tmp });
          }

          value_indexes.emplace_back(d, i);
        }

        if (order == "ascend")
        {
          sort(value_indexes.begin(), value_indexes.end(), [](const ValueIndex<double>& a, const ValueIndex<double>& b) {
            return a.value < b.value;
            });
        }
        else
        {
          sort(value_indexes.begin(), value_indexes.end(), [](const ValueIndex<double>& a, const ValueIndex<double>& b) {
            return a.value > b.value;
            });
        }

        for (size_t i = 1; i < columns_quantity; i++)
        {
          Component* c = (*(comp_df->_children))[i];
          if(c->name == column_name)  
          {
            for (int j = 0; j < Length; j++)
            {
              Composite* ccomp = (Composite*)c;
              Component* c1 = (*(ccomp->_children))[j];
              c1->value = to_string(value_indexes[j].value);
              EraseTrailingZeros(c1->value);           
            }
            continue;
          }

          vector<string> tmp_array(Length);
          for (int j = 0; j < Length; j++)
          {
             tmp_array[j] = (*(static_cast<Composite*>(c)->_children))[j]->value;
          }
          //=====return=====      
          for (int j = 0; j < Length; j++)
          {
            //int index = value_indexes[j].i;
            //Component* c = (*(comp_df->_children))[i];
            //Composite* ccomp = (Composite*)c;
            ////static_cast<Composite*>(comp_df->_children[i])->_children[j]->value = tmp_array[index];
            //(*(ccomp->_children))[j]->value = tmp_array[index];
            int index = value_indexes[j].i;
            (*(static_cast<Composite*>(c)->_children))[j]->value = tmp_array[index];
          }
        }
      }

    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true;
  }
  //============================================================
  /*bool DataFrame::FuncReverse(vector<string> parameters, string& result, Composite* node = nullptr)
  {
  string func_name = "DataFrame.FuncReverse";

  try
  {
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.FuncReverse (DataFrame_name)",func_name });
      return false;
    }

    string df_name = parameters[0];
    string column_name;

    //====================================================
    Composite* comp_df = nullptr;
    Composite* comp_settings = nullptr;
    for (auto& tn : table_names)
    {
      if (tn.name == df_name)
      {
        comp_df = tn.comp_df;
        comp_settings = tn.comp_settings;
        break;
      }
    }
    if (comp_df == nullptr)
    {
      printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
      return false;
    }

    Component* compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
    if (compRowsLength == nullptr)
    {
      printDlgt({ "Error: [{0}] RowsLength is omitted in [{1}].Settings", func_name, df_name });
      return false;
    }

    int Length;
    TryParse(compRowsLength->value, Length);
    string type = GetSettingsValue(comp_settings, column_name + "Type");
    int columns_quantity = comp_df->_children->size();
    if (columns_quantity == 0)
    {
      printDlgt({ "Warning: [{0}] [{1}] columns_quantity = 0", func_name, df_name });
      return false;
    }
    Composite* first_column = (Composite*)((*(comp_df->_children))[1]);
    
    vector<ValueIndex<string>> value_indexes;

    for (size_t i = 0; i < Length; i++)
      value_indexes.emplace_back((*(first_column->_children))[i]->value, i);

    reverse(value_indexes.begin(), value_indexes.end());

    for (size_t i = 1; i < columns_quantity; i++)
    {
      if ((*(comp_df->_children))[i]->name == column_name)
      {
        for (int j = 0; j < Length; j++)
        {
          Composite* c = (Composite*)((*(comp_df->_children))[i]);
          (*(c->_children))[j]->value = value_indexes[j].value;
        }
        continue;
      }

      vector<string> tmp_array(Length);
      for (int j = 0; j < Length; j++)
      {
        Composite* c = (Composite*)((*(comp_df->_children))[i]);
        tmp_array[j] = (*(c->_children))[j]->value;
      }

      for (int j = 0; j < Length; j++)
      {
        int index = value_indexes[j].i;
        Composite* c = (Composite*)((*(comp_df->_children))[i]);
        (*(c->_children))[j]->value = tmp_array[index];
      }
    }
  }
  catch (const exception& ex)
  {
    printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
    return false;
  }

  return true;
  }
  */

  bool DataFrame::FuncReverse(vector<string> parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncReverse";
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.FuncReverse (DataFrame_name)",func_name });
        return false;
      }

      string df_name = parameters[0];
      string column_name;

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      /*
      Component* compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
      if (compRowsLength == nullptr)
      {
        printDlgt({ "Error: [{0}] RowsLength is omitted in [{1}].Settings", func_name, df_name });
        return false;
      }
      int Length;
      TryParse(compRowsLength->value, Length);
      string type = GetSettingsValue(comp_settings, column_name + "Type");
      */
      int columns_quantity = comp_df->_children->size();
      if (columns_quantity == 0)
      {
        printDlgt({ "Warning: [{0}] [{1}] columns_quantity = 0", func_name, df_name });
        return false;
      }
      for (size_t i = 1; i < columns_quantity; i++)
      {
        Composite* c = (Composite*)((*(comp_df->_children))[i]);
        reverse( (c->_children)->begin(), (c->_children)->end());
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true;
  }

}