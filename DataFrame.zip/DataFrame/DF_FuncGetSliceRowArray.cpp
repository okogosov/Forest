#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{ 
  //  df,index column,row_from,[row_to],"array"
  bool DataFrame::FuncGetSliceRowArray(vector<string> parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetSliceRowArray";

    if ((parameters.size() != 4) && (parameters.size() != 5))
    {
      printDlgt({"Error: [{0}] wrong format: DataFrame.GetSliceRowArray(DataFrame_name)(column)(row_from)[(row_to)](array)", func_name });
      return false;
    }

    string df_name = parameters[0];
    try
    {
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] not digital RowsLength [{2}]", func_name,df_name,  str_RowsLength });
        return false;
      }
      
      string column = trim(parameters[1],"\"");
      vector<string> column_names = *ptr_column_names;
      int index = VectorIndexOf(column_names, column);
      if (index == -1)
      {
         printDlgt({ "Error: [{0}] DataFrame [{1}] wrong column [{2}]", func_name,df_name, column});
         return false;
      }

      string str_row_from = parameters[2];
      int row_from = 0;
      b = TryParse(str_row_from, row_from);
      if (!b)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] row_from not digital [{2}]", func_name,df_name, str_row_from });
        return false;
      }
      if ((row_from < 0) || (row_from >= RowsLength))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] row_from [{2}] out of bounds", func_name,df_name, to_string(row_from) });
        return false;
      }

      int row_to = 0;
      string array_result_name;
      if (parameters.size() == 4)
      {
        row_to = RowsLength;
        array_result_name = parameters[3];
      }
      else
      {
        string str_row_to = parameters[3];
        b = TryParse(str_row_to, row_to);
        if (!b)
        {
          printDlgt({"Error: [{0}] DataFrame [{1}] row_to not digital [{2}])",  func_name, df_name, str_row_to });
          return false;
        }
        row_to++;
        array_result_name = parameters[4];
      }

      Composite* array_result = static_cast<Composite*>(ppl->processing->GetComponentFromDataNames(array_result_name));
      if (array_result == nullptr)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] wrong array name [{2}]",func_name,df_name, array_result_name });
        return false;
      }

      Composite* comp_column = nullptr;
      //for (int i = 0; i < comp_df->_children->size(); i++)
      for (auto* c : *(comp_df->_children))
      {
        if (c->name == column)
        {
          comp_column = (Composite*)c;
          break;
        }
      }
      //==================================
      for (int i = row_from; i < row_to; i++)
      {
        Component* c = (*(comp_column->_children))[i];
        array_result->Add(new Leaf("#", c->value));
      }
      array_result->value = "Array " + to_string(row_to - row_from);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
}