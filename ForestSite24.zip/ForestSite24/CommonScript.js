        function toggleSubmenu(menuId) {
          
          const rightPanel = document.getElementById('right-panel');
          rightPanel.innerHTML = 
          `<div id="right-panel"> <p style="text-align: center;font-size: 20px">Please select an item from the menu on the left</p> </div>`;

            const submenu = document.getElementById(menuId);
            submenu.style.display = submenu.style.display === "block" ? "none" : "block";
        }

        function toggleSubmenuLibraries(menuId) {
          
          const rightPanel = document.getElementById('right-panel');
          rightPanel.innerHTML = 
          `<div id="right-panel"> <p style="text-align: center;font-size: 20px">Formats and samples are described in detail in Tutorial Forest.pdf
</p> </div>`;

            const submenu = document.getElementById(menuId);
            submenu.style.display = submenu.style.display === "block" ? "none" : "block";
        }




      function LoadContent(commandFile) {
        const rightPanel = document.getElementById('right-panel');
        rightPanel.innerHTML = `<iframe id="contentFrame" src="${commandFile}" width="100%" height="100%" style="border:none;"></iframe>`;

        const iframe = document.getElementById("contentFrame");
        iframe.onload = function () {
          try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            if (iframeDoc) {
              const style = iframeDoc.createElement('style');
              style.textContent = `
                    pre {
                        font-family: Arial, sans-serif;
                        font-size: 24px;
                        color: #333;
                        white-space: pre-wrap; 
                        word-wrap: break-word; 
                        overflow-wrap:break-word;
                    }
                `;
              iframeDoc.head.appendChild(style);
            }
          } catch (error) {
            console.error("Error applying styles to iframe content:", error);
          }
        };
      }
