bool FuncDisplayNodes(List<string> parameters, ref string result, Composite node = null)
    {
      if (node.parent != null)
      {
        if ((node.parent.name == "var") ||
            (node.parent.name == "const") ||
            (node.parent.name == "array") ||
            (node.parent.name == "storage") ||
            (node.parent.name == "swrite") ||
            (node.parent.name == "createnode"))

        {
          ppl.print("Error: [FuncDisplay] name is keyword [{0}]", new object[] { node.parent.name + "(dn)" });
          return false;
        }
      }
      Composite display_node = ppl.NameSpaces;

     
      if (parameters.Count == 0)
      {
        display_node.Display(ppl.print, 1, true);
        return true;
      }

      switch (parameters[0])
      {
        case "":
          display_node.Display(ppl.print, 1, true);
          return true;
        case "root":
          ppl.print("-----root-----");
          foreach (Composite cc in ppl.root.GetChildren())
          {
            if (cc != null)
              cc.Display(ppl.print, 1, true);
          }
          return true;
        case "Functions":
          ppl.print("-----Functions-----");
          foreach (Composite cc in ppl.Functions.GetChildren())
          {
            if (cc != null)
              cc.Display(ppl.print, 1, true);
          }
          return true;
        case "Configuration":
          ppl.print("-----Configuration-----");
          foreach (Component c in ppl.Configuration.GetChildren())
          {
            if (c != null)
              c.Display(ppl.print, 1, true);
          }
          return true;
        case "Global":
          ppl.print("-----Global-----");
          ppl.Global.Display(ppl.print, 1, true);

          return true;
        case "Local":
          ppl.print("-----Local-----");
          ppl.Local.Display(ppl.print, 1, true);
          return true;
        default:
          string[] tokens = parameters[0].Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);
          string name = "";
          if (parameters[0].Contains("Functions"))
          {
            name = tokens.Last();
            Component c = ppl.Functions.GetChildren().Find(item => item.name == name);
            if (c == null)
            {
              ppl.print("Error: [FuncDisplayNodes] node {0} does not exist", new object[] { name });
              return false;
            }
            if (c is Composite cc)
            {
              cc.Display(ppl.print, 1, true);
              return true;
            }
            else
            {
              ppl.print("Error: [FuncDisplayNodes] name {0} is Leaf", new object[] { name });
              return false;
            }
          }
          else
          {
            // display node contents
            Composite path = null;
            string fullname = "";
            string nodes = "";
            fullname = parameters[0];
            string s = "Global.";
            if (parameters[0].Contains(s))
              fullname = parameters[0].Substring(s.Length);

            s = "Local.";
            if (parameters[0].Contains(s))
              fullname = parameters[0].Substring(s.Length);

            bool b = ppl.processing.GetPathAndNameFromGlobalLocal("FuncDisplayNodes",
                 fullname, ref path, ref nodes, ref name);
            if (b == false)
            {
              ppl.print("Error: [FuncDisplayNodes] node {0} does not exist", new object[] { fullname });
              return false;
            }
            Component c = null;
            b = false;
            for (int m = 0; m < path.GetChildren().Count; m++)
            {
              c = path.GetChildren()[m];
              if (c.name == name)
              {
                b = true;
                break;
              }
            }
            if (b)
            {
              ppl.print("-----Variables  and arrays-----");
              c.Display(ppl.print, 1, true);
            }
            else
            {
              ppl.print("Error: [FuncDisplayNodes] wrong name {0}", new object[] { name });
              return false;
            }
          }
          break;
      }
      return true;
    }