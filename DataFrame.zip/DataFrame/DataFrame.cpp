#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  static DataFrame* DATAFRAMEInstance = nullptr;

  void DataFrame_CreateInstance(PPL* ppl)
  {
    DATAFRAMEInstance = new DataFrame(ppl);
    DATAFRAMEInstance->AddToKeywordDictionary();
  }

  DataFrame::DataFrame(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void DataFrame::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Init",    FuncInit);
    AddKeyword("Create", FuncCreate);
    AddKeyword("List",      FuncList);
    AddKeyword("SetRow",    FuncSetRow);
    AddKeyword("SetColumn", FuncSetColumn);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Save", FuncSave);
    AddKeyword("ReadFile", FuncReadFile);
    AddKeyword("InsertRows", FuncInsertRows);
    AddKeyword("AddRows", FuncAddRows);
    AddKeyword("RemoveRows", FuncRemoveRows);
    AddKeyword("InsertColumns", FuncInsertColumns);
    AddKeyword("AddColumns", FuncAddColumns);
    AddKeyword("RemoveColumns", FuncRemoveColumns);
    AddKeyword("ClearColumns", FuncClearColumns);
    AddKeyword("SetWidthForAll", FuncSetWidthForAll);
    AddKeyword("SetTypeForAll", FuncSetTypeForAll);
    AddKeyword("Sort", FuncSort);
    AddKeyword("Reverse", FuncReverse);
    AddKeyword("SelectRows", FuncSelectRows);
    AddKeyword("UnSelectRows", FuncUnSelectRows);
    AddKeyword("GetRowsLength", FuncGetRowsLength);
    AddKeyword("GetColumnsLength", FuncGetColumnsLength);
    AddKeyword("GetColumnNames", FuncGetColumnNames);
    AddKeyword("AddRowData", FuncAddRowData);
    AddKeyword("GetRowArray", FuncGetRowArray);
    AddKeyword("GetSliceRowArray", FuncGetSliceRowArray);
    AddKeyword("GetColumnArray", FuncGetColumnArray);
    AddKeyword("GetSliceColumnArray", FuncGetSliceColumnArray);
    AddKeyword("SetCell", FuncSetCell);
    AddKeyword("GetCell", FuncGetCell);
    AddKeyword("CellName", FuncCellName);
    AddKeyword("SetWidth", FuncSetWidth);
    AddKeyword("SetType", FuncSetType);
    AddKeyword("GetWidth", FuncGetWidth);
    AddKeyword("GetType", FuncGetType);
    AddKeyword("SetPrintEmptyRows", FuncSetPrintEmptyRows);
    AddKeyword("GetPrintEmptyRows", FuncGetPrintEmptyRows);
    AddKeyword("SetRowSelectedFrom", FuncSetRowSelectedFrom);
    AddKeyword("GetRowSelectedFrom", FuncGetRowSelectedFrom);
    AddKeyword("SetRowSelectedTo", FuncSetRowSelectedTo);
    AddKeyword("GetRowSelectedTo", FuncGetRowSelectedTo);
    AddKeyword("SetReallocIncrement", FuncSetReallocIncrement);
    AddKeyword("GetReallocIncrement", FuncGetReallocIncrement);

    help_dict->insert({ "help", "\tDataFrame.help([name])" });
    help_dict->insert({ "Init", "\tto add this call in first .scr file only: DataFrame.Init()" });
    help_dict->insert({ "Create", "\tDataFrame.Create([df_name])[(number rows)(column1)(column2)(column3)�]" });
    help_dict->insert({ "List", "\tDataFrame.List()" });
    help_dict->insert({ "SetRow", "\tDataFrame.SetRow(df_name)(row index)(\"ppl_array\")" });
    help_dict->insert({ "SetColumn", "\tDataFrame.SetColumn(df_name)(column) (\"ppl_array\")" });
    help_dict->insert({ "Write", "\tDataFrame.Write([df_name])[(column)(column)�]" });
    help_dict->insert({ "Save", "\tDataFrame.Save(df_name)(filename.csv|.data)[(column)( column)]�" });
    help_dict->insert({ "ReadFile", "\tDataFrame.ReadFile(df_name) (filename.csv)[(column)( column)]�\r\n\tDataFrame.ReadFile(filename.data)" });
    help_dict->insert({ "InsertRows", "\tDataFrame.InsertRows(df_name)(index)[(number of rows)]" });
    help_dict->insert({ "AddRows", "\tDataFrame.AddRows([df_name])[(number of rows)]" });
    help_dict->insert({ "RemoveRows", "\tDataFrame.RemoveRows(df_name)(number_from)(number_to)" });
    help_dict->insert({ "InsertColumns", "\tDataFrame.InsertColumns(df_name) )(specified column)(column)(column)�" });
    help_dict->insert({ "AddColumns", "\tDataFrame.AddColumns(df_name)(column1)(column2)�" });
    help_dict->insert({ "RemoveColumns", "\tDataFrame.RemoveRows(df_name)(column1)(column2)" });
    help_dict->insert({ "ClearColumns", "\tDataFrame.ClearColumns(df_name)[(column1)(column2)�]" });
    help_dict->insert({ "SetWidthForAll", "\tDataFrame.SetWidthForAll([df_name])[(width)]" });
    help_dict->insert({ "SetTypeForAll", "\tDataFrame.SetWidthForAll([df_name])[(Text | Number)]" });
    help_dict->insert({ "Sort", "\tDataFrame.Sort(df_name)(ascend | descend)(column)" });
    help_dict->insert({ "Reverse", "\tDataFrame.Reverse(df_name)" });
    help_dict->insert({ "SelectRows", "\tDataFrame.SelectRows(df_name)(select_from)[(*|select_to)]" });
    help_dict->insert({ "UnSelectRows", "\tDataFrame.UnSelectRows(df_name)" });
    help_dict->insert({ "GetRowsLength", "\tDataFrame.GetRowsLength(df_name)" });
    help_dict->insert({ "GetColumnsLength", "\tDataFrame.GetColumnLength(df_name)" });
    help_dict->insert({ "GetColumnNames", "\tDataFrame.GetColumnNames(df_name)" });
    help_dict->insert({ "AddRowData", "\tDataFrame.AddRowData(df_name)(\"ppl_array\")" });
    help_dict->insert({ "GetRowArray", "\tDataFrame.GetRowArray(df_name)(index row)(\"ppl array name\")" });
    help_dict->insert({ "GetSliceRowArray", "\tDataFrame.GetSliceRowArray(df_name)(column)(row_from)[(row_to)](\"ppl array name\")" });
    help_dict->insert({ "GetColumnArray", "\tDataFrame.GetColumnArray(df_name)(column)(\"ppl array name\")" });
    help_dict->insert({ "GetSliceColumnArray", "\tDataFrame.GetSliceColumnArray(df_name)(row)(column_from)[(column_to)](\"ppl array name\")" });
    help_dict->insert({ "SetCell", "\tDataFrame.SetCell(df_name)(column)(row index)(value) | (df_name.cell_name)(value)"});
    help_dict->insert({ "GetCell", "\tDataFrame.GetCell(df_name)(column)(row index)(value) | (df_name.cell_name)" });
    help_dict->insert({ "CellName", "\tDataFrame.CellName(df_name)(column)(row index)(cell name)" });
    help_dict->insert({ "SetWidth", "\tDataFrame.SetWidth(df_name)(column_name)(value)" });
    help_dict->insert({ "SetType", "\tDataFrame.SetType(df_name)(column_name)(Text | Number)" });
    help_dict->insert({ "GetWidth", "\tDataFrame.GetWidth(df_name)(column_name)" });
    help_dict->insert({ "GetType", "\tDataFrame.GetType(df_name)(column_name)" });
    help_dict->insert({ "SetPrintEmptyRows", "\tDataFrame.SetPrintEmptyRows(df_name)(yes | no)" });
    help_dict->insert({ "GetPrintEmptyRows", "\tDataFrame.GetPrintEmptyRows(df_name)" });
    help_dict->insert({ "SetRowSelectedFrom", "\tDataFrame.SetRowSelectedFrom(df_name)(index_row_from)" });
    help_dict->insert({ "GetRowSelectedFrom", "\tDataFrame.SetRowSelectedTo(df_name)(index_row_to)" });
    help_dict->insert({ "SetRowSelectedTo", "\tDataFrame.SetRowSelectedTo(df_name)(index_row_to)" });
    help_dict->insert({ "GetRowSelectedTo", "\tDataFrame.GetRowSelectedTo(df_name)" });
    help_dict->insert({ "SetReallocIncrement", "\tDataFrame.SetReallocIncrement(df_name)(value)" });
    help_dict->insert({ "GetReallocIncrement", "\tDataFrame.SetReallocIncrement(df_name)" });
    for (const auto pair : *keyword_dict)
    {
      string key = "DataFrame." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "DataFrame", this });
  }
  //=========================================================  
  string DataFrame::GetSettingsValue( Composite* comp_settings, const string name)
  {
    for (auto* c : *(comp_settings->_children))
    {
      if (c->name == name)
        return c->value;
    }
    return ""; // Return empty string if not found
  }
  //==========================================================
  // Function to get a component by name
  Component* DataFrame::GetComponentSettingsByName(Composite* comp_settings, const string name)
  {
    for (auto* c : *(comp_settings->_children))
    {
      if (c->name == name)
        return const_cast<Component*>(c); 
    }
    return nullptr; // Return nullptr if not found
  }
  //=========================================================
  Composite* DataFrame::GetDataFrameComposite(const string& df_name)
  {
    string name = "", nodes = "";
    Composite* path = nullptr;
    Composite* comp_df = nullptr;
    string func_name = "DataFrame.GetDataFrameComposite";

    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, df_name, path, nodes, name);
    if (!b)
      return nullptr;

    for (size_t j = 0; j < path->_children->size(); j++)
    {
      Component* comp = (*(path->_children))[j];
      if (comp->name == df_name)
      {
        comp_df = (Composite*)comp;
        break;
      }
    }

    return comp_df; // Returns nullptr if not found
  }

  //==========================================================
  Composite* DataFrame::GetSettingsComposite(Composite* comp_df)
  {
    Composite* comp_settings = nullptr;
    for (auto c : *(comp_df->_children))
    {
      if (c->name == "Settings")
      {
        comp_settings = (Composite*)c;
        return comp_settings;
      }
    }
    return nullptr; // Return nullptr if not found
  }
  //=========================================================
  Composite* DataFrame::GetArrayComposite(const string& fullname)
  {
    string func_name = "GetArrayComposite";
    string name = "";
    string nodes = "";
    Composite* path = nullptr; 
    string tmp;
    bool b = ppl->processing->GetPathAndNameFromGlobalLocal(func_name, fullname, path, nodes, name);
    if (!b)
    {
      tmp = "[" + func_name + "] wrong name [" + fullname + "]";
      printDlgt({"Error: {0}", tmp});
      return nullptr;
    }

    Component* c = nullptr;
    for (size_t m = 0; m < path->_children->size(); m++)
    {
      if (dynamic_cast<Leaf*>((*(path->_children))[m])) 
        continue;

      if ( (*(path->_children))[m]->name == name)
      {
        c = (*(path->_children))[m];
        break;
      }
    }

    if (c == nullptr)
    {
      tmp = "[" + func_name + "] wrong name [" + name + "]";
      printDlgt({ "Error: {0}", tmp });
      return nullptr;
    }
    return dynamic_cast<Composite*>(c); // Cast to Composite
  }
  //=========================================================
  int DataFrame::GetColumnIndex(Composite* comp_df, string name)
  {
    for(int i = 0;i < comp_df->_children->size();i++)
    {
      if ( (*(comp_df->_children))[i]->name == name)
        return i;
    }
    return -1;
  }
  //=========================================================
  Component* DataFrame::GetCellComponent(Composite* comp, int x, int y)
  {
    Composite* comp2 = (Composite*)(*(comp->_children))[x];
    return (*(comp2->_children))[y];
  }
  //=========================================================
  bool DataFrame::FuncInit(const vector<string>& parametersInput, string& result, Composite* node)
  {
    table_names.clear();
    return true;
  }
  //=========================================================
  /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame"></param>
    /// <param name="length"></param>
    /// <param name="column name1"></param>
    /// <param name="column name2"></param>
    /// <param name="column name3"></param>
    /// ...
    /// <returns></returns>
    /// DataFrame.Create() => Create(DF)(1000)(A)(B)(C)...(BA)(BB)...(ZZ)  26x26 columns x1000 rows    
    /// DataFrame.Create(Name) => Create(Name)(10)(A)(B)(C)...(BA)(BB)...(ZZ)  26x26 columns x10 rows  
    /// DataFrame.Create(Name)(rows length) => Create(Name)(rows length)(A)(B)(C)...  26 columns x rows_length 
    /// DataFrame.Create(Name)(rows length)(column_name1)(column_name2)(column_name2)...
  bool DataFrame::FuncCreate(const vector<string>& parametersInput, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncCreate";
    string df_name = "";
    try
    {
      bool abc = false;
      vector<string> parameters;
      //DataFrame.Create() 
      if (parametersInput.empty())
      {
        df_name = "DF";
        parameters.push_back(df_name);
        parameters.push_back("1000");
        int unicode = 65; // 'A'
        abc = true;

        for (int j = 0; j < 26; j++)
        {
          char character2 = static_cast<char>(unicode + j);
          for (int i = 0; i < 26; i++)
          {
            char character = static_cast<char>(unicode + i);
            string column_name = string(1, character);
            if (j > 0)
              column_name = string(1, character2) + column_name;
            parameters.push_back(column_name);
          }
        }
      }

      //DataFrame.Create(Name)
      if (parametersInput.size() == 1)
      {
        df_name = parametersInput[0];
        parameters.push_back(df_name);
        parameters.push_back("10");
        int unicode = 65; // 'A'
        abc = true;

        for (int j = 0; j < 26; j++)
        {
          char character2 = static_cast<char>(unicode + j);
          for (int i = 0; i < 26; i++)
          {
            char character = static_cast<char>(unicode + i);
            string column_name = string(1, character);
            if (j > 0)
              column_name = string(1, character2) + column_name;
            parameters.push_back(column_name);
          }
        }
      }

      //DataFrame.Create(Name)(rows length)
      if (parametersInput.size() == 2)
      {
        df_name = parametersInput[0];
        parameters.push_back(df_name);
        parameters.push_back(parametersInput[1]);
        int unicode = 65; // 'A'
        abc = true;

        for (int i = 0; i < 26; i++)
        {
          char character = static_cast<char>(unicode + i);
          string column_name = string(1, character);
          parameters.push_back(column_name);
        }
      }

      // DataFrame.Create(Name)(rows length)
      //// ("ppl_arr_column_names")(column_name1)(column_name2)(column_name2)...
      if (parametersInput.size() > 2)
      {
        df_name = parametersInput[0];
        for (auto* c : *(node->_children))
          parameters.push_back(c->name);
        if (node->_children->size() == 1)
          parameters.push_back("0");
        if (parameters[1].empty()) // Create(name)() = Create(name)(0)
          parameters[1] = "0";
      }

      string tmp_result = "";
      string name = "";
      int Length = 0;
      string strLength = parameters[1];
      bool b = (strLength.find_first_not_of("0123456789") == string::npos);
      if (!b)
      {
        string tmp = "Error: [" + func_name + "] wrong rows length [" + strLength + "]";
        printDlgt({ "{0}",tmp });
        return false;
      }

      if (GetDataFrameComposite(df_name))
      {
        vector<string> vec_delete = {df_name};
        ppl->processing->FuncDelete(vec_delete,tmp_result,node);
        for (size_t i = 0; i < table_names.size(); i++)
        {
          if (table_names[i].name == df_name)
          {
            table_names.erase(table_names.begin() + i);
            break;
          }
        }
      }
      string settings = df_name + "." + "Settings";
      ppl->processing->FuncCreateNode(vector<string>{df_name, "DataFrame"}, tmp_result, node);
      ppl->processing->FuncCreateNode(vector<string>{settings, ""}, tmp_result, node);

      ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + "RowSelectedFrom", ""}, tmp_result, node);
      ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + "RowSelectedTo", ""}, tmp_result, node);
      ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + "PrintEmptyRows", "yes"}, tmp_result, node); // yes|no
      ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + "RowsLength", strLength}, tmp_result, node);
      ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + "ReallocIncrement", "10"}, tmp_result, node);

      for (size_t i = 2; i < parameters.size(); i++)
      {
        tmp_result = "";
        name = df_name + ".##" + parameters[i];
        ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + parameters[i] + "Type", "Text"}, tmp_result, node);
        if (abc)
          ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + parameters[i] + "Width", "4"}, tmp_result, node);
        else
          ppl->processing->FuncCreateVariables(vector<string>{settings + ".##" + parameters[i] + "Width", "12"}, tmp_result, node);
        ppl->processing->FuncCreateArray(vector<string>{name, strLength}, tmp_result, node);
      }

      TableName tn;
      tn.name = df_name;
      tn.comp_df = GetDataFrameComposite(df_name);
      tn.comp_settings = GetSettingsComposite(tn.comp_df);
      for(auto*& c : *(tn.comp_df->_children))
      {
        if (c->name == "Settings")
          continue;
        tn.column_names.push_back(c->name);
      } 
      table_names.push_back(tn);
    }

    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name, ex.what()});
      return false;
    }
    return true; 
  }
  //=========================================================
  // All commentaried functions are moved to separated files
  //bool DataFrame::FuncList(const vector<string>& inp_parameters, string& result, Composite* node) {  return true; }
  //bool DataFrame::FuncSetRow(const vector<string>& parameters, string& result, Composite* node)  {  return true;  }
  //bool DataFrame::FuncSetColumn(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncWrite(const vector<string>& parameters, string& result, Composite* node)   { return true; }
  //bool DataFrame::FuncSave(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncReadFile(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncInsertRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncAddRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncRemoveRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  // bool DataFrame::FuncInsertColumns(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncAddColumns(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncRemoveColumns(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncClearColumns(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //===============================================================================================
  bool DataFrame::FuncSetWidthForAll(const vector<string>& parametersInput, string& result, Composite* node) 
  { 
    string func_name = "DataFrame.FuncSetWidthForAll";
    try
    {
      if (parametersInput.size() > 2)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.SetWidthForAll [(DataFrame_name)](value)",func_name});
        return false;
      }
      vector<string> parameters;
      string df_name;
      string strWidth;
      if (parametersInput.size() == 1)
      {
        parameters.push_back("DF");
        parameters.push_back(parametersInput[0]);
      }
      else
      {
        parameters.push_back(parametersInput[0]);
        parameters.push_back(parametersInput[1]);
      }
      
      df_name = parameters[0];
      strWidth = parameters[1];
      int width = 0;

      if(!TryParse(strWidth,width))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] width not a valid number [{2}]",func_name,df_name,strWidth });
        return false;
      }

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      // Set width for all columns
      for(auto*& settings_param : *(comp_settings->_children))
      {
        if (settings_param->name.find("Width") != string::npos)
          settings_param->value = to_string(width);
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true;
  }
  //===========================================================================================
  // [df_name])[(Text | Number)]
  bool DataFrame::FuncSetTypeForAll(const vector<string>& parametersInput, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncSetTypeForAll";
    string df_name = "";
    vector<string> parameters = parametersInput;
    try
    {
      if (parameters.size() > 2)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.SetTypeForAll [(DataFrame_name)] [(Text | Number)]", func_name});
        return false;
      }

      if (parameters.empty())
      {
        parameters.push_back("DF");
        parameters.push_back("Text");
      }

      if (parameters.size() == 1)
      {
        parameters.push_back("Text");
      }

      df_name = parameters[0];
      string strType = parameters[1];

      if ((strType != "Text") && (strType != "Number"))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] wrong Type, format: DataFrame.SetTypeForAll [(DataFrame_name)][(Text | Number)]", 
          func_name,df_name});
        return false;
      }

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      for(auto*& settings_param : *(comp_settings->_children))
      {
        if (settings_param->name.find("Type") != string::npos)
          settings_param->value = strType;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",func_name,ex.what() });
      return false;
    }
    return true; 
  }
  //===========================================================================================
  //bool DataFrame::FuncSort(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncReverse(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSelectRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncUnSelectRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetRowsLength(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetColumnsLength(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetColumnNames(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncAddRowData(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetRowArray(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetSliceRowArray(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetColumnArray(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetSliceColumnArray(const vector<string>& parameters, string& result, Composite* node) { return true; }
  // 
  //bool DataFrame::FuncSetCell(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetCell(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncCellName(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSetWidth(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSetType(const vector<string>& parameters, string& result, Composite* node)  { return true; }
  //bool DataFrame::FuncGetWidth(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetType(const vector<string>& parameters, string& result, Composite* node) { return true; }
  
  //bool DataFrame::FuncSetPrintEmptyRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetPrintEmptyRows(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSetRowSelectedFrom(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetRowSelectedFrom(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSetRowSelectedTo(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetRowSelectedTo(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncSetReallocIncrement(const vector<string>& parameters, string& result, Composite* node) { return true; }
  //bool DataFrame::FuncGetReallocIncrement(const vector<string>& parameters, string& result, Composite* node) { return true; }
}
