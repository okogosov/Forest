#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  bool DataFrame::FuncGetWidth(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetWidth";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.GetWidth (DataFrame_name)(column_name)",func_name });
        return false;
      }
      //=========================================================
      df_name = parameters[0];
      string column_name = parameters[1];

      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      //vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          //ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == column_name + "Width")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }

      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] wrong column name [{2}]",func_name,df_name ,column_name });
        return false;
      }

      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncSetWidth(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncSetWidth";
    string df_name;
    try
    {
      if (parameters.size() != 3)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.SetWidth (DataFrame_name)(column_name)(value)", func_name});
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      string column_name = parameters[1];
      string strLength = "";

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ( (*(comp_settings->_children))[i]->name == column_name + "Width")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({"Error: [{0}] DataFrame name [{1}] wrong column name [{2}]", func_name,df_name, column_name });
        return false;
      }
      int width = 0;
      bool b = TryParse(parameters[2], width); 
      if (!b)
      {
        printDlgt({"Error: [{0}] DataFrame name [{1}] width not digital [{2}]", func_name,df_name, parameters[2]});
        return false;
      }
      settings_param->value = to_string(width);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncSetType(const vector<string>& parameters, string& result, Composite* node)
  {
    const string func_name = "DataFrame.FuncSetType";
    string df_name;
    try
    {
      if (parameters.size() != 3)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.SetType (DataFrame_name)(column_name)(Text | Number)", func_name });
        return false;
      }

      df_name = parameters[0];
      string column_name = parameters[1];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      Composite* settings_param = nullptr;
      for (auto* child : *(comp_settings->_children))
      {
        if (child->name == column_name + "Type")
        {
          settings_param = (Composite*)child;
          break;
        }
      }

      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] wrong column name [{2}]", func_name,df_name,column_name });
        return false;
      }

      string value = parameters[2];
      if (value == "Text" || value == "Number")
      {
        settings_param->value = value;
      }
      else
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] wrong Type value[{2}](not 'Text' or 'Number')",func_name,df_name, value });
        return false;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncGetType(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetType";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.GetType (DataFrame_name)(column_name)",func_name});
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      string column_name = parameters[1];

      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      //vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          //ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ( (*(comp_settings->_children))[i]->name == column_name + "Type")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }

      if (settings_param == nullptr)
      {
        printDlgt({"Error: [{0}] DataFrame name [{1}] wrong column name [{2}]",func_name,df_name ,column_name});
        return false;
      }

      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncSetPrintEmptyRows(const vector<string>& parameters, string& result, Composite* node) 
  { 
    string func_name = "DataFrame.FuncSetPrintEmptyRows";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.SetPrintEmptyRows (DataFrame_name)(value)", func_name });
        return false;
      }
      //====================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "PrintEmptyRows")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] PrintEmptyRows is omitted", func_name,df_name });
        return false;
      }
      string value = parameters[1];
      if ((value == "yes") || (value == "no"))
        settings_param->value = value;
      else
      {
        printDlgt({"Error: [{0}] DataFrame name [{1}] wrong Type value [{2}]  (not 'yes' or 'no')", func_name, df_name, value });
        return false;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=====================================================================================
  bool DataFrame::FuncGetPrintEmptyRows(const vector<string>& parameters, string& result, Composite* node) 
  { 
    string func_name = "DataFrame.FuncGetPrintEmptyRows";
    string df_name;
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.GetPrintEmptyRows (DataFrame_name)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "PrintEmptyRows")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] PrintEmptyRows is omitted", func_name,df_name });
        return false;
      }
      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=====================================================================================
  bool DataFrame::FuncSetRowSelectedFrom(const vector<string>& parameters, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncSetRowSelectedFrom";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.SetRowSelectedFrom (DataFrame_name)(value)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "RowSelectedFrom")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowSelecteFrom is omitted", func_name,df_name });
        return false;
      }
      int value = 0;
      bool b = TryParse(parameters[1], value);
      if (!b)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] width not digital [{2}]", func_name,df_name, parameters[1] });
        return false;
      }
      settings_param->value = to_string(value);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=====================================================================================
  bool DataFrame::FuncGetRowSelectedFrom(const vector<string>& parameters, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncGetRowSelectedFrom";
    string df_name;
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.GetRowSelectedFrom (DataFrame_name)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "RowSelectedFrom")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowSelectedFrom is omitted", func_name,df_name });
        return false;
      }
      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=====================================================================================
  bool DataFrame::FuncSetRowSelectedTo(const vector<string>& parameters, string& result, Composite* node) 
  { 
    string func_name = "DataFrame.FuncSetRowSelectedTo";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.SetRowSelectedTo (DataFrame_name)(value)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "RowSelectedTo")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowSelectedTo is omitted", func_name,df_name });
        return false;
      }
      int value = 0;
      bool b = TryParse(parameters[1], value);
      if (!b)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] width not digital [{2}]", func_name,df_name, parameters[1] });
        return false;
      }
      settings_param->value = to_string(value);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
  //=====================================================================================
  bool DataFrame::FuncGetRowSelectedTo(const vector<string>& parameters, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncGetRowSelectedTo";
    string df_name;
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.GetRowSelectedTo (DataFrame_name)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "RowSelectedTo")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowSelectedTo is omitted", func_name,df_name });
        return false;
      }
      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncSetReallocIncrement(const vector<string>& parameters, string& result, Composite* node) 
  {
    string func_name = "DataFrame.FuncSetReallocIncrement";
    string df_name;
    try
    {
      if (parameters.size() != 2)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.SetReallocIncrement (DataFrame_name)(value)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "ReallocIncrement")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] ReallocIncrement is omitted", func_name,df_name});
        return false;
      }
      int value = 0;
      bool b = TryParse(parameters[1], value);
      if (!b)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] width not digital [{2}]", func_name,df_name, parameters[1] });
        return false;
      }
      settings_param->value = to_string(value);
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //=====================================================================================
  bool DataFrame::FuncGetReallocIncrement(const vector<string>& parameters, string& result, Composite* node) 
  { 
    string func_name = "DataFrame.FuncGetReallocIncrement";
    string df_name;
    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({ "Error: [{0}] wrong parameter, format: DataFrame.GetReallocIncrement (DataFrame_name)", func_name });
        return false;
      }

      //=========================================================
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      Composite* settings_param = nullptr;
      for (size_t i = 0; i < comp_settings->_children->size(); i++)
      {
        if ((*(comp_settings->_children))[i]->name == "ReallocIncrement")
        {
          settings_param = (Composite*)((*(comp_settings->_children))[i]);
          break;
        }
      }
      if (settings_param == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] ReallocIncrement is omitted", func_name,df_name });
        return false;
      }
      result = settings_param->value;
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true; 
  }
}