#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "File.h"

using namespace std;
namespace PPLNS
{
  static File* FILEInstance = nullptr;

  void File_CreateInstance(PPL* ppl)
  {
    FILEInstance = new File(ppl);
    FILEInstance->AddToKeywordDictionary();
  }

  File::File(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void File::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("ReadAllText", FuncReadAllText);
    AddKeyword("WriteAllText", FuncWriteAllText);
    AddKeyword("ReadAllLines", FuncReadAllLines);
    AddKeyword("WriteAllLines", FuncWriteAllLines);
    AddKeyword("Exists", FuncExists);
    AddKeyword("Delete", FuncDelete);

    help_dict->insert({ "help", "\tFile.help([name])" });
    help_dict->insert({ "ReadAllText", "\t..." });
    help_dict->insert({ "WriteAllText", "\t..." });
    help_dict->insert({ "ReadAllLines", "\t..." });
    help_dict->insert({ "WriteAllLines", "\t..." });
    help_dict->insert({ "Exists", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "File." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "File", this });
  }
  //=========================================================
  bool File::FuncReadAllText(vector<string> parameters, string& result, Composite* node) { return true; }
  bool File::FuncWriteAllText(vector<string> parameters, string& result, Composite* node) { return true; }
  bool File::FuncReadAllLines(vector<string> parameters, string& result, Composite* node) { return true; }
  bool File::FuncWriteAllLines(vector<string> parameters, string& result, Composite* node) { return true; }
  bool File::FuncExists(vector<string> parameters, string& result, Composite* node) { return true; }
  bool File::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
}
