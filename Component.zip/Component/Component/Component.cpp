﻿#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <nlohmann/json.hpp> // Include the JSON library

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

using namespace std;

// Forward declaration of Composite
class Composite;
using json = nlohmann::json;

// Base class Component
class Component {
public:
  string name = "";
  string value = "";
  Composite* parent = nullptr;

  Component(string _name, string _value = "")
    : name(_name), value(_value) {
  }

  virtual ~Component() = default; // Virtual destructor for polymorphic deletion
  virtual void SaveTreeJson(Composite*& WorkNode, const string& CallerObjectName, ofstream& writer, int& depth) = 0;
  virtual void Display(int depth, bool only_nodes = false) = 0;
};

// Composite class
class Composite : public Component {
public:
  vector<Component*>* _children;

  Composite(string _name, string _value = "") : Component(_name, _value) {
    _children = new vector<Component*>;
  }

  ~Composite() {
    DeleteAllSuccessors();
    delete _children;
  }

  void DeleteAllSuccessors() {
    for (Component* c : *_children) {
      delete c;
    }
    _children->clear();
  }

  void Display(int depth, bool only_nodes = false) override {
    string offset(depth, '-');
    if (value.empty()) {
      cout << offset << "\t" << name << endl;
    }
    else {
      cout << offset << "\t" << "Name: " << name << "\tValue: " << value << endl;
    }
    for (Component* child : *_children) {
      child->Display(depth + 2);
    }
  }

  void Add(Component* c) 
  {
    _children->push_back(c);
    c->parent = this;
  }
  // recursive
  void SaveTreeJson(Composite*& WorkNode, const string& CallerObjectName, ofstream& writer, int& depth) override 
  {
    string indent(depth, ' '); // Create indentation
    string str;

    // Trim quotes from name and value
    name.erase(remove(name.begin(), name.end(), '\"'), name.end());
    value.erase(remove(value.begin(), value.end(), '\"'), value.end());
    
    if (this->name != WorkNode->name)
    {
      //str = indent + "\"" + name + "\": {" + "\n";
      str = indent + "\"" + name + "\"" + ":\n";
      str += indent + "{" + "\n";
    }
    else
      str = "{\n";
    writer << str;
    depth++;

    // Iterate over children and call their SaveTreeJson
    for (size_t i = 0; i < _children->size(); i++) 
    {
      (*_children)[i]->SaveTreeJson(WorkNode, CallerObjectName, writer, depth);

      // Only add a comma if this is not the last child
      if (i < _children->size() - 1) 
      {
        writer << ","; // Add a comma between siblings
      }
      writer << "\n"; // Ensure each child is on a new line
    }
    // Close the JSON object for the composite
    if (this->name != WorkNode->name)
      writer << indent << "}" << "\n";
    else
      writer << "}" << "\n";
    depth--;
  }
};

// Leaf class
class Leaf : public Component 
{
public:
  Leaf(string _name, string _value) : Component(_name, _value) {}

  void Display(int depth, bool only_nodes = false) override {
    if (only_nodes) return;
    string offset(depth, '-');
    cout << offset << name << (value.empty() ? "" : "\t" + value) << endl;
  }

  void SaveTreeJson(Composite*& WorkNode, const string& CallerObjectName, ofstream& writer, int& depth) override 
  {
    string indent(depth, ' '); // Create indentation
    string str;

    // Trim quotes from name and value
    name.erase(remove(name.begin(), name.end(), '\"'), name.end());
    value.erase(remove(value.begin(), value.end(), '\"'), value.end());

    // Format the JSON string for the leaf
    if (IsDigitsOnly(value)) 
    {
      str = indent + "\"" + name + "\": " + value;
    }
    else 
    {
      str = indent + "\"" + name + "\": \"" + value + "\"";
    }
    writer << str;
  }

  bool IsDigitsOnly(const std::string& str) 
  {
    return !str.empty() && all_of(str.begin(), str.end(), ::isdigit);
  }
};
//=======================================================
// recursive
void ReadDataFromJson(const string& filename, Composite*& root) 
{
  ifstream inputFile(filename);
  if (!inputFile.is_open()) 
  {
    cerr << "Could not open the file: " << filename << endl;
    return;
  }

  json j;
  inputFile >> j; // Parse the JSON file
  inputFile.close();

  if (j.is_null()) 
  {
    cerr << "Parsed JSON is null!" << endl;
    return;
  }

  // Recursive function to build the tree
  function<Composite* (const json&, const string&)> buildTree = [&](const json& jNode, const string& nodeName) 
  {
    Composite* node = new Composite(nodeName);

    for (auto& el : jNode.items()) 
    {
      if (el.value().is_object())
      {
        // If the value is an object, create a composite node
        Composite* childNode = buildTree(el.value(), el.key());
        node->Add(childNode);
      }
      else 
      {
        // If the value is a primitive, create a leaf node
        Leaf* leafNode = new Leaf(el.key(), el.value().get<string>());
        node->Add(leafNode);
      }
    }
    return node;
  };

  /*
  //function<Composite* (const json&, const string&)> buildTree = [&](const json& jNode, const string& nodeName)
  //  {
  //    Composite* node = new Composite(nodeName);

  //    // Extract keys and sort them
  //    std::vector<std::string> keys;
  //    for (auto& el : jNode.items()) {
  //      keys.push_back(el.key());
  //    }
  //    std::reverse(keys.begin(), keys.end());  

  //    for (const auto& key : keys)
  //    {
  //      auto& el = jNode[key];
  //      if (el.is_object())
  //      {
  //        // If the value is an object, create a composite node
  //        Composite* childNode = buildTree(el, key);
  //        node->Add(childNode);
  //      }
  //      else
  //      {
  //        // If the value is a primitive, create a leaf node
  //        Leaf* leafNode = new Leaf(key, el.get<string>());
  //        node->Add(leafNode);
  //      }
  //    }
  //    return node;
  //  };
  */

  // Start building the tree from the root
  root = buildTree(j, "root");   
}
//=======================================================
int main() 
{
  Composite* root = new Composite("root");
  
  Leaf* leaf1 = new Leaf("leaf1", "");
  Leaf* leaf2 = new Leaf("leaf2", "");
  root->Add(leaf1);
  root->Add(leaf2);

  Composite* node = new Composite("Node");
  node->Add(new Leaf("leafN1", ""));
  node->Add(new Leaf("leafN2", ""));
  Composite* subNode = new Composite("subNode");
  subNode->Add(new Leaf("leaf_subN1", ""));
  subNode->Add(new Leaf("leaf_subN2", ""));
  node->Add(subNode);

  root->Add(node);
  root->Display(1);

/* 1st print
1st print
- root
-- - leaf1
-- - leaf2
-- - Node
---- - leafN1
---- - leafN2
---- - subNode
------ - leaf_subN1
------ - leaf_subN2

*/
  cout << endl;

  ofstream writer("output.json");
  Composite*& WorkNode = root; // For recursive function
  int depth = 1; // Initial depth
  
  root->SaveTreeJson(WorkNode, "main", writer, depth);
  writer.close(); // Always close the file after writing
  delete root; // Clean up memory

  ReadDataFromJson("output.json", root);
  if (root) 
    root->Display(1);
  /*
  *2nd print order of Leaves & Nodes is differ from the 1st print
  - root
-- - Node
---- - leafN1
---- - leafN2
---- - subNode
------ - leaf_subN1
------ - leaf_subN2
-- - leaf1             <=== wrong order
-- - leaf2
  */
  delete root; // Clean up memory
  _CrtDumpMemoryLeaks(); // Check for memory leaks
  return 0;
}