

/*
The PPLNS::PPL::Parser function is a core component for interpreting a custom programming language (PPL) by transforming a raw string of PPL code into an Abstract Syntax Tree (AST). This AST, represented by a tree of Composite and Leaf nodes, provides a structured, hierarchical representation of the code, making it easier for subsequent processing steps (like execution or semantic analysis) to understand and act upon the program's logic.

Here's a detailed breakdown of its functionality, section by section:

1. Preliminaries and Setup:

Includes: The parser relies on standard C++ libraries like iostream for output, string for string manipulation, algorithm for general utilities, unordered_set for efficient lookup of command names, and stack for managing the parsing process (parentheses and nodes).
Namespace PPLNS: The entire parser logic is encapsulated within this namespace, promoting code organization and preventing naming conflicts.
Helper Utilities:
PPL::trim(const std::string& str): Removes leading and trailing whitespace characters (including standard spaces, tabs, newlines, carriage returns, form feeds, vertical tabs, and non-breaking spaces \xA0) from a string.
PPL::TrimPPL(std::string& text): A utility that trims a string in place if its length is at least 2 characters.
isSingleLineCommentStart, isMultiLineCommentStart, isMultiLineCommentEnd: Helper functions to identify comment delimiters.
handleEscapedCharacter: Helps in CheckNumberOfParentheses and CheckNumberOfQuotes to correctly skip escaped characters within string literals.
Command Sets:
set_cmds_OneArgument: An unordered_set containing commands that can optionally take one argument (e.g., help, import, display).
NoParametersCommands: An array of commands that can be used without any parameters (e.g., display, code). These will be converted from Leaf to Composite nodes post-parsing.
set_creation_cmds: An unordered_set containing commands related to variable/data creation (var, const, array, storage).
2. Core PPL::Parser Function (Composite* PPL::Parser(const string& input0, bool CheckQuotesAndParentheses)):

Initialization:
stack<char> parentheses;: Stores opening parenthesis characters to ensure balance.
stack<Composite*> nodes;: Stores Composite nodes as they are built, representing the current path in the AST. The top of the stack is the current parent node.
Composite* root = nullptr;: A pointer to the root of the AST, initialized to nullptr and populated when the first top-level expression is parsed.
Input Validation and Pre-processing:
Empty Input Check: If input0 is empty, it immediately returns nullptr.
Whitespace Normalization:
C++

for (char& ch : input) 
{
    if (ch == '\xA0') 
    { // Non-breaking space
        ch = ' '; // Replace with standard space
    }
}
This crucial step replaces all Unicode non-breaking spaces with standard spaces. This prevents subtle parsing errors and ensures consistent behavior of whitespace-sensitive functions like trim.
Quote and Parenthesis Balance Checks:
C++

if (CheckQuotesAndParentheses)
{
  if (!CheckNumberOfQuotes(input)) {  return nullptr; }  // error handling 
  if (!CheckNumberOfParentheses(input)) {  return nullptr; }  // error handling 
}
If CheckQuotesAndParentheses is true, the parser first validates the overall balance of quotes and parentheses in the raw input string.This is a fundamental syntactic check.
Comment Removal(PPL::RemoveComments) :
  C++

  PPL::RemoveComments(input);
This is a significant pre - processing step.The dedicated PPL::RemoveComments function is called to strip all single - line(//) and multi-line (/* ... */) comments from the input string. By doing this before the main parsing loop, the parser's logic becomes much simpler, as it no longer needs to deal with comment states during tokenization and AST construction.
  Command Argument Handling :
C++

string cmd1 = GetCommand(input);
if (set_cmds_OneArgument.count(cmd1)) { /* logic to wrap arguments in parentheses */ }
It identifies the initial command(cmd1).If it's a command that expects one argument (from set_cmds_OneArgument), and the argument is not already enclosed in parentheses, the argument is wrapped in (). This standardizes the input format for such commands.
Root Parentheses Addition(AddParentheses) :
  C++

  AddParentheses(input);
This function ensures that the entire input string is wrapped within a single pair of parentheses().This simplifies the parser's task by guaranteeing a consistent top-level structure, allowing it to always start parsing from an opening parenthesis to establish the root of the AST.
3. Main Parsing Loop(for (long k = 0; k < input.size(); ++k)) :

  This is the core state machine that iterates through the pre - processed input string character by character to build the AST.

  State Variables :

string value = ""; : Accumulates characters that form the content(name or value) of a Leaf or Composite node.
string name = ""; : Temporarily holds the name of a node being constructed.
int open_brackets = 0; : Counts open square brackets[], indicating an array access or similar context.Characters within these brackets are treated as part of the value string.
bool inQuotes = false; : Tracks whether the parser is currently inside a double - quoted string literal.Characters within quotes are treated literally.
long counter_leaf = 0; : A counter for debugging / profiling leaf node creation.
switch (c) Statement : Processes each character c based on its type and the current parsing state.

String Literals("):
  Toggles inQuotes state.
  Appends the quote character to value.
  Escaped Characters(\) :
  If a backslash is followed by another backslash(\\) or a quote(\"), the escaped character is appended to value, and k is incremented to skip the next character. This ensures escaped sequences are treated as single characters within literals.
    Other backslashes are appended literally.
    Whitespace(\t, \n, \r) :
    Whitespace characters are generally ignored unless the parser is currently inQuotes.If inQuotes is true, whitespace is appended to value(as it's part of the string literal).
      Square Brackets([, ]) :
      If not inQuotes, open_brackets count is incremented / decremented.
      Always appended to value, as they define array / indexer content within a node's value.
      Semicolon(;) :
      Appended to value only if inside square brackets(open_brackets != 0) or inQuotes.Otherwise, it acts as a statement separator(though the AddParentheses step often handles this at the top level).
      Opening Parenthesis(() :
        If inside brackets or quotes : Appended to value(treated as part of the string / expression).
        Otherwise(significant() : This is a key parsing point, handled by handleOpenParenthesis.
          It checks the parentheses stack.
          If the stack is empty, it's the very first opening parenthesis (after AddParentheses), and a Composite("root") node is created, pushed onto nodes, and root is set.
          If the stack's top is ')' (unlikely if parentheses are truly balanced), it might indicate a syntax error or a complex case.
        If the stack's top is '(', it means a new nested expression/block is starting. The value accumulated so far (which represents the name of the new node) is extracted. A new Composite node is created with this name, added as a child to the current parent (nodes.top()), and then pushed onto the nodes stack, effectively moving deeper into the AST. value is reset for the new node's content.
          Closing Parenthesis()) :
        If inside brackets or quotes : Appended to value.
        Otherwise(significant)) : This is another key parsing point, handled by handleCloseParenthesis.
      If the parentheses stack's top is '(': This signifies the end of a block/expression that started with an opening parenthesis.
        The value accumulated since the last(is processed.This value can represent a simple literal, a command, or a more complex expression potentially with[] indexing or quoted strings.
          Logic is applied to extract the name and an optional value_tmp(e.g., for var(x[10]), name is x, value_tmp is 10).
          Special handling exists for commands that take a single argument or for quoted string values(where the entire quoted string might become the node's name).
            A Leaf node is typically created with the extracted name and value_tmp.
            This Leaf is then added as a child to the current parent node(nodes.top()).value is reset.
            If the parentheses stack's top is ')': This means the current Composite node's content is finished.The node is popped from the nodes stack, moving the parser back up the AST hierarchy to the parent.
          4. Post - Parsing Processing and Validation:

Bracket Balance Check : After the loop, it verifies that open_brackets is 0. If not, it indicates a syntax error.
Stack Cleanup : The parentheses and nodes stacks are cleared.root is not deleted here as it's the function's return value.
Root Check : If root is still nullptr (meaning no valid top - level expression was parsed), it returns nullptr.
Leaf - to - Node Conversion :
C++

for (int i = 0; i < NoParametersCommands_Length; i++)
  root->ConvertLeafToNode(NoParametersCommands[i]);
For commands listed in NoParametersCommands(e.g., display, code), if they were initially parsed as Leaf nodes(because they didn't have explicit arguments, or their arguments were handled by AddParentheses), this step converts them into Composite nodes. This allows them to potentially have children added later (e.g., if code generation adds implicit arguments).
  Semantic Validations :
Creation Commands Naming : Checks if the name of a variable, constant, array, or storage declaration(commands like var, const) is not a reserved keyword(all, True, False) or a keyword in the processing->keyword_dict(if processing object was available).This prevents conflicts with built - in language elements.
set Command Special Handling : For the set command, it checks for specific conditions related to empty child elements or quoted string representation(""") to potentially convert internal names.
  Empty Leaf Check : root->FindEmptyLeaf(nullptr, node_name_for_error) traverses the generated AST to find any Leaf nodes that have empty names.If found, it indicates a parsing error, and the function returns nullptr.
  5. Return Value :

The function returns the Composite * root pointer, which is the root of the constructed Abstract Syntax Tree.This AST can then be traversed and interpreted by other parts of the PPL system.
In summary, the PPLNS::PPL::Parser function is a robust, state - machine - driven parser that first cleans and standardizes the input, then meticulously builds a hierarchical AST by managing parenthesis and node stacks, and finally performs post - parsing validations to ensure the semantic correctness of the parsed structure.

*/