#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  /// <summary>
  /// SelectRows(df_name)(selected_row)    only one row
  /// </summary>
  /// <param name="parameters"></param>
  /// <param name="result"></param>
  /// <param name="node"></param>
  /// <returns></returns>
  bool DataFrame::FuncSelectRows(const vector<string>& parametersInput, string &result, Composite* node)
  {
    string func_name = "DataFrame.FuncSelectRows";
    string df_name = "";

    try
    {
      if (parametersInput.size() != 2 && parametersInput.size() != 3)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.SelectRows(df_name)(select_from)[(select_to)]", func_name});
        return false;
      }
      vector<string> parameters = parametersInput;
      if (parameters.size() == 2)
      {
        parameters.push_back(parameters[1]);
      }
      df_name = parameters[0];
      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame [{1}]", func_name,df_name });
        return false;
      }
      //====================================================
      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      TryParse(strLength,Length);
      //====================================================
      string strSelectFrom = parameters[1];
      int SelectFrom = 0;

      if(!TryParse(strSelectFrom, SelectFrom))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] strSelectFrom not digital value [{2}]", func_name , df_name, strSelectFrom });
        return false;
      }

      if (strSelectFrom == "0")
      {
        printDlgt({"Error: [{0}] DataFrame [{1}]  select_from = 0",func_name , df_name});
        return false;
      }
      //====================================================
      string strSelectTo = parameters[2];
      if (strSelectTo == "*")
        strSelectTo = to_string(Length - 1);

      int SelectTo = 0;
      if (!TryParse(strSelectTo, SelectTo))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] strSelectTo not digital value [{2}]", func_name , df_name, strSelectTo });
        return false;
      }

      if (strSelectTo == "0")
      {
        printDlgt({"Error: [{0}]  [{1}] strSelectTo = 0",func_name , df_name });
        return false;
      }

      //====================================================
      for(auto*& c : *(comp_settings->_children))
      {
        if (c->name.find("RowSelectedFrom") != string::npos)
          c->value = strSelectFrom;
        if (c->name.find("RowSelectedTo") != string::npos)
          c->value = strSelectTo;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }
  //==================================================================================
  bool DataFrame::FuncUnSelectRows(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncUnSelectRows";
    string df_name = "";

    try
    {
      if (parameters.size() != 1)
      {
        printDlgt({"Error: [{0}] wrong parameter, format: DataFrame.UnSelectRows(df_name)", func_name});
        return false;
      }

      df_name = parameters[0];

      //====================================================
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame [{1}]", func_name,df_name });
        return false;
      }
      //====================================================

      //for (size_t i = 0; i < comp_settings->_children.size(); i++)
      for(auto*& c : *(comp_settings->_children))
      {
        if (c->name.find("RowSelectedFrom") != string::npos)
        {
          c->value = "";
          continue;
        }

        if (c->name.find("RowSelectedTo") != string::npos)
        {
          c->value = "";
          continue;
        }
      }
    }
    catch (const exception& ex)
    {
      printDlgt({"Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }

    return true;
  }  
}