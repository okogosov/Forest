#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Random.h"

using namespace std;
namespace PPLNS
{
  static Random* RANDOMInstance = nullptr;

  void Random_CreateInstance(PPL* ppl)
  {
    RANDOMInstance = new Random(ppl);
    RANDOMInstance->AddToKeywordDictionary();
  }

  Random::Random(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void Random::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Next", FuncNext);
    AddKeyword("NextToArray", FuncNextToArray)
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Write", FuncWrite);

    help_dict->insert({ "help", "\tRandom.help([name])" });
    help_dict->insert({ "Create", "\tRandom.Create(random_name)(type)(from)(to)\t\r\ntype: = int | real" });
    help_dict->insert({ "Next", "\tRandom.Next(random_name)" });
    help_dict->insert({ "NextToArray", "\tRandom.NextToArray(random name)(\"ppl_array\")(quantity of random elements)" });
    help_dict->insert({ "Delete", "\tRandom.Delete(random_name) | Random.Delete()" });
    help_dict->insert({ "Write", "\t: Random.Write()" });
    for (const auto pair : *keyword_dict)
    {
      string key = "Random." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Random", this });
  }
  //=========================================================
  // random_name, int | real, from, to
  bool Random::FuncCreate(const vector<string>& parameters, string& result, Composite* node)
  {
    try
    {
      if (parameters.size() != 4)
      {
        printDlgt({ "Error: [Random.FuncCreate] wrong number of parameters" });
        return false;
      }
      bool CreatedRepeatedlyFlag = false;
      result = "";
      string randomName = trim(parameters[0], "\"");

      for (size_t j = 0; j < named_random_vector.size(); j++)
      {
        if (named_random_vector[j].name == randomName)
        {
          CreatedRepeatedlyFlag = true;
          break;
        }
      }
      if ((parameters[1] != "int") && (parameters[1] != "real"))
      {
        printDlgt({ "Error: [Random.FuncCreate] [{0}] wrong randodm type", parameters[1] });
        return false;
      }
      NamedRandom nrand;
      nrand.name = randomName;

      if (parameters[1] == "int")
      {
        nrand.type = DISTRUBUTION_TYPE::INT;
        int i1 = stoi(parameters[2]);
        int i2 = stoi(parameters[3]);
        nrand.int_dist = uniform_int_distribution<int>(i1, i2);

      }
      else
      {
        nrand.type = DISTRUBUTION_TYPE::REAL;
        double d1 = stod(parameters[2]);
        double d2 = stod(parameters[3]);
        nrand.real_dist = uniform_real_distribution<double>(d1, d2);
      }
      named_random_vector.push_back(nrand);
      if (CreatedRepeatedlyFlag)
        printDlgt({ "Warning: [Random.FuncCreate] name [" + parameters[0] + "] is created repeatedly" });

    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [Random.FuncCreate] [{0}]", ex.what() });
      return false;
    }

  }
  //=========================================================
  bool Random::GetNamedRandomByName(const string& methodName, const string& name, NamedRandom*& nrandom)
  {
    for (int i = 0; i < named_random_vector.size(); i++)
    {
      if (named_random_vector[i].name == name)
      {
        nrandom = &(named_random_vector[i]);
        return true;
      }
    }
    nrandom = nullptr;
    printDlgt({ "Error: [Random.GetNamedRandomByName] [{0}] wrong name [{1}]", methodName, name });
    return false;
  }
  //=========================================================
  bool Random::FuncNext(const vector<string>& parameters, string& result, Composite* node)
  {
    string calling_method_name = "Random.FuncNext";

    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters", calling_method_name });
      return false;
    }
    try
    {
      NamedRandom* nrandom = nullptr;
      bool b = GetNamedRandomByName(calling_method_name, parameters[0], nrandom);
      if (!b)
      {
        printDlgt({ "Error: [{0}] wrong name of Random object: [{1}]", calling_method_name, parameters[0] });
        return false;
      }
      if (nrandom->type == DISTRUBUTION_TYPE::INT)
      {
        int randomNumber = nrandom->int_dist(nrandom->random);
        result = to_string(randomNumber);
      }
      else
      {
        double randomNumber = nrandom->real_dist(nrandom->random);
        result = to_string(randomNumber);
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [Random.FuncNext] [{0}]", ex.what() });
      return false;
    }
    return true;
  }
  //=========================================================
  // random_name, ppl_array, counter 
  bool Random::FuncNextToArray(const vector<string>& parameters, string& result, Composite* node)
  {
    string calling_method_name = "Random.FuncNextToArray";

    if (parameters.size() != 3)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters", calling_method_name });
      return false;
    }
    try
    {      
        NamedRandom* nrandom = nullptr;
        bool b = GetNamedRandomByName(calling_method_name, parameters[0], nrandom);
        if (!b)
        {
          printDlgt({"Error: [{0}] wrong name of Random object",calling_method_name });
            return false;
        }
        string ppl_array = parameters[1];
        int Counter = 0;
        if(!TryParse(parameters[2], Counter))
        {
          printDlgt({"Error: [{0}] not a digital value [{1}]",calling_method_name ,parameters[2] });
          return false;
        }
        //========================================================
        Composite* path = nullptr; // Assuming Composite is a pointer type
        string nodes = "";
        string name = "";
        b = ppl->processing->GetPathAndNameFromGlobalLocal(calling_method_name, ppl_array, path, nodes, name);
        if (!b)
            return false;
        //===================================================
        ppl->processing->FuncReAllocArray({ name, "", parameters[2], "","", ""}, result, node);
        //======================================================
        Composite* node_ppl_array = nullptr;
        for (Component* c : *(path->_children))
        {
          if (c->name == name)
          {
            node_ppl_array = (Composite*)c;
            break;
          }
        }
        if (node_ppl_array == nullptr)
        {
          // error
          return false;
        }
        //======================================================        
        if (nrandom->type == DISTRUBUTION_TYPE::INT)
        {
          for (size_t i = 0; i < Counter; ++i)
          {
            int itmp = nrandom->int_dist(nrandom->random);
            (*(node_ppl_array->_children))[i]->value = to_string(itmp);
          }
        }
        else
        {
          for (size_t i = 0; i < Counter; ++i)
          {
            double dtmp = nrandom->real_dist(nrandom->random);
            (*(node_ppl_array->_children))[i]->value = FormatDouble(dtmp);
          }
        }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",calling_method_name ,ex.what() });
      return false;
    }
  }
  //=========================================================
  // [random_name]
  bool Random::FuncDelete(const vector<string>& parameters, string& result, Composite* node)
  {
    string calling_method_name = "Random.FuncDelete";

    if (parameters.size() > 1)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters", calling_method_name });
      return false;
    }
    try
    {
      if (parameters.empty())
      {
        named_random_vector.clear();
        return true;
      }
      else
      {
        string random_name = parameters[0];
        for (int i = 0; i < named_random_vector.size(); i++)
        {
          if (named_random_vector[i].name == random_name)
          {
            named_random_vector.erase(named_random_vector.begin() + i);
            return true;
          }
        }
        printDlgt({ "Error: [{0}] wrong name of Random object",calling_method_name });
        return false;
      }
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] [{1}]",calling_method_name ,ex.what() });
      return false;
    }
  }
  //=========================================================
  bool Random::FuncWrite(const vector<string>& parameters, string& result, Composite* node)
  {
    string calling_method_name = "Random.FuncWrite";

    if (parameters.size() != 0)
    {
      printDlgt({ "Error: [{0}] wrong number of parameters", calling_method_name });
      return false;
    }
    string str_type;
    for (int i = 0; i < named_random_vector.size(); i++)
    {
      if (named_random_vector[i].type == DISTRUBUTION_TYPE::INT)
        str_type = "int";
      else
        str_type = "real";
      printDlgt({"{0}\t{1}\t{2}",to_string(i),named_random_vector[i].name, str_type});
    }

  }
}
