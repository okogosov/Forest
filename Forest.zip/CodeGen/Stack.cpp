#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Stack.h"

using namespace std;
namespace PPLNS
{
  static Stack* STACKInstance = nullptr;

  void Stack_CreateInstance(PPL* ppl)
  {
    STACKInstance = new Stack(ppl);
    STACKInstance->AddToKeywordDictionary();
  }

  Stack::Stack(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Stack::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("Count", FuncCount);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Push", FuncPush);
    AddKeyword("Pop", FuncPop);
    AddKeyword("Peek", FuncPeek);
    AddKeyword("Clear", FuncClear);
    AddKeyword("Contains", FuncContains);
    AddKeyword("AddArray", FuncAddArray);
    AddKeyword("ToArray", FuncToArray);

    help_dict->insert({ "help", "\tStack.help([name])" });
    help_dict->insert({ "Create", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    help_dict->insert({ "Count", "\t..." });
    help_dict->insert({ "Write", "\t..." });
    help_dict->insert({ "Push", "\t..." });
    help_dict->insert({ "Pop", "\t..." });
    help_dict->insert({ "Peek", "\t..." });
    help_dict->insert({ "Clear", "\t..." });
    help_dict->insert({ "Contains", "\t..." });
    help_dict->insert({ "AddArray", "\t..." });
    help_dict->insert({ "ToArray", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Stack." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Stack", this });
  }
  //=========================================================
  bool Stack::FuncCreate(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncCount(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncWrite(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncPush(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncPop(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncPeek(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncClear(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncContains(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncAddArray(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Stack::FuncToArray(vector<string> parameters, string& result, Composite* node) { return true; }
}
