#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "..\Vector\Vector.h"
#include "Erato.h"

using namespace std;
namespace PPLNS
{
  static Erato* ERATOInstance = nullptr;

  void Erato_CreateInstance(PPL* ppl)
  {
    ERATOInstance = new Erato(ppl);
    ERATOInstance->AddToKeywordDictionary();
  }

  Erato::Erato(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }
  //=======================================================
  void Erato::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Solve1", FuncSolve1);
    AddKeyword("Solve2", FuncSolve2);
    AddKeyword("Solve3", FuncSolve3);

    help_dict->insert({ "help", "\tErato.help([name])" });
    help_dict->insert({ "Solve", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Erato." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Erato", this });
  }
  //=========================================================
  bool Erato::GetVectorByName(string calling_method_name, const string& vector_name, int*& vector,int& length_vector) 
  {
    // Vector from PPLNS.Vector
    string function_name = "Erato.GetVectorByName";
    bool b = ppl->ImportList.find("Vector") != ppl->ImportList.end();
    string err;
    if (!b) 
    {
      err = "[" + function_name + "] Vector not imported";
      printDlgt({"Error: {0}",err});
      return false;
    }

    PPLNS::Vector* v = (PPLNS::Vector*)(ppl->ImportList["Vector"]);
    string type = "";
    int length = 0;
    int index = 0;

    b = v->GetVectorProperty(vector_name, type, length, index);
    if (!b) 
    {
      // Uncomment for debugging
      // cerr << "Error: [" << function_name << "] vector [" << vector_name << "] does not exist" << endl;
      return false;
    }

    vector = (int*)(v->int_vectors[index]); 
    length_vector = length;
    return true;
  }
  //=========================================================
  // Processing data, prepared by Vector
  bool Erato::FuncSolve1(const vector<string>& parameters, string& result, Composite* node)
  { 
    int* primes;
    const string function_name = "Erato.Solve1";
    string err;
    try 
    {
      string vector_name = parameters[0];
      int vector_length = 0;
      GetVectorByName("FuncSolve1", vector_name, primes, vector_length);
      for (int n = 2; n < vector_length; n++)
      {
        for (int j = n + 1; j < vector_length; j++)
        {
          if (primes[j] == 0)
          {
            continue;
          }
          if (j % n == 0)
            primes[j] = 0;
        }
      }      
    }
    catch (const exception& ex) 
    {
      err = "[{0}] {1}" + function_name + ex.what();
      printDlgt({ "Error: {0}",err });
      return false;
    }

    return true;
  }  
  //=========================================================
  void Erato::Print(vector<int> v)
  {
    std::stringstream ss;
    for (size_t i = 0; i < v.size(); ++i)
    {
      ss << v[i];
      if (i < v.size() - 1)
        ss << ",";
    }
    std::cout << ss.str() << std::endl;
  }
  // Processing data without Vector & print results with erasing 0-elements during processing
  bool Erato::FuncSolve2(const vector<string>& parameters, string& result, Composite* node)
  {
    const string function_name = "Erato.Solve2";
    if (parameters.size() != 1)
    {
      printDlgt({ "Error: [{0}] wrong format", function_name });
      return false;
    }
    try
    {
      int vector_length = stoi(parameters[0]);
      vector<int> v(vector_length);
      for (int i = 0;i < vector_length;i++)  v[i] = i;

      int n = 1;
      while (true)
      {
        n++;
        if (n == vector_length)
          break;
        int j = n + 1;
        while (true)
        {   
          if (j == vector_length)
            break;
          if (v[j] == 0)
          {
            v.erase(v.begin() + j);
            vector_length--;
            continue;
          }
          if (v[j] % n == 0)
            v[j] = 0;
          j++;
        }
      }
      v.erase(v.begin());
      Print(v);
     
    }
    catch (const exception& ex)
    {
      cerr << "Error: [{0}] ...{1}" << function_name << ex.what() << endl;
      return false;
    }

    return true;
  }
  //===========================================================
  // the fastest algorithm
  // Processing data without Vector & print results with erasing 0-elements after processing
  bool Erato::FuncSolve3(const vector<string>& parameters, string& result, Composite* node)
  {
    const std::string function_name = "Erato.Solve3";
    if (parameters.size() != 1)
    {
      cerr << "Error: [" << function_name << "] wrong format" << endl;
      return false;
    }
    try
    {
      int vector_length = stoi(parameters[0]);
      vector<int> v(vector_length);
      for (int i = 0; i < vector_length; i++) v[i] = i;

      for (int n = 2; n * n < vector_length; n++)
      {
        if (v[n] != 0)
        {
          // the fastest algorithm
          for (int j = n * n; j < vector_length; j += n)
          {
            v[j] = 0;
          }
          // another algorithm  
          //for (int j = n + 1; j < vector_length; j++)
          //{
          //  if (v[j] == 0)
          //  {
          //    continue;
          //  }
          //  if (j % n == 0)
          //    v[j] = 0;
          //}
        }
      }
      v.erase(remove(v.begin(), v.end(), 0), v.end());
      Print(v);
    }
    catch (const exception& ex)
    {
      cerr << "Error: [" << function_name << "] ... " << ex.what() << endl;
      return false;
    }

    return true;
  }
}