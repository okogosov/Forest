#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  vector<DataFrame::TypeWidth> DataFrame::CreateTypeWidthArray(Composite* comp_df, Composite* comp_settings)
  {
    int columns_quantity = comp_df->_children->size();
    vector<string> columns(columns_quantity - 1);
    for (int i = 1; i < columns_quantity; i++) 
      columns[i - 1] = (*(comp_df->_children))[i]->name;

    vector<TypeWidth> arr_type_width(columns_quantity - 1);
    for (size_t i = 0; i < columns.size(); i++) 
    {
      TypeWidth tw;
      tw.Type = GetSettingsValue(comp_settings, columns[i] + "Type");
      tw.Width = GetSettingsValue(comp_settings, columns[i] + "Width");
      arr_type_width[i] = tw;
    }

    return arr_type_width;
  }
//=========================================================================================
// DataFrame.Write() | (df_name)
bool DataFrame::FuncWrite(vector<string> parametersInput, string& result, Composite* node)
{
  string func_name = "DataFrame.FuncWrite";
  vector<string> parameters = parametersInput;
  string df_name;
  try
  {
    if (parameters.empty())
    {
      parameters.push_back("DF");
    }
    df_name = parameters[0];
    //====================================================
    Composite* comp_df = nullptr;
    Composite* comp_settings = nullptr;
    for (auto& tn : table_names)
    {
      if (tn.name == df_name)
      {
        comp_df = tn.comp_df;
        comp_settings = tn.comp_settings;
        break;
      }
    }
    if (comp_df == nullptr)
    {
      printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
      return false;
    }
    //====================================================
    vector<TypeWidth> arr_type_width = CreateTypeWidthArray(comp_df, comp_settings);
    int columns_quantity = comp_df->_children->size();
    string strLength = GetSettingsValue(comp_settings, "RowsLength");
    int rows_length;  
    if (!TryParse(strLength, rows_length))
    {
      printDlgt({ "Error: [{0}] DataFrame name [{1}] RowsLength not digit [{2}]",func_name,df_name, strLength });
      return false;
    }
    //====================================================
    string output = "     ";
    vector<string> columns_selected;
    if (parameters.size() > 1)
    {
      columns_selected.assign(parameters.begin() + 1, parameters.end());
    }

    //=============Test column names================
    if (!columns_selected.empty())
    {
      for (const string& cw : columns_selected)
      {
        bool b2 = false;
        for (int i = 0; i < columns_quantity; i++)
        {
          if ((*(comp_df->_children))[i]->name == cw)
          {
            b2 = true;
            break;
          }
        }
        if (!b2)
        {
          printDlgt({ "Error: [{0}] DataFrame name [{1}] wrong column name [{2}]",func_name,df_name, cw });
          return false;
        }
      }
    }

    //=====get RowSelectedFrom & RowSelectedTo===================================
    string strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
    int RowSelectedFrom = 0;
    string strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");
    int RowSelectedTo = rows_length - 1;
    string PrintEmptyRows = GetSettingsValue(comp_settings, "PrintEmptyRows");
    bool b = false;
    if(!strRowSelectedFrom.empty())
    {
      if (!TryParse(strRowSelectedFrom, RowSelectedFrom))
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] not digit RowSelectedFrom [{2}]",func_name, df_name, strRowSelectedFrom });
        return false;
      }
    }
    if (strRowSelectedTo == "*") 
      strRowSelectedTo = to_string(rows_length - 1);
    if (!strRowSelectedTo.empty()) 
    {
      if (!TryParse(strRowSelectedTo, RowSelectedTo))
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] not digit RowSelectedTo [{2}]",func_name, df_name, strRowSelectedTo });
        return false;
      }
      if (RowSelectedTo >= rows_length) 
      {
        printDlgt({"Error: [{0}] RowSelectedTo [{1}] >= Max Rows Number [{2}])", func_name, strRowSelectedTo, to_string(rows_length) });
        return false;
      }
    }
    int width = 0;
    printDlgt({ "" });
    printDlgt({ "================{0}================", df_name });
    //================Write column names=============
    printDlgt({""});
    for (int i = 1; i < columns_quantity; i++) 
    {
      if (!columns_selected.empty())
      {
        if(VectorContains(columns_selected, (*(comp_df->_children))[i]->name))
        continue;
      }     
      if (!TryParse(arr_type_width[i - 1].Width,width))     
      {
        printDlgt({ "Error: [{0}] DataFrame name [{1}] RowSelectedTo [{2}] >= Max Rows Number [{3}])", 
          func_name, df_name, strRowSelectedTo, to_string(rows_length) });
        return false;
      }
      output += (*(comp_df->_children))[i]->name + string(width - (*(comp_df->_children))[i]->name.length(), ' ');
    }
    printDlgt({ output });;
    printDlgt({""});
    output.clear();
    //==============================================
    if (rows_length == 0) 
    {
      printDlgt({ "          no rows [{0}]",df_name });
      return true;
    }
    string value;
    bool EmptyRow;

    for (int j = RowSelectedFrom; j <= RowSelectedTo; j++) 
    {
      output = to_string(j) + string(5 - to_string(j).length(), ' ');
      string output2;
      EmptyRow = true;
      for (int i = 1; i < columns_quantity; i++) 
      {
        if (!columns_selected.empty())
        {
          if (VectorContains(columns_selected, (*(comp_df->_children))[i]->name))
            continue;
        }

        Composite* comp2 = (Composite*)( (*(comp_df->_children))[i] );
        value = ((*(comp2->_children))[j])->value;
        //width = stoi(arr_type_width[i - 1].Width);
        TryParse(arr_type_width[i - 1].Width,width);
        if (value.empty()) 
          value = string(width, ' ');
        else 
          EmptyRow = false;
        output2 += value + string(width - value.length(), ' ');
      }
      if (PrintEmptyRows == "no" && EmptyRow) 
        continue;
      output += output2;
      printDlgt({ "{0}",output});
    }
    for (const TableName& tn : table_names) 
    {
      if (df_name != tn.name) 
        continue;
      if(tn.cell_addresses.size() != 0)
      {
        printDlgt({ "=== defined names in DataFrame [{0}]===",tn.name});
        printDlgt({"\t{0,-15}  {1,-8}  {2}", "name", "column", "row" });
        for (const auto& pair : tn.cell_addresses)
        {
          string cell_name = pair.first;
          string column = pair.second.column;
          string row = to_string(pair.second.row);
          printDlgt({ "\t{0,-15} {1,-8} {2}", cell_name,column,  row });
        }
      }
    }
  }
  catch (const exception& ex)
  {
    printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
    return false;
  }
  return true;
}
}