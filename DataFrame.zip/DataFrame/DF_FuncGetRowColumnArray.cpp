#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
 // df,row,array   
  bool DataFrame::FuncGetRowArray(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetRowArray";

    if (parameters.size() != 3)
    {
      printDlgt({"Error: [{0}] wrong format: DataFrame.GetRowArray(DataFrame_name)(row)(array)", func_name});
      return false;
    }

    string df_name = parameters[0];

    try
    {
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      int RowsLength = 0;
      string str_RowsLength = GetSettingsValue(comp_settings, "RowsLength");
      bool b = TryParse(str_RowsLength, RowsLength);
      if (!b)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] not digital RowsLength [{2}]", func_name , df_name, str_RowsLength });
        return false;
      }

      int row = 0;
      b = TryParse(parameters[1], row);
      if (!b)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] not digital [{2}]", func_name , df_name, parameters[1]});
        return false;
      }

      if ((row < 0) || (row >= RowsLength))
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] row [{2}] out of bounds",func_name , df_name, parameters[1] });
        return false;
      }

      Composite* array_result = static_cast<Composite*>(ppl->processing->GetComponentFromDataNames(parameters[2]));
      if (array_result == nullptr)
      {
        printDlgt({"Error: [" + func_name + "] DataFrame [" + df_name + "] wrong array name [" + parameters[2] + "]", });
        return false;
      }

      string array_name = parameters[2];
      for (size_t i = 0; i < ptr_column_names->size(); i++)
      {
        Component* c = ppl->processing->GetComponentFromDataNames(df_name + "." + (*(ptr_column_names))[i]);
        if ((dynamic_cast<Leaf*>(c)) || (c == nullptr))  {  /* impossible error */ }

        Composite* array_name_node = static_cast<Composite*>(c);
        array_result->Add(new Leaf("#", (*(array_name_node->_children))[row]->value));
      }
      array_result->value = "Array " + to_string(ptr_column_names->size());
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
  //===================================================================================================
  //df,column,array
  bool DataFrame::FuncGetColumnArray(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "DataFrame.FuncGetColumnArray";
    if (parameters.size() != 3)
    {
      printDlgt({"Error: [" + func_name + "] wrong format: DataFrame.GetColumnArray(DataFrame_name)(column)(array)", });
      return false;
    }

    string df_name = parameters[0];
    try
    {
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      vector<string>* ptr_column_names = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          ptr_column_names = &(tn.column_names);
          break;
        }
      }
      if (comp_df == nullptr)
      {
        printDlgt({ "Error: [{0}] wrong DataFrame name [{1}]", func_name,df_name });
        return false;
      }

      Composite* comp_column = nullptr;
      for (size_t i = 1; i < comp_df->_children->size(); i++)
      {
        if ( (*(comp_df->_children))[i]->name == parameters[1])
        {
          comp_column = (Composite*)((*(comp_df->_children))[i]);
          break;
        }
      }

      if (comp_column == nullptr)
      {
        printDlgt({"Error: [{0}] DataFrame [{1}] wrong column name [{2}]", func_name, df_name, parameters[1] });
        return false;
      }

      Composite* array_result = static_cast<Composite*>(ppl->processing->GetComponentFromDataNames(parameters[2]));
      if (array_result == nullptr)
      {
        printDlgt({ "Error: [{0}] DataFrame [{1}] wrong array name [{2}]", func_name, df_name, parameters[2] });
        return false;
      }

     array_result->Clear();
     for (size_t i = 0; i < comp_column->_children->size(); i++)
      {
        Leaf* leaf = new Leaf("#", (*(comp_column->_children))[i]->value);
        array_result->Add(leaf);
      }
      array_result->value = "Array " + to_string(comp_column->_children->size());
    }
    catch (const exception& ex)
    {
      printDlgt({ "Error: [{0}] DataFrame [{1}] [{2}]",func_name, df_name, ex.what() });
      return false;
    }
    return true;
  }
}