#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <regex>
#include <fstream>
#include "NotationTransformations.h" // Include the new header

// Function to simulate the transformation for var declarations
std::string transformVarDeclaration(const std::string& declaration)
{
  std::string result = "";

  // Trim leading/trailing whitespace and remove "var " prefix
  std::string clean_declaration = declaration;
  if (clean_declaration.rfind("var ", 0) == 0) // Check if it starts with "var "
  {
    clean_declaration = clean_declaration.substr(4);
  }
  // Remove trailing semicolon if present
  if (!clean_declaration.empty() && clean_declaration.back() == ';')
  {
    clean_declaration.pop_back();
  }

  // Handle declarations with assignment
  if (clean_declaration.find('=') != std::string::npos)
  {
    // Split by '=' to get variable part and value part
    size_t eq_pos = clean_declaration.find('=');
    std::string var_part = clean_declaration.substr(0, eq_pos);
    std::string value_part = clean_declaration.substr(eq_pos + 1);

    // Trim spaces
    var_part = std::regex_replace(var_part, std::regex("^\\s+|\\s+$"), "");
    value_part = std::regex_replace(value_part, std::regex("^\\s+|\\s+$"), "");

    // Apply NotationTransformation to the value part (now InfixToPrefixParenthesized)
    std::string transformed_value = NotationTransformations::Math_InfixToParentheses(value_part);

    std::stringstream ss(var_part);
    std::string segment;
    while (std::getline(ss, segment, ','))
    {
      segment = std::regex_replace(segment, std::regex("^\\s+|\\s+$"), ""); // Trim each segment
      if (!segment.empty())
      {
        result += "var (" + segment + "[" + transformed_value + "]); ";
      }
    }
  }
  else
  {
    // Handle declarations without assignment (e.g., var v,x,y;)
    std::stringstream ss(clean_declaration);
    std::string segment;
    while (std::getline(ss, segment, ','))
    {
      segment = std::regex_replace(segment, std::regex("^\\s+|\\s+$"), ""); // Trim each segment
      if (!segment.empty())
      {
        result += "var (" + segment + "); ";
      }
    }
  }
  // Remove trailing space if any
  if (!result.empty() && result.back() == ' ')
  {
    result.pop_back();
  }
  return result;
}

// Function to simulate the transformation for array declarations
std::string transformArrayDeclaration(const std::string& declaration)
{
  std::string result = "";
  std::string clean_declaration = declaration;

  // Remove "array " prefix and trailing semicolon
  if (clean_declaration.rfind("array ", 0) == 0)
  {
    clean_declaration = clean_declaration.substr(6);
  }
  if (!clean_declaration.empty() && clean_declaration.back() == ';')
  {
    clean_declaration.pop_back();
  }

  // Rule: array name [] = {1st item, 2nd item,�}; => array(name)(1st item)(2nd item)�;
  if (clean_declaration.find("[] = {") != std::string::npos)
  {
    size_t bracket_pos = clean_declaration.find("[]");
    std::string array_name = clean_declaration.substr(0, bracket_pos);
    array_name = std::regex_replace(array_name, std::regex("^\\s+|\\s+$"), ""); // Trim name

    size_t brace_start = clean_declaration.find('{');
    size_t brace_end = clean_declaration.find('}');
    if (brace_start != std::string::npos && brace_end != std::string::npos)
    {
      std::string items_str = clean_declaration.substr(brace_start + 1, brace_end - (brace_start + 1));
      result += "array(" + array_name + ")";

      std::stringstream ss(items_str);
      std::string item;
      while (std::getline(ss, item, ','))
      {
        item = std::regex_replace(item, std::regex("^\\s+|\\s+$"), ""); // Trim each item
        if (!item.empty())
        {
          // Apply NotationTransformation to each item (now InfixToPrefixParenthesized)
          std::string transformed_item = NotationTransformations::Math_InfixToParentheses(item);
          result += "(" + transformed_item + ")";
        }
      }
      return result + ";"; // Add semicolon at the end as per original examples
    }
  }
  // Rule: array name [length] = initial value; => array(name [length]) (initial value);
  else if (clean_declaration.find('=') != std::string::npos)
  {
    size_t eq_pos = clean_declaration.find('=');
    std::string left_part = clean_declaration.substr(0, eq_pos);
    std::string right_part = clean_declaration.substr(eq_pos + 1);

    left_part = std::regex_replace(left_part, std::regex("^\\s+|\\s+$"), "");
    right_part = std::regex_replace(right_part, std::regex("^\\s+|\\s+$"), "");

    // Find the name and length in left_part (e.g., "name [length]")
    size_t open_bracket_pos = left_part.find('[');
    size_t close_bracket_pos = left_part.find(']');

    std::string array_name = left_part.substr(0, open_bracket_pos);
    array_name = std::regex_replace(array_name, std::regex("^\\s+|\\s+$"), "");

    std::string length_str = "";
    if (open_bracket_pos != std::string::npos && close_bracket_pos != std::string::npos)
    {
      length_str = left_part.substr(open_bracket_pos + 1, close_bracket_pos - (open_bracket_pos + 1));
      length_str = std::regex_replace(length_str, std::regex("^\\s+|\\s+$"), "");
    }
    else
    {
      // This case should ideally not happen if it matches "name [length]" format
    }

    // Apply NotationTransformation to length and initial value (now InfixToPrefixParenthesized)
    std::string transformed_length = NotationTransformations::Math_InfixToParentheses(length_str);
    std::string transformed_initial_value = NotationTransformations::Math_InfixToParentheses(right_part);

    result += "array(" + array_name + " [" + transformed_length + "]) (" + transformed_initial_value + ");";
  }
  // Rule: array name[length]; => array(name [length]);
  else if (clean_declaration.find('[') != std::string::npos)
  {
    size_t open_bracket_pos = clean_declaration.find('[');
    size_t close_bracket_pos = clean_declaration.find(']');

    std::string array_name = clean_declaration.substr(0, open_bracket_pos);
    array_name = std::regex_replace(array_name, std::regex("^\\s+|\\s+$"), "");

    std::string length_str = "";
    if (open_bracket_pos != std::string::npos && close_bracket_pos != std::string::npos)
    {
      length_str = clean_declaration.substr(open_bracket_pos + 1, close_bracket_pos - (open_bracket_pos + 1));
      length_str = std::regex_replace(length_str, std::regex("^\\s+|\\s+$"), "");
    }
    // Apply NotationTransformation to length (now InfixToPrefixParenthesized)
    std::string transformed_length = NotationTransformations::Math_InfixToParentheses(length_str);

    result += "array(" + array_name + " [" + transformed_length + "]);";
  }
  // Rule: array name; => array(name [0]); (length is implicitly 0 or default, no transformation needed)
  else
  {
    std::string array_name = std::regex_replace(clean_declaration, std::regex("^\\s+|\\s+$"), ""); // Trim
    result += "array(" + array_name + " [0]);";
  }

  return result;
}

int main()
{
  const std::string filename = "test_declarations.txt";
  std::ifstream testFile(filename);

  if (!testFile.is_open())
  {
    std::cerr << "Error: Could not open file " << filename << std::endl;
    return 1;
  }

  std::string line;
  std::cout << "--- Processing declarations from " << filename << " ---" << std::endl << std::endl;

  while (std::getline(testFile, line))
  {
    // Skip empty lines
    if (line.empty() || std::regex_match(line, std::regex("^\\s*$")))
    {
      continue;
    }

    std::cout << "Original: " << line << "\t\t=> Transformed: ";
    if (line.rfind("var ", 0) == 0) // Starts with "var "
    {
      std::cout << transformVarDeclaration(line) << std::endl;
    }
    else if (line.rfind("array ", 0) == 0) // Starts with "array "
    {
      std::cout << transformArrayDeclaration(line) << std::endl;
    }
    else
    {
      std::cout << "Unknown declaration type." << std::endl;
    }
  }

  testFile.close();

  std::cout << "\n--- Notation Transformations Tests (Infix to Parenthesized Prefix) ---" << std::endl << std::endl;

  // Test cases for checkParenthesesBalance (remains the same)
  std::cout << "Parentheses Balance Check:" << std::endl;
  std::cout << "'((a + b) * c)' is balanced: " << (NotationTransformations::checkParenthesesBalance("((a + b) * c)") ? "True" : "False") << std::endl;
  std::cout << "'(a + b))' is balanced: " << (NotationTransformations::checkParenthesesBalance("(a + b))") ? "True" : "False") << std::endl;
  std::cout << "'(a + (b * c)' is balanced: " << (NotationTransformations::checkParenthesesBalance("(a + (b * c)") ? "True" : "False") << std::endl;
  std::cout << "'' is balanced: " << (NotationTransformations::checkParenthesesBalance("") ? "True" : "False") << std::endl;
  std::cout << std::endl;

  // Test cases for Math_InfixToParentheses (now Infix to Parenthesized Prefix)
  std::cout << "Math Infix to Parenthesized Prefix Transformation:" << std::endl;
  std::string mathExpr1 = "2 + 3 * 4"; // Expected: + (2) (* (3) (4))
  std::cout << "Original: " << mathExpr1 << "\t\t=> Transformed: " << NotationTransformations::Math_InfixToParentheses(mathExpr1) << std::endl;
  std::string mathExpr2 = "(A + B) * C"; // Expected: * (+ (A) (B)) (C)
  std::cout << "Original: " << mathExpr2 << "\t\t=> Transformed: " << NotationTransformations::Math_InfixToParentheses(mathExpr2) << std::endl;
  std::string mathExpr3 = "A + B * C / D - E"; // Expected: - (+ (A) (/ (* (B) (C)) (D))) (E)
  std::cout << "Original: " << mathExpr3 << "\t=> Transformed: " << NotationTransformations::Math_InfixToParentheses(mathExpr3) << std::endl;
  std::string mathExpr4 = "10 + 20 * 3 / 4 - 5"; // Expected: - (+ (10) (/ (* (20) (3)) (4))) (5)
  std::cout << "Original: " << mathExpr4 << "\t=> Transformed: " << NotationTransformations::Math_InfixToParentheses(mathExpr4) << std::endl;
  std::string mathExpr5 = "A ^ B ^ C"; // Expected: (^ (A) (^ (B) (C)))
  std::cout << "Original: " << mathExpr5 << "\t\t=> Transformed: " << NotationTransformations::Math_InfixToParentheses(mathExpr5) << std::endl;
  std::cout << std::endl;


  // Test cases for Logical_InfixToParentheses (now Infix to Parenthesized Prefix)
  std::cout << "Logical Infix to Parenthesized Prefix Transformation:" << std::endl;
  std::string logicalExpr1 = "A && B || C"; // Expected: (|| (&& (A) (B)) (C))
  std::cout << "Original: " << logicalExpr1 << "\t\t=> Transformed: " << NotationTransformations::Logical_InfixToParentheses(logicalExpr1) << std::endl;
  std::string logicalExpr2 = "! A || B"; // Expected: (|| (! (A)) (B))
  std::cout << "Original: " << logicalExpr2 << "\t\t=> Transformed: " << NotationTransformations::Logical_InfixToParentheses(logicalExpr2) << std::endl;
  std::string logicalExpr3 = "(X || Y) && Z"; // Expected: (&& (|| (X) (Y)) (Z))
  std::cout << "Original: " << logicalExpr3 << "\t\t=> Transformed: " << NotationTransformations::Logical_InfixToParentheses(logicalExpr3) << std::endl;
  std::string logicalExpr4 = "A == B && C != D"; // Expected: (&& (== (A) (B)) (!= (C) (D)))
  std::cout << "Original: " << logicalExpr4 << "\t=> Transformed: " << NotationTransformations::Logical_InfixToParentheses(logicalExpr4) << std::endl;
  //std::string logicalExpr5 = "E < F || G >= H xor I"; // Expected: (|| (< (E) (F)) (xor (>= (G) (H)) (I))) -- assuming xor has same precedence as ||
  //std::cout << "Original: " << logicalExpr5 << "\t=> Transformed: " << NotationTransformations::Logical_InfixToParentheses(logicalExpr5) << std::endl;
  std::cout << std::endl;

  return 0;
}

/*  Result
--- Processing declarations from test_declarations.txt ---

Original: var x;                => Transformed: var (x);
Original: var x = value;                => Transformed: var (x[(value)]);
Original: var v,x,y;            => Transformed: var (v); var (x); var (y);
Original: var v,x,y = value;            => Transformed: var (v[(value)]); var (x[(value)]); var (y[(value)]);
Original: array name;           => Transformed: array(name [0]);
Original: array name[10];               => Transformed: array(name [(10)]);
Original: array myArr [5] = 100;                => Transformed: array(myArr [(5)]) ((100));
Original: array items [] = {apple, banana, cherry};             => Transformed: array(items)((apple))((banana))((cherry));
Original: array anotherArr;             => Transformed: array(anotherArr [0]);
Original: array data[20];               => Transformed: array(data [(20)]);
Original: var a = 1;            => Transformed: var (a[(1)]);
Original: var p,q;              => Transformed: var (p); var (q);

--- Notation Transformations Tests (Infix to Parenthesized Prefix) ---

Parentheses Balance Check:
'((a + b) * c)' is balanced: True
'(a + b))' is balanced: False
'(a + (b * c)' is balanced: False
'' is balanced: True

Math Infix to Parenthesized Prefix Transformation:
Original: 2 + 3 * 4             => Transformed: (+ (2) (* (3) (4)))
Original: (A + B) * C           => Transformed: (* (+ (A) (B)) (C))
Original: A + B * C / D - E     => Transformed: (- (+ (A) (/ (* (B) (C)) (D))) (E))
Original: 10 + 20 * 3 / 4 - 5   => Transformed: (- (+ (10) (/ (* (20) (3)) (4))) (5))
Original: A ^ B ^ C             => Transformed: (^ (A) (^ (B) (C)))

Logical Infix to Parenthesized Prefix Transformation:
Original: A && B || C           => Transformed: (|| (&& (A) (B)) (C))
Original: ! A || B              => Transformed: (|| (! (A)) (B))
Original: (X || Y) && Z         => Transformed: (&& (|| (X) (Y)) (Z))
Original: A == B && C != D      => Transformed: (&& (== (A) (B)) (!= (C) (D)))

*/