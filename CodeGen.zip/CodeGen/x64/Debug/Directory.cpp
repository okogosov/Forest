#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Directory.h"

using namespace std;
namespace PPLNS
{
  static Directory* DIRECTORYInstance = nullptr;

  void Directory_CreateInstance(PPL* ppl)
  {
    DIRECTORYInstance = new Directory(ppl);
    DIRECTORYInstance->AddToKeywordDictionary();
  }

  Directory::Directory(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Directory::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("GetFiles", FuncGetFiles);
    AddKeyword("GetDirectories", FuncGetDirectories);
    AddKeyword("SetCurrentDirectory", FuncSetCurrentDirectory);
    AddKeyword("GetCurrentDirectory", FuncGetCurrentDirectory);
    AddKeyword("GetParent", FuncGetParent);
    AddKeyword("CreateDirectory", FuncCreateDirectory);
    AddKeyword("Exists", FuncExists);
    AddKeyword("Delete", FuncDelete);

    help_dict->insert({ "help", "\tDirectory.help([name])" });
    help_dict->insert({ "GetFiles", "\t..." });
    help_dict->insert({ "GetDirectories", "\t..." });
    help_dict->insert({ "SetCurrentDirectory", "\t..." });
    help_dict->insert({ "GetCurrentDirectory", "\t..." });
    help_dict->insert({ "GetParent", "\t..." });
    help_dict->insert({ "CreateDirectory", "\t..." });
    help_dict->insert({ "Exists", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Directory." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Directory", this });
  }
  //=========================================================
  bool Directory::FuncGetFiles(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncGetDirectories(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncSetCurrentDirectory(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncGetCurrentDirectory(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncGetParent(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncCreateDirectory(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncExists(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Directory::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
}
