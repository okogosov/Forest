#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "DataFrame.h"

using namespace std;
namespace PPLNS
{
  bool DataFrame::FuncReadFile(const vector<string>& parameters, string& result, Composite* node = nullptr)
  {
    string func_name = "DataFrame.FuncReadFile";
    string err;
    try
    {
      if (parameters.size() < 1)
      {
        printDlgt({ "Error: {0} wrong format: DataFrame.ReadFile (DataFrame_name)(filename.csv)[(column_name1)(column_name2)...", func_name });
        printDlgt({ " or", });
        printDlgt({ "DataFrame.ReadFile (DataFrame_name)(filename.data)" });
        return false;
      }

      string df_name = "";
      string filename = "";
      string extension = "";
      if (parameters.size() == 1)
        filename = parameters[0];
      else
      {
        df_name = parameters[0];
        filename = parameters[1];
      }
      if (filename.find(".csv") != string::npos)
        extension = "csv";
      if (filename.find(".data") != string::npos)
        extension = "data";
      if (extension.empty())
      {
        printDlgt({ "Error: [{0}] dataframe [{1}]  wrong file extension [{2}] (must be .scr | .data)", func_name, df_name , filename });
        return false;
      }
      if ((extension == "data") && (parameters.size() != 1))
      {
        printDlgt({ "Error: {0} wrong format: DataFrame.ReadFile (DataFrame_name)(filename.csv)[(column_name1)(column_name2)...", func_name });
        printDlgt({ " or", });
        printDlgt({ "DataFrame.ReadFile (DataFrame_name)(filename.data)" });
        return false;
      }
      if (extension == "data")
      {
        string tmp_return = "";
        ppl->processing->FuncReadData({ filename }, tmp_return, node);
        //  df_name = tmp_return; case: several dataframes in several .scr files (1 df per 1 .scr-file) 
        // case: 2 or more dataframe_name in 1 .scr file 
        vector<string> df_names;
        for (auto* c : *(ppl->Global->_children))
        {
          if (c->value == "DataFrame")
            df_names.push_back(c->name);
        }
        //================================================
        for (int i = 0;i < df_names.size();i++)
        {
          df_name = df_names[i];
          TableName tn;
          tn.name = df_name;
          tn.comp_df = GetDataFrameComposite(df_name);
          tn.comp_settings = GetSettingsComposite(tn.comp_df);
          for (auto*& c : *(tn.comp_df->_children))
          {
            if (c->name == "Settings")
              continue;
            tn.column_names.push_back(c->name);
          }

          for (size_t i = 0; i < table_names.size(); i++)
          {
            if (table_names[i].name == df_name)
            {
              table_names.erase(table_names.begin() + i);
              break;
            }
          }
          table_names.push_back(tn);
        }
        //================================================     
        return true;
      }
      if ((extension == "csv") && (parameters.size() == 1))
      {
        df_name = "DF";
      }
      Composite* comp_df = nullptr;
      Composite* comp_settings = nullptr;
      for (auto& tn : table_names)
      {
        if (tn.name == df_name)
        {
          comp_df = tn.comp_df;
          comp_settings = tn.comp_settings;
          break;
        }
      }
      if (comp_df == nullptr)
      {
        err = "[" + func_name + "] wrong DataFrame name [" + df_name + "]";
        printDlgt({ "Error: {0}", err });
        return false;
      }
      vector<TypeWidth> arr_type_width = CreateTypeWidthArray(comp_df, comp_settings);
      int columns_quantity = comp_df->_children->size();

      string output = "     ";
      vector<string> columns_selected;

      if (parameters.size() > 2)
      {
        columns_selected.insert(columns_selected.end(), parameters.begin() + 2, parameters.end());
      }

      string strLength = GetSettingsValue(comp_settings, "RowsLength");
      int Length;
      TryParse(strLength,Length);
      // Test column names
      if (!columns_selected.empty())
      {
        for (const auto& cw : columns_selected)
        {
          bool b2 = false;

          for (int i = 0; i < columns_quantity; i++)
          {
            if ( (*(comp_df->_children))[i]->name == cw)
            {
              b2 = true;
              break;
            }
          }

          if (!b2)
          {
            err = "[" + func_name + "] wrong column name [" + cw + "]";
            printDlgt({ "Error: {0}", err });
            return false;
          }
        }
      }

      // Get RowSelectedFrom & RowSelectedTo
      string strRowSelectedFrom = "";
      int RowSelectedFrom = 0;
      string strRowSelectedTo = "";
      int RowSelectedTo = 0;
      bool b = false;

      if (!strRowSelectedFrom.empty())
      {
        b = TryParse(strRowSelectedFrom, RowSelectedFrom);  // istringstream(strRowSelectedFrom) >> RowSelectedFrom;
        if (!b)
        {
          err = "Error: [" + func_name + "] not digital RowSelectedFrom [" + strRowSelectedFrom + "]";
          printDlgt({ "Error: {0}", err });
          return false;
        }
      }

      if (!strRowSelectedTo.empty())
      {
        b = TryParse(strRowSelectedTo, RowSelectedTo); //istringstream(strRowSelectedTo) >> RowSelectedTo;
        if (!b)
        {
          err = "[" + func_name + "] not digital RowSelectedTo [" + strRowSelectedTo + "]";
          printDlgt({ "Error: {0}", err });
          return false;
        }
      }

      if (!ifstream(filename))
      {
        err = "[" + func_name + "] file [" + filename + "] is omitted";
        printDlgt({ "Error: {0}", err });
        return false;
      }

      int real_lines = 0;

      //if(extension == "csv")   // processing extension "data" above
      {
        ifstream file(filename);
        vector<string> arr_lines;
        string line;

        while (getline(file, line))
        {
          arr_lines.push_back(line);
        }

        if (arr_lines.size() > Length)
        {
          string add_result = "";
          int delta = arr_lines.size() - Length;
          FuncAddRows({ df_name, to_string(delta) }, add_result, node);
          Length = arr_lines.size();
        }

        real_lines = Length = arr_lines.size();

        // Get RowSelectedFrom & RowSelectedTo
        strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
        strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");
        RowSelectedTo = real_lines - 1;

        if (!strRowSelectedFrom.empty())
        {
          b = TryParse(strRowSelectedFrom, RowSelectedFrom); 
          if (!b)
          {
            err = "[" + func_name + "] not digital RowSelectedFrom [" + strRowSelectedFrom + "]";
            printDlgt({ "Error: {0}", err });
            return false;
          }
        }

        if (!strRowSelectedTo.empty())
        {
          b = TryParse(strRowSelectedTo, RowSelectedTo);
          if (!b)
          {
            err = "[" + func_name + "] not digital RowSelectedTo [" + strRowSelectedTo + "]";
            printDlgt({ "Error: {0}", err });
            return false;
          }
        }

        if (RowSelectedTo > real_lines)
        {
          err = "[" + func_name + "] RowSelectedTo [" + strRowSelectedTo + "] > real_lines [" + to_string(real_lines) + "]";
          printDlgt({ "Error: {0}", err });
          return false;
        }

        int column_index = 0;

        if (columns_selected.empty())
        {
          for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
          {
            vector<string> cells = ppl->processing->SplitCsv(arr_lines[j], ',');
            int col_num = cells.size();

            for (int i = 0; i < col_num; i++)
            {
              column_index = i + 1;

              if (arr_type_width[i].Type == "Text")
              {
                //static_cast<Composite*>(comp_df->_children[column_index])->_children[j].value = cells[i];
                GetCellComponent(comp_df, column_index, j)->value = trim(cells[i], "\"");
                continue;
              }

              if (arr_type_width[column_index - 1].Type == "Number")
              {
                double d = 0;
                bool b2 = TryParse(cells[i], d);

                if (b2)
                {
                  GetCellComponent(comp_df, column_index, j)->value = cells[i];
                }
                else
                {
                  err = "[" + func_name + "] DataFrame name [" + df_name + "] not digital data [" + cells[i] + "]";
                  printDlgt({ "Error: {0}", err });
                  return false;
                }
                continue;
              }
              else
              {
                err = "[" + func_name + "] wrong DataFrame name [" + df_name + "]";
                printDlgt({ "Error: {0}", err });
                return false;
              }
            }
          }
        }
        else
        {
          for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
          {
            vector<string> cells = ppl->processing->SplitCsv(arr_lines[j], ',');
            int col_num = min(static_cast<int>(cells.size()), static_cast<int>(columns_selected.size()));

            for (int i = 0; i < col_num; i++)
            {
              string selected_name = columns_selected[i];
              column_index = GetColumnIndex(comp_df, selected_name);

              if (arr_type_width[column_index - 1].Type == "Text")
              {
                GetCellComponent(comp_df, column_index, j)->value = trim(cells[i], "\"");
                continue;
              }

              if (arr_type_width[column_index - 1].Type == "Number")
              {
                double d = 0;
                bool b2 = TryParse(cells[i], d);
                if (b2)
                {
                  //Composite* comp2 = (Composite*) (*(comp_df->_children))[column_index];
                  //static_cast<Composite*>(comp_df->_children[column_index])->_children[j].value = cells[i];
                  //(*(comp2->_children))[j]->value = cells[i];

                  GetCellComponent(comp_df, column_index, j)->value = cells[i];
                }
                else
                {
                  err = "[" + func_name + "] DataFrame name [" + df_name + "] not digital data [" + cells[i] + "]";
                  printDlgt({ "Error: {0}", err });
                  return false;
                }

                continue;
              }
              else
              {
                err = "[" + func_name + "] wrong DataFrame name [" + df_name + "]";
                printDlgt({ "Error: {0}", err });
                return false;
              }
            }
          }
        }
      }
      /*if (extension == "data")
      {
        TableName tn;
        tn.name = df_name;
        tn.comp_df = GetDataFrameComposite(df_name);
        tn.comp_settings = GetSettingsComposite(tn.comp_df);
        for (auto*& c : *(tn.comp_df->_children))
        {
          if (c->name == "Settings")
            continue;
          tn.column_names.push_back(c->name);
        }

        for (size_t i = 0; i < table_names.size(); i++)
        {
          if (table_names[i].name == df_name)
          {
            table_names.erase(table_names.begin() + i);
            break;
          }
        }
        table_names.push_back(tn);
      }*/
      return true;
    }
    catch (const exception& ex)
    {
      err = "[" + func_name + "]";
      printDlgt({ "Error: {0}", err });
      return false;
    }
    return true;
  }

}