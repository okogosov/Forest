#include "pch.h"
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Vector.h"

using namespace std;
namespace PPLNS
{
  static Vector* VECTORInstance = nullptr;

  void Vector_CreateInstance(PPL* ppl)
  {
    VECTORInstance = new Vector(ppl);
    VECTORInstance->AddToKeywordDictionary();
  }

  Vector::Vector(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(vector<string>, string&, Composite*)>>;
  }
  //=======================================================
  void Vector::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Create", FuncCreate);
    AddKeyword("Get", FuncGet);
    AddKeyword("Set", FuncSet);
    AddKeyword("Add", FuncAdd);
    AddKeyword("Write", FuncWrite);
    AddKeyword("WriteNames", FuncWriteNames);
    AddKeyword("Delete", FuncDelete);
    AddKeyword("DeleteAll", FuncDeleteAll);

    help_dict->insert({ "help", "\tVector.help([name])" });
    help_dict->insert({ "Create", "\t..." });
    help_dict->insert({ "Get", "\t..." });
    help_dict->insert({ "Set", "\t..." });
    help_dict->insert({ "Add", "\t..." });
    help_dict->insert({ "Write", "\t..." });
    help_dict->insert({ "WriteNames", "\t..." });
    help_dict->insert({ "Delete", "\t..." });
    help_dict->insert({ "DeleteAll", "\t..." });
    for (const auto pair : *keyword_dict)
    {
      string key = "Vector." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Vector", this });
  }
  //=========================================================
  bool Vector::FuncCreate(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncGet(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncSet(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncAdd(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncWrite(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncWriteNames(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncDelete(vector<string> parameters, string& result, Composite* node) { return true; }
  bool Vector::FuncDeleteAll(vector<string> parameters, string& result, Composite* node) { return true; }
}
